import { useState, useEffect } from 'react';
import { NavLink, Outlet, useNavigate } from 'react-router-dom';
import { 
  Cpu, LayoutDashboard, Settings, LogOut, Shield, 
  Menu, X, User, Activity, Bell, Grid, BarChart3, Radio, Download,
  Sun, Moon
} from 'lucide-react';

interface AppLayoutProps {
  user: any;
  wsConnected: boolean;
  onSignOut: () => void;
}

export default function AppLayout({ user, wsConnected, onSignOut }: AppLayoutProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  
  // Theme logic
  const [theme, setTheme] = useState<'dark' | 'light'>(() => {
    return (localStorage.getItem('casamesh_theme') as 'dark' | 'light') || 'dark';
  });

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem('casamesh_theme', theme);
  }, [theme]);

  const toggleTheme = () => {
    setTheme(prev => prev === 'dark' ? 'light' : 'dark');
  };

  const navigate = useNavigate();

  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
  }, []);

  const handleInstallClick = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setDeferredPrompt(null);
    }
  };

  const handleSignOut = () => {
    onSignOut();
    navigate('/');
  };

  const navItems = [
    { to: '/dashboard', icon: LayoutDashboard, label: 'Overview' },
    { to: '/devices', icon: Radio, label: 'Devices' },
    { to: '/automations', icon: Activity, label: 'Automations' },
    { to: '/dashboards', icon: Grid, label: 'Dashboards' },
    { to: '/analytics', icon: BarChart3, label: 'Analytics' },
    { to: '/alerts', icon: Bell, label: 'Notifications' },
    { to: '/integrations', icon: Settings, label: 'Integrations' },
  ];

  if (user?.role === 'ADMIN' || user?.role === 'OWNER') {
    navItems.push({ to: '/settings', icon: Shield, label: 'Owner Console' });
  }

  const handleNavClick = () => {
    setMobileMenuOpen(false);
  };

  return (
    <div className="layout-container">
      {/* Sidebar Navigation */}
      <aside className={`app-sidebar glass-panel ${mobileMenuOpen ? 'open' : ''}`}>
        <div style={styles.branding}>
          <div style={styles.logoCircle}>
            <Cpu size={24} color="var(--color-primary)" />
          </div>
          <span style={styles.brandName}>Casa<span>Mesh</span></span>
        </div>

        <nav style={styles.navigation}>
          {navItems.map((item) => (
            <NavLink
              key={item.to}
              to={item.to}
              onClick={handleNavClick}
              className={({ isActive }) => (isActive ? 'active-nav-item' : '')}
              style={({ isActive }) => ({
                ...styles.navBtn,
                background: isActive ? 'var(--color-primary-glow)' : 'transparent',
                color: isActive ? 'var(--text-primary)' : 'var(--text-secondary)'
              })}
            >
              <item.icon size={18} />
              {item.label}
            </NavLink>
          ))}
        </nav>

        <div style={styles.sidebarFooter}>
          <div style={styles.profileRow}>
            <div style={styles.avatar}>
              <User size={16} />
            </div>
            <div style={styles.profileDetails}>
              <span style={styles.profileEmail}>{user?.email}</span>
              <span style={styles.profileRole}>{user?.role}</span>
            </div>
          </div>

          <button onClick={handleSignOut} style={styles.signOutBtn} className="btn btn-secondary">
            <LogOut size={16} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Panel Frame */}
      <div className="app-main-frame">
        {/* Top Navbar */}
        <header className="app-navbar glass-panel">
          <div style={styles.navLeft}>
            <button className="app-menu-toggle" onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div style={styles.wsIndicator}>
              <span className={`status-indicator ${wsConnected ? 'status-online' : 'status-offline'}`}></span>
              <span style={styles.wsText}>{wsConnected ? 'Cloud Sync Online' : 'Connecting to Cloud...'}</span>
            </div>
          </div>
          <div style={styles.navRight}>
            <button onClick={toggleTheme} className="btn btn-secondary" style={{ padding: '8px', marginRight: '16px', borderRadius: '50%' }} aria-label="Toggle Theme">
              {theme === 'dark' ? <Sun size={16} /> : <Moon size={16} />}
            </button>
            {deferredPrompt && (
              <button onClick={handleInstallClick} className="btn btn-secondary text-indigo-400 hover:text-indigo-300 py-1 text-sm border-indigo-500/30">
                <Download size={14} /> Install App
              </button>
            )}
            <span style={styles.tag}>CasaMesh v2.0</span>
          </div>
        </header>

        {/* Nested Route View Router */}
        <main style={styles.content}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}

const styles = {
  branding: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    paddingLeft: '8px',
  },
  logoCircle: {
    width: '40px',
    height: '40px',
    borderRadius: '10px',
    background: 'rgba(99, 102, 241, 0.08)',
    border: '1px solid rgba(99, 102, 241, 0.2)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 0 15px rgba(99, 102, 241, 0.2)',
  },
  brandName: {
    fontSize: '20px',
    fontWeight: 700,
    color: 'var(--text-primary)',
    span: { color: 'var(--color-primary)' },
  },
  navigation: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '8px',
    flex: 1,
  },
  navBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '12px 16px',
    borderRadius: '10px',
    border: 'none',
    fontSize: '14px',
    fontWeight: 600,
    textAlign: 'left' as const,
    cursor: 'pointer',
    transition: 'all 0.2s',
    outline: 'none',
    textDecoration: 'none',
    '&:hover': {
      background: 'var(--bg-surface-hover)',
      color: 'var(--text-primary)',
    },
  },
  sidebarFooter: {
    borderTop: '1px solid var(--border-glass)',
    paddingTop: '16px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '14px',
  },
  profileRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    paddingLeft: '6px',
  },
  avatar: {
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    background: 'var(--bg-glass)',
    border: '1px solid var(--border-glass)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: 'var(--text-primary)',
  },
  profileDetails: {
    display: 'flex',
    flexDirection: 'column' as const,
    width: '150px',
  },
  profileEmail: {
    fontSize: '12px',
    color: 'var(--text-primary)',
    fontWeight: 500,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap' as const,
  },
  profileRole: {
    fontSize: '10px',
    color: 'var(--color-primary)',
    fontWeight: 600,
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  signOutBtn: {
    width: '100%',
    padding: '10px',
    fontSize: '13px',
  },
  navLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
  },
  wsIndicator: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  wsText: {
    fontSize: '13px',
    color: '#94a3b8',
    fontWeight: 500,
  },
  navRight: {
    display: 'flex',
    alignItems: 'center',
  },
  tag: {
    background: 'var(--btn-secondary-bg)',
    border: '1px solid var(--border-glass)',
    padding: '4px 10px',
    borderRadius: '20px',
    fontSize: '11px',
    fontWeight: 600,
    color: 'var(--text-secondary)',
  },
  content: {
    flex: 1,
    position: 'relative' as const,
  },
};
