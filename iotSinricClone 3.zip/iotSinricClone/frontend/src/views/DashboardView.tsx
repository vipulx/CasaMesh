import React, { useState, useEffect, useRef } from 'react';
import { 
  Cpu, Plus, Trash2, Power, Lightbulb, Thermometer, Radio, 
  Copy, Check, ShieldAlert, Upload, Download, Wifi
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface Device {
  id: string;
  name: string;
  type: string;
  status: string;
  key: string;
  secret: string;
  provisionToken: string;
  properties: string; // JSON string
  lastSeen: string;
}

interface TelemetryPoint {
  id: string;
  property: string;
  value: string;
  timestamp: string;
}

interface DashboardViewProps {
  apiBase: string;
  token: string;
  devices: Device[];
  setDevices: React.Dispatch<React.SetStateAction<Device[]>>;
  wsMessage: any;
  sendWsMessage: (msg: any) => void;
}

export default function DashboardView({ 
  apiBase, token, devices, setDevices, wsMessage, sendWsMessage 
}: DashboardViewProps) {
  const [error, setError] = useState('');
  
  // Selected device for detail view
  const [selectedDevice, setSelectedDevice] = useState<Device | null>(null);
  const [telemetry, setTelemetry] = useState<TelemetryPoint[]>([]);
  const [codeType, setCodeType] = useState<'arduino' | 'python'>('arduino');
  const [generatedCode, setGeneratedCode] = useState('');
  
  // Modals
  const [showAddModal, setShowAddModal] = useState(false);
  const [newDeviceName, setNewDeviceName] = useState('');
  const [newDeviceType, setNewDeviceType] = useState('SWITCH');
  
  // Clipboard
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };

  // Sync state changes pushed through WebSockets
  useEffect(() => {
    if (!wsMessage) return;

    if (wsMessage.type === 'deviceConnectionChanged') {
      setDevices(prev => prev.map(d => d.id === wsMessage.deviceId ? { ...d, status: wsMessage.status } : d));
      if (selectedDevice && selectedDevice.id === wsMessage.deviceId) {
        setSelectedDevice(prev => prev ? { ...prev, status: wsMessage.status } : null);
      }
    } 
    else if (wsMessage.type === 'deviceStateChanged') {
      setDevices(prev => prev.map(d => d.id === wsMessage.deviceId ? { ...d, properties: JSON.stringify(wsMessage.properties) } : d));
      if (selectedDevice && selectedDevice.id === wsMessage.deviceId) {
        setSelectedDevice(prev => prev ? { ...prev, properties: JSON.stringify(wsMessage.properties) } : null);
      }
    }
    else if (wsMessage.type === 'deviceTelemetry') {
      // If we receive telemetry and the selected device is active, append to historical array
      if (selectedDevice && selectedDevice.id === wsMessage.deviceId) {
        const points = Object.entries(wsMessage.properties).map(([key, val]) => ({
          id: Math.random().toString(),
          property: key,
          value: String(val),
          timestamp: new Date().toISOString()
        }));
        setTelemetry(prev => [...prev, ...points].slice(-30)); // Cap to last 30
      }
    }
  }, [wsMessage]);

  // Load telemetry logs when selected device changes
  useEffect(() => {
    if (!selectedDevice) return;
    
    const fetchTelemetry = async () => {
      try {
        const res = await fetch(`${apiBase}/api/v1/devices/${selectedDevice.id}/telemetry?limit=40`, { headers });
        if (res.ok) {
          const data = await res.json();
          setTelemetry(data);
        }
      } catch (e) {}
    };

    const fetchCodeTemplate = async () => {
      try {
        const res = await fetch(`${apiBase}/api/v1/devices/${selectedDevice.id}/template?type=${codeType}`, { headers });
        if (res.ok) {
          const data = await res.json();
          setGeneratedCode(data.code);
        }
      } catch (e) {}
    };

    fetchTelemetry();
    fetchCodeTemplate();
  }, [selectedDevice, codeType]);

  const handleCreateDevice = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeviceName) return;

    try {
      const res = await fetch(`${apiBase}/api/v1/devices`, {
        method: 'POST',
        headers,
        body: JSON.stringify({ name: newDeviceName, type: newDeviceType })
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create device');

      setDevices([...devices, data]);
      setShowAddModal(false);
      setNewDeviceName('');
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteDevice = async (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this device? This will unlink all history records.')) return;

    try {
      const res = await fetch(`${apiBase}/api/v1/devices/${id}`, {
        method: 'DELETE',
        headers
      });

      if (!res.ok) throw new Error('Failed to delete device');

      setDevices(devices.filter(d => d.id !== id));
      if (selectedDevice?.id === id) {
        setSelectedDevice(null);
      }
    } catch (err: any) {
      setError(err.message);
    }
  };

  // Dispatch a change trigger (control action) to the device
  const handleControlDevice = (deviceId: string, property: string, value: any) => {
    // 1. Sync WebSocket update to server immediately
    sendWsMessage({
      action: 'control',
      deviceId,
      property,
      value
    });

    // 2. Optimistic UI update locally
    setDevices(prev => prev.map(d => {
      if (d.id === deviceId) {
        let currentProps = {};
        try { currentProps = JSON.parse(d.properties); } catch (e) {}
        const updatedProps = { ...currentProps, [property]: value };
        return { ...d, properties: JSON.stringify(updatedProps) };
      }
      return d;
    }));

    if (selectedDevice && selectedDevice.id === deviceId) {
      setSelectedDevice(prev => {
        if (!prev) return null;
        let currentProps = {};
        try { currentProps = JSON.parse(prev.properties); } catch (e) {}
        const updatedProps = { ...currentProps, [property]: value };
        return { ...prev, properties: JSON.stringify(updatedProps) };
      });
    }
  };

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const getDeviceIcon = (type: string, size = 20, active = false) => {
    const color = active ? 'var(--color-primary)' : 'var(--text-secondary)';
    switch (type) {
      case 'LIGHT':
        return <Lightbulb size={size} color={active ? '#f59e0b' : color} />;
      case 'THERMOSTAT':
        return <Thermometer size={size} color={active ? '#ef4444' : color} />;
      case 'SENSOR':
        return <Radio size={size} color={active ? '#10b981' : color} />;
      default:
        return <Power size={size} color={active ? 'var(--color-success)' : color} />;
    }
  };

  // Parsing properties JSON safely
  const parseProperties = (propsStr: string) => {
    try {
      return JSON.parse(propsStr);
    } catch (e) {
      return {};
    }
  };

  // Convert telemetry dates into clean string indices for charting
  const getChartData = () => {
    const pointsMap: { [time: string]: any } = {};
    telemetry.forEach(p => {
      const timeStr = new Date(p.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });
      if (!pointsMap[timeStr]) {
        pointsMap[timeStr] = { time: timeStr };
      }
      pointsMap[timeStr][p.property] = parseFloat(p.value);
    });
    return Object.values(pointsMap);
  };

  return (
    <div style={styles.container} className="animate-fade-in">
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>IoT Registered Devices</h1>
          <p style={styles.subtitle}>Register, inspect, customize, and write script controls for your connected hardware devices.</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowAddModal(true)}>
          <Plus size={18} />
          Register Device
        </button>
      </div>

      {error && (
        <div style={styles.errorAlert}>
          <ShieldAlert size={18} />
          <span>{error}</span>
        </div>
      )}

      <div style={styles.dashboardSplit}>
        {/* DEVICES LIST GRID */}
        <div style={styles.leftPane}>
          {devices.length === 0 ? (
            <div className="glass-panel" style={styles.emptyCard}>
              <Cpu size={48} color="#6366f1" style={{ marginBottom: '16px', opacity: 0.6 }} />
              <h3>No Registered Devices</h3>
              <p>Create a logical switch, sensor channel, or thermostat to link physical devices.</p>
              <button className="btn btn-secondary" style={{ marginTop: '16px' }} onClick={() => setShowAddModal(true)}>
                Add Device Channel
              </button>
            </div>
          ) : (
            <div className="grid-layout">
              {devices.map((device) => {
                const props = parseProperties(device.properties);
                const isOnline = device.status === 'ONLINE';
                const isPowerOn = props.powerState === 'On';

                return (
                  <div 
                    key={device.id} 
                    className="glass-panel glass-panel-interactive"
                    style={{
                      ...styles.deviceCard,
                      borderColor: selectedDevice?.id === device.id ? 'var(--color-primary)' : 'var(--border-glass)',
                      boxShadow: selectedDevice?.id === device.id ? 'var(--shadow-glow)' : 'var(--shadow-card)'
                    }}
                    onClick={() => setSelectedDevice(device)}
                  >
                    <div style={styles.cardTop}>
                      <div style={styles.iconTitle}>
                        <div style={styles.iconCircle}>
                          {getDeviceIcon(device.type, 20, isPowerOn || device.type === 'SENSOR')}
                        </div>
                        <div>
                          <strong style={styles.deviceName}>{device.name}</strong>
                          <span style={styles.deviceType}>{device.type}</span>
                        </div>
                      </div>
                      <button 
                        onClick={(e) => handleDeleteDevice(device.id, e)}
                        style={styles.cardDelete}
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>

                    <div style={styles.cardControls}>
                      {/* Power Switch control */}
                      {device.type !== 'SENSOR' && (
                        <div style={styles.switchRow}>
                          <span style={styles.controlLabel}>Power State</span>
                          <label className="switch" onClick={(e) => e.stopPropagation()}>
                            <input 
                              type="checkbox"
                              checked={isPowerOn}
                              onChange={(e) => handleControlDevice(device.id, 'powerState', e.target.checked ? 'On' : 'Off')}
                            />
                            <span className="slider"></span>
                          </label>
                        </div>
                      )}

                      {/* Render temperature/humidity previews for sensor */}
                      {device.type === 'SENSOR' && (
                        <div style={styles.sensorPreview}>
                          <div>Temp: <strong>{props.temperature !== undefined ? `${props.temperature}°C` : '--'}</strong></div>
                          <div>Hum: <strong>{props.humidity !== undefined ? `${props.humidity}%` : '--'}</strong></div>
                        </div>
                      )}
                      
                      {/* Thermostat brief values */}
                      {device.type === 'THERMOSTAT' && (
                        <div style={styles.sensorPreview}>
                          <div>Target: <strong>{props.targetTemperature || '--'}°C</strong></div>
                          <div>Current: <strong>{props.temperature || '--'}°C</strong></div>
                        </div>
                      )}
                    </div>

                    <div style={styles.cardFooter}>
                      <div style={styles.statusGroup}>
                        <span className={`status-indicator ${isOnline ? 'status-online' : 'status-offline'}`}></span>
                        <span style={styles.statusText}>{device.status}</span>
                      </div>
                      <span style={styles.seenText}>
                        {isOnline ? 'Connected' : `Last seen: ${new Date(device.lastSeen).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}`}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* DEVICE DETAILS PANE */}
        {selectedDevice && (
          <div className="glass-panel" style={styles.rightPane}>
            <div style={styles.detailHeader}>
              <div>
                <h2 style={styles.detailTitle}>{selectedDevice.name}</h2>
                <div style={styles.statusGroup}>
                  <span className={`status-indicator ${selectedDevice.status === 'ONLINE' ? 'status-online' : 'status-offline'}`}></span>
                  <span style={styles.statusText}>{selectedDevice.status}</span>
                </div>
              </div>
              <button className="btn btn-secondary" style={styles.closeBtn} onClick={() => setSelectedDevice(null)}>Close</button>
            </div>

            {/* CONTROL BLOCK */}
            <div style={styles.detailSection}>
              <h3 style={styles.sectionHeading}>Device Control Console</h3>
              
              {(() => {
                const props = parseProperties(selectedDevice.properties);
                
                return (
                  <div style={styles.detailControls}>
                    {/* General power switch */}
                    {selectedDevice.type !== 'SENSOR' && (
                      <div style={styles.ctrlActionRow}>
                        <span>Toggle Relays</span>
                        <button 
                          className={`btn ${props.powerState === 'On' ? 'btn-primary' : 'btn-secondary'}`}
                          onClick={() => handleControlDevice(selectedDevice.id, 'powerState', props.powerState === 'On' ? 'Off' : 'On')}
                        >
                          <Power size={16} />
                          {props.powerState === 'On' ? 'Switch OFF' : 'Switch ON'}
                        </button>
                      </div>
                    )}

                    {/* Light dimming slider and colors */}
                    {selectedDevice.type === 'LIGHT' && (
                      <div style={styles.lightControlPack}>
                        <div style={styles.sliderGroup}>
                          <div style={styles.sliderLabelRow}>
                            <span>Brightness level</span>
                            <strong>{props.brightness || 0}%</strong>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="100"
                            value={props.brightness || 0}
                            onChange={(e) => handleControlDevice(selectedDevice.id, 'brightness', parseInt(e.target.value))}
                            style={styles.slider}
                          />
                        </div>

                        {/* Solid HSL gradient colors simulator */}
                        <div style={styles.colorSelectorRow}>
                          <span>Color Tuning</span>
                          <div style={styles.colorCircles}>
                            {[
                              { r: 255, g: 255, b: 255, name: 'white' },
                              { r: 239, g: 68, b: 68, name: 'red' },
                              { r: 245, g: 158, b: 11, name: 'orange' },
                              { r: 16, g: 185, b: 129, name: 'green' },
                              { r: 99, g: 102, b: 241, name: 'indigo' },
                            ].map((col) => {
                              const activeColor = props.color;
                              const isSelected = activeColor && activeColor.r === col.r && activeColor.g === col.g && activeColor.b === col.b;
                              return (
                                <button
                                  key={col.name}
                                  onClick={() => handleControlDevice(selectedDevice.id, 'color', { r: col.r, g: col.g, b: col.b })}
                                  style={{
                                    ...styles.colorCircleBtn,
                                    background: `rgb(${col.r}, ${col.g}, ${col.b})`,
                                    borderColor: isSelected ? '#fff' : 'rgba(255,255,255,0.1)'
                                  }}
                                />
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Thermostat target clicks */}
                    {selectedDevice.type === 'THERMOSTAT' && (
                      <div style={styles.thermostatPack}>
                        <div style={styles.tempGauge}>
                          <span>Target Temperature</span>
                          <div style={styles.tempControls}>
                            <button 
                              className="btn btn-secondary"
                              onClick={() => handleControlDevice(selectedDevice.id, 'targetTemperature', (props.targetTemperature || 22) - 0.5)}
                            >-</button>
                            <span style={styles.tempText}>{props.targetTemperature || 22.0}°C</span>
                            <button 
                              className="btn btn-secondary"
                              onClick={() => handleControlDevice(selectedDevice.id, 'targetTemperature', (props.targetTemperature || 22) + 0.5)}
                            >+</button>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Sensor current readings preview */}
                    {selectedDevice.type === 'SENSOR' && (
                      <div style={styles.sensorPack}>
                        <div style={styles.sensorGauge}>
                          <span style={styles.gaugeLabel}>Temperature</span>
                          <strong style={styles.gaugeVal}>{props.temperature !== undefined ? `${props.temperature}°C` : '--'}</strong>
                        </div>
                        <div style={styles.sensorGauge}>
                          <span style={styles.gaugeLabel}>Humidity</span>
                          <strong style={styles.gaugeVal}>{props.humidity !== undefined ? `${props.humidity}%` : '--'}</strong>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })()}
            </div>

            {/* CHART PLOTS FOR SENSOR / HISTORICAL TELEMETRY */}
            {selectedDevice.type === 'SENSOR' && telemetry.length > 0 && (
              <div style={styles.detailSection}>
                <h3 style={styles.sectionHeading}>Live Sensor Data</h3>
                <div style={{ width: '100%', height: 180, marginTop: '12px' }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={getChartData()} margin={{ top: 10, right: 10, left: -25, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                      <XAxis dataKey="time" stroke="var(--text-muted)" fontSize={10} />
                      <YAxis stroke="var(--text-muted)" fontSize={10} />
                      <Tooltip 
                        contentStyle={{ 
                          background: 'rgba(10, 8, 20, 0.95)', 
                          borderColor: 'rgba(255,255,255,0.1)',
                          borderRadius: '8px'
                        }}
                      />
                      <Line type="monotone" dataKey="temperature" name="Temp (°C)" stroke="#ef4444" strokeWidth={2} dot={false} />
                      <Line type="monotone" dataKey="humidity" name="Hum (%)" stroke="#10b981" strokeWidth={2} dot={false} />
                    </LineChart>
                  </ResponsiveContainer>
                </div>
              </div>
            )}

            {/* CREDENTIALS KEYS */}
            <div style={styles.detailSection}>
              <h3 style={styles.sectionHeading}>Device Access Credentials</h3>
              <div style={styles.credentialsBlock}>
                <div style={styles.credRow}>
                  <span>Device ID</span>
                  <div style={styles.credValue}>
                    <code>{selectedDevice.id}</code>
                    <button onClick={() => handleCopy(selectedDevice.id, 'devId')} style={styles.copyBtn}>
                      {copiedText === 'devId' ? <Check size={12} color="#10b981" /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>

                <div style={styles.credRow}>
                  <span>Device Key</span>
                  <div style={styles.credValue}>
                    <code>{selectedDevice.key}</code>
                    <button onClick={() => handleCopy(selectedDevice.key, 'devKey')} style={styles.copyBtn}>
                      {copiedText === 'devKey' ? <Check size={12} color="#10b981" /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>

                <div style={styles.credRow}>
                  <span style={{ display: 'flex', alignItems: 'center', gap: 4 }}>
                    <Wifi size={12} color="#a855f7" /> Provision Token
                  </span>
                  <div style={styles.credValue}>
                    <code style={{ color: '#a855f7' }}>{selectedDevice.provisionToken || '—'}</code>
                    <button onClick={() => handleCopy(selectedDevice.provisionToken || '', 'provToken')} style={styles.copyBtn}>
                      {copiedText === 'provToken' ? <Check size={12} color="#10b981" /> : <Copy size={12} />}
                    </button>
                  </div>
                </div>
              </div>
              <p style={{ fontSize: 11, color: 'var(--text-muted)', marginTop: 8, lineHeight: 1.5 }}>
                💡 Use the <strong>Provision Token</strong> on first device boot. It exchanges for a secure JWT — never hardcode the device secret.
              </p>
            </div>

            {/* CODE SAMPLES TEMPLATES FOR CONNECTING */}
            <div style={styles.detailSection}>
              <div style={styles.codeHeader}>
                <h3 style={styles.sectionHeading}>Firmware Code Templates</h3>
                <div style={styles.tabs}>
                  <button 
                    style={{ ...styles.tabBtn, color: codeType === 'arduino' ? 'var(--color-primary)' : 'var(--text-muted)' }}
                    onClick={() => setCodeType('arduino')}
                  >ESP32 Arduino</button>
                  <button 
                    style={{ ...styles.tabBtn, color: codeType === 'python' ? 'var(--color-primary)' : 'var(--text-muted)' }}
                    onClick={() => setCodeType('python')}
                  >Python (RPi)</button>
                </div>
              </div>

              <div style={styles.codeSnippetBox}>
                <button 
                  onClick={() => handleCopy(generatedCode, 'code')}
                  className="btn btn-secondary"
                  style={styles.codeCopy}
                >
                  {copiedText === 'code' ? <Check size={12} color="#10b981" /> : <Copy size={12} />}
                  {copiedText === 'code' ? 'Copied Code!' : 'Copy Code'}
                </button>
                <pre style={styles.preCode}>
                  <code>{generatedCode}</code>
                </pre>
              </div>
            </div>

            {/* OTA FIRMWARE UPDATE */}
            <OtaPanel apiBase={apiBase} token={token} deviceId={selectedDevice.id} />

          </div>
        )}
      </div>

      {/* REGISTER DEVICE MODAL */}
      {showAddModal && (
        <div style={styles.modalOverlay}>
          <div className="glass-panel" style={styles.modalCard}>
            <h2 style={styles.modalTitle}>Register New Device</h2>
            <form onSubmit={handleCreateDevice} style={styles.form}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Device Name</label>
                <input 
                  type="text"
                  className="input-field"
                  placeholder="e.g. Living Room Switch"
                  value={newDeviceName}
                  onChange={(e) => setNewDeviceName(e.target.value)}
                  required
                />
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Device Type</label>
                <select
                  className="input-field"
                  value={newDeviceType}
                  onChange={(e) => setNewDeviceType(e.target.value)}
                  style={styles.select}
                  required
                >
                  <option value="SWITCH">SWITCH — Relay / power toggle</option>
                  <option value="LIGHT">LIGHT — Dimmable / RGB bulb</option>
                  <option value="THERMOSTAT">THERMOSTAT — Climate controller</option>
                  <option value="SENSOR">SENSOR — Temperature / humidity</option>
                  <option value="FAN">FAN — Speed control</option>
                  <option value="LOCK">LOCK — Smart door lock</option>
                  <option value="CUSTOM">CUSTOM — Custom device</option>
                </select>
              </div>

              <div style={styles.modalButtons}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Create Device</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '24px',
    maxWidth: '1350px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '24px',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '16px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    color: 'var(--text-primary)',
  },
  subtitle: {
    fontSize: '14px',
    color: 'var(--text-secondary)',
    marginTop: '4px',
  },
  errorAlert: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    background: 'rgba(239, 68, 68, 0.1)',
    border: '1px solid rgba(239, 68, 68, 0.3)',
    color: '#fca5a5',
    padding: '12px 16px',
    borderRadius: '8px',
    fontSize: '13px',
  },
  dashboardSplit: {
    display: 'grid',
    gridTemplateColumns: '1fr',
    gap: '24px',
    alignItems: 'start',
    '@media (min-width: 992px)': {
      gridTemplateColumns: '3fr 2fr',
    },
  },
  leftPane: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '20px',
  },
  rightPane: {
    padding: '24px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '24px',
    maxHeight: '90vh',
    overflowY: 'auto' as const,
    position: 'sticky' as const,
    top: '24px',
  },
  emptyCard: {
    textAlign: 'center' as const,
    padding: '60px 24px',
    h3: { color: 'var(--text-primary)', fontSize: '20px', marginBottom: '8px' },
    p: { color: 'var(--text-secondary)', fontSize: '14px', maxWidth: '400px', margin: '0 auto' },
  },
  deviceCard: {
    padding: '20px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  cardTop: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  iconTitle: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
  },
  iconCircle: {
    width: '40px',
    height: '40px',
    borderRadius: '10px',
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-glass)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  deviceName: {
    fontSize: '15px',
    color: 'var(--text-primary)',
    fontWeight: 600,
    display: 'block',
  },
  deviceType: {
    fontSize: '11px',
    color: 'var(--text-secondary)',
    textTransform: 'uppercase' as const,
    fontWeight: 500,
    marginTop: '2px',
    display: 'block',
  },
  cardDelete: {
    background: 'transparent',
    border: 'none',
    color: '#64748b',
    cursor: 'pointer',
    padding: '4px',
    borderRadius: '4px',
    transition: 'all 0.2s',
    '&:hover': {
      color: '#fca5a5',
      background: 'rgba(239, 68, 68, 0.1)',
    },
  },
  cardControls: {
    borderTop: '1px solid rgba(255,255,255,0.04)',
    paddingTop: '12px',
  },
  switchRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  controlLabel: {
    fontSize: '13px',
    color: 'var(--text-secondary)',
  },
  sensorPreview: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '13px',
    color: 'var(--text-secondary)',
    strong: {
      color: 'var(--text-primary)',
    },
  },
  cardFooter: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    borderTop: '1px solid rgba(255,255,255,0.04)',
    paddingTop: '12px',
    fontSize: '12px',
  },
  statusGroup: {
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
  },
  statusText: {
    color: 'var(--text-secondary)',
    fontWeight: 500,
  },
  seenText: {
    color: 'var(--text-muted)',
  },
  detailHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    borderBottom: '1px solid var(--border-glass)',
    paddingBottom: '16px',
  },
  detailTitle: {
    fontSize: '22px',
    color: 'var(--text-primary)',
    fontWeight: 600,
    marginBottom: '4px',
  },
  closeBtn: {
    padding: '6px 12px',
    fontSize: '12px',
  },
  detailSection: {
    borderBottom: '1px solid rgba(255,255,255,0.06)',
    paddingBottom: '20px',
  },
  sectionHeading: {
    fontSize: '14px',
    fontWeight: 600,
    color: 'var(--text-secondary)',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
    marginBottom: '12px',
  },
  detailControls: {
    background: 'var(--bg-glass)',
    padding: '16px',
    borderRadius: '12px',
    border: '1px solid var(--border-glass)',
  },
  ctrlActionRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontSize: '14px',
    span: { color: 'var(--text-secondary)' }
  },
  lightControlPack: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  sliderGroup: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '6px',
  },
  sliderLabelRow: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '13px',
    span: { color: 'var(--text-secondary)' },
    strong: { color: 'var(--text-primary)' },
  },
  slider: {
    width: '100%',
    cursor: 'pointer',
  },
  colorSelectorRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    fontSize: '13px',
    color: 'var(--text-secondary)',
  },
  colorCircles: {
    display: 'flex',
    gap: '8px',
  },
  colorCircleBtn: {
    width: '24px',
    height: '24px',
    borderRadius: '50%',
    border: '2px solid',
    cursor: 'pointer',
    boxShadow: '0 2px 8px rgba(0,0,0,0.3)',
    transition: 'transform 0.1s',
    '&:hover': {
      transform: 'scale(1.1)',
    },
  },
  thermostatPack: {
    padding: '6px 0',
  },
  tempGauge: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    span: { color: 'var(--text-secondary)', fontSize: '13px' }
  },
  tempControls: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
  },
  tempText: {
    fontSize: '18px',
    fontWeight: 700,
    color: 'var(--text-primary)',
  },
  sensorPack: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
  },
  sensorGauge: {
    background: 'var(--bg-glass)',
    padding: '12px',
    borderRadius: '8px',
    textAlign: 'center' as const,
    border: '1px solid var(--border-glass)',
  },
  gaugeLabel: {
    display: 'block',
    fontSize: '11px',
    color: 'var(--text-muted)',
    textTransform: 'uppercase' as const,
  },
  gaugeVal: {
    fontSize: '20px',
    color: 'var(--text-primary)',
    fontWeight: 700,
    marginTop: '4px',
    display: 'block',
  },
  credentialsBlock: {
    background: 'var(--bg-glass)',
    borderRadius: '8px',
    padding: '14px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '10px',
  },
  credRow: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '4px',
    span: { fontSize: '11px', color: 'var(--text-muted)', textTransform: 'uppercase' as const },
  },
  credValue: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-glass)',
    padding: '8px 12px',
    borderRadius: '6px',
    fontFamily: 'monospace',
    fontSize: '12px',
    color: 'var(--text-primary)',
    gap: '10px',
  },
  copyBtn: {
    background: 'transparent',
    border: 'none',
    color: 'var(--text-secondary)',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
  },
  codeHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '8px',
  },
  tabs: {
    display: 'flex',
    gap: '12px',
  },
  tabBtn: {
    background: 'transparent',
    border: 'none',
    fontSize: '11px',
    fontWeight: 600,
    textTransform: 'uppercase' as const,
    cursor: 'pointer',
  },
  codeSnippetBox: {
    position: 'relative' as const,
  },
  codeCopy: {
    position: 'absolute' as const,
    top: '8px',
    right: '8px',
    padding: '4px 8px',
    fontSize: '11px',
    display: 'flex',
    alignItems: 'center',
    gap: '4px',
    zIndex: 1,
  },
  preCode: {
    background: '#040209',
    padding: '16px',
    borderRadius: '8px',
    fontSize: '11px',
    overflowX: 'auto' as const,
    color: '#a9b1d6',
    fontFamily: 'Consolas, Monaco, monospace',
    lineHeight: '1.5',
    maxHeight: '220px',
  },
  modalOverlay: {
    position: 'fixed' as const,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(0,0,0,0.6)',
    backdropFilter: 'blur(4px)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
    padding: '20px',
  },
  modalCard: {
    width: '100%',
    maxWidth: '400px',
    padding: '30px',
  },
  modalTitle: {
    fontSize: '20px',
    fontWeight: 600,
    color: 'var(--text-primary)',
    marginBottom: '20px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '6px',
  },
  label: {
    fontSize: '11px',
    fontWeight: 600,
    color: 'var(--text-secondary)',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  select: {
    appearance: 'none' as const,
    backgroundImage: `url("data:image/svg+xml;utf8,<svg fill='white' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>")`,
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'right 12px center',
    backgroundSize: '20px',
    paddingRight: '36px',
  },
  modalButtons: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '12px',
    marginTop: '10px',
  },
};

// ── OTA Firmware Upload Panel ────────────────────────────────────────────────
function OtaPanel({ apiBase, token, deviceId }: { apiBase: string; token: string; deviceId: string }) {
  const [otaList, setOtaList] = useState<any[]>([]);
  const [version, setVersion] = useState('');
  const [uploading, setUploading] = useState(false);
  const [otaMsg, setOtaMsg] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);

  const fetchOta = async () => {
    try {
      const res = await fetch(`${apiBase}/api/v1/devices/${deviceId}/ota/list`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      if (res.ok) setOtaList(await res.json());
    } catch (_) {}
  };

  useEffect(() => { fetchOta(); }, [deviceId]);

  const handleUpload = async () => {
    const file = fileRef.current?.files?.[0];
    if (!file || !version) { setOtaMsg('Select a .bin file and enter a version.'); return; }
    setUploading(true);
    setOtaMsg('');
    try {
      const buf = await file.arrayBuffer();
      const res = await fetch(`${apiBase}/api/v1/devices/${deviceId}/ota/upload?version=${version}`, {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/octet-stream',
        },
        body: buf,
      });
      const data = await res.json();
      if (res.ok) {
        setOtaMsg(`✅ ${data.message}`);
        setVersion('');
        if (fileRef.current) fileRef.current.value = '';
        fetchOta();
      } else {
        setOtaMsg(`❌ ${data.error}`);
      }
    } catch (e) {
      setOtaMsg('❌ Upload failed.');
    }
    setUploading(false);
  };

  return (
    <div style={{ marginTop: 16, padding: '16px 20px', background: 'rgba(168,85,247,0.04)', border: '1px solid rgba(168,85,247,0.15)', borderRadius: 12 }}>
      <h3 style={{ fontSize: 13, fontWeight: 700, color: '#a855f7', marginBottom: 12, display: 'flex', alignItems: 'center', gap: 6 }}>
        <Upload size={14} /> OTA Firmware Updates
      </h3>

      <div style={{ display: 'flex', gap: 8, flexWrap: 'wrap' as const, marginBottom: 8 }}>
        <input
          type="text"
          className="input-field"
          placeholder="Version (e.g. 1.0.1)"
          value={version}
          onChange={(e) => setVersion(e.target.value)}
          style={{ width: 140, fontSize: 12, padding: '6px 10px' }}
        />
        <input type="file" accept=".bin" ref={fileRef} style={{ display: 'none' }} />
        <button
          className="btn btn-secondary"
          style={{ fontSize: 12, padding: '6px 12px' }}
          onClick={() => fileRef.current?.click()}
        >
          Choose .bin
        </button>
        <button
          className="btn"
          style={{ fontSize: 12, padding: '6px 12px', background: uploading ? 'rgba(99,102,241,0.3)' : 'rgba(99,102,241,0.8)', color: '#fff', border: 'none', borderRadius: 8, cursor: uploading ? 'not-allowed' : 'pointer' }}
          onClick={handleUpload}
          disabled={uploading}
        >
          {uploading ? 'Uploading...' : 'Upload Firmware'}
        </button>
      </div>

      {otaMsg && <p style={{ fontSize: 11, color: '#94a3b8', marginBottom: 8 }}>{otaMsg}</p>}

      {otaList.length > 0 && (
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 11 }}>
          <thead>
            <tr style={{ borderBottom: '1px solid rgba(255,255,255,0.06)', textAlign: 'left' }}>
              <th style={{ padding: '4px 8px', color: '#94a3b8' }}>Version</th>
              <th style={{ padding: '4px 8px', color: '#94a3b8' }}>Uploaded</th>
              <th style={{ padding: '4px 8px', color: '#94a3b8' }}>Download</th>
            </tr>
          </thead>
          <tbody>
            {otaList.map((fw: any) => (
              <tr key={fw.id} style={{ borderBottom: '1px solid rgba(255,255,255,0.03)' }}>
                <td style={{ padding: '4px 8px', color: '#a855f7', fontWeight: 700 }}>v{fw.version}</td>
                <td style={{ padding: '4px 8px', color: '#94a3b8' }}>{new Date(fw.uploadedAt).toLocaleDateString()}</td>
                <td style={{ padding: '4px 8px' }}>
                  <a
                    href={`${apiBase}/api/v1/devices/ota/download/${fw.filename}`}
                    style={{ color: '#6366f1', display: 'flex', alignItems: 'center', gap: 4, textDecoration: 'none', fontSize: 11 }}
                  >
                    <Download size={10} /> {fw.filename}
                  </a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}
