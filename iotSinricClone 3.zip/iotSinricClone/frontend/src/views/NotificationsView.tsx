import { useState, useEffect } from 'react';
import { Bell, CheckCircle2, AlertTriangle, Trash2 } from 'lucide-react';

export default function NotificationsView({ apiBase, token, wsMessage }: { apiBase: string, token: string, wsMessage: any }) {
  const [notifications, setNotifications] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchNotifications();
  }, [token]);

  useEffect(() => {
    if (wsMessage && wsMessage.type === 'notification') {
      setNotifications(prev => [wsMessage.notification, ...prev]);
    }
  }, [wsMessage]);

  const fetchNotifications = async () => {
    try {
      const res = await fetch(`${apiBase}/api/v1/notifications`, {
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      setNotifications(data);
    } catch (e) {
      console.error('Failed to fetch notifications', e);
    } finally {
      setLoading(false);
    }
  };

  const markAsRead = async (id: string) => {
    try {
      await fetch(`${apiBase}/api/v1/notifications/${id}/read`, {
        method: 'PATCH',
        headers: { Authorization: `Bearer ${token}` }
      });
      setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
    } catch (e) {
      console.error(e);
    }
  };

  const clearAll = async () => {
    try {
      await fetch(`${apiBase}/api/v1/notifications`, {
        method: 'DELETE',
        headers: { Authorization: `Bearer ${token}` }
      });
      setNotifications([]);
    } catch (e) {
      console.error(e);
    }
  };

  if (loading) return <div className="p-8 text-slate-400">Loading notifications...</div>;

  return (
    <div className="flex flex-col h-full animate-fade-in" style={{ padding: '24px' }}>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <Bell className="text-pink-400" />
            Notifications
          </h1>
          <p className="text-slate-400 mt-1">System alerts and automation events.</p>
        </div>

        {notifications.length > 0 && (
          <button className="btn btn-secondary text-red-400 hover:text-red-300 hover:border-red-400/50" onClick={clearAll}>
            <Trash2 size={16} /> Clear All
          </button>
        )}
      </div>

      <div className="flex-1 overflow-y-auto">
        {notifications.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-slate-500 bg-slate-900/50 rounded-2xl border border-slate-700/50">
            <Bell size={48} className="mb-4 opacity-20" />
            <p>You have no new notifications.</p>
          </div>
        ) : (
          <div className="space-y-3">
            {notifications.map(n => (
              <div 
                key={n.id} 
                className={`glass-panel p-4 flex gap-4 transition-all ${n.read ? 'opacity-60' : 'border-pink-500/30 shadow-[0_0_15px_rgba(236,72,153,0.1)]'}`}
              >
                <div className={`p-3 rounded-full h-fit ${n.type === 'DEVICE_OFFLINE' ? 'bg-red-500/20 text-red-400' : 'bg-indigo-500/20 text-indigo-400'}`}>
                  {n.type === 'DEVICE_OFFLINE' ? <AlertTriangle size={20} /> : <Bell size={20} />}
                </div>
                
                <div className="flex-1">
                  <div className="flex justify-between items-start">
                    <h3 className={`font-semibold ${n.read ? 'text-slate-300' : 'text-white'}`}>{n.title}</h3>
                    <span className="text-xs text-slate-500">{new Date(n.createdAt).toLocaleString()}</span>
                  </div>
                  <p className="text-sm text-slate-400 mt-1">{n.message}</p>
                </div>

                {!n.read && (
                  <button 
                    onClick={() => markAsRead(n.id)}
                    className="self-center p-2 text-slate-400 hover:text-green-400 transition-colors"
                    title="Mark as read"
                  >
                    <CheckCircle2 size={20} />
                  </button>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
