import { Activity, Radio, Wifi, AlertTriangle, Plus } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Link } from 'react-router-dom';

export default function HomeView({ devices, telemetry: _telemetry }: { devices: any[]; telemetry?: any }) {
  const onlineCount = devices.filter(d => d.status === 'ONLINE').length;
  const offlineCount = devices.length - onlineCount;

  // Mock chart data for now
  const chartData = [
    { time: '10:00', events: 12 },
    { time: '11:00', events: 19 },
    { time: '12:00', events: 15 },
    { time: '13:00', events: 25 },
    { time: '14:00', events: 22 },
    { time: '15:00', events: 30 },
  ];

  return (
    <div style={styles.container} className="animate-fade-in">
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Dashboard Overview</h1>
          <p style={styles.subtitle}>Welcome back to CasaMesh.</p>
        </div>
        <Link to="/devices" className="btn btn-primary" style={{ display: 'inline-flex', alignItems: 'center', gap: '8px', textDecoration: 'none' }}>
          <Plus size={18} />
          Add Device
        </Link>
      </div>

      {/* Metrics Row */}
      <div style={styles.metricsGrid}>
        <div className="glass-panel" style={styles.metricCard}>
          <div style={styles.metricHeader}>
            <span style={styles.metricTitle}>Total Devices</span>
            <Radio size={16} color="#6366f1" />
          </div>
          <div style={styles.metricValue}>{devices.length}</div>
        </div>

        <div className="glass-panel" style={styles.metricCard}>
          <div style={styles.metricHeader}>
            <span style={styles.metricTitle}>Online Devices</span>
            <Wifi size={16} color="#10b981" />
          </div>
          <div style={{ ...styles.metricValue, color: '#10b981' }}>{onlineCount}</div>
        </div>

        <div className="glass-panel" style={styles.metricCard}>
          <div style={styles.metricHeader}>
            <span style={styles.metricTitle}>Offline / Errors</span>
            <AlertTriangle size={16} color="var(--color-danger)" />
          </div>
          <div style={{ ...styles.metricValue, color: offlineCount > 0 ? 'var(--color-danger)' : 'var(--text-primary)' }}>{offlineCount}</div>
        </div>

        <div className="glass-panel" style={styles.metricCard}>
          <div style={styles.metricHeader}>
            <span style={styles.metricTitle}>Active Automations</span>
            <Activity size={16} color="#a855f7" />
          </div>
          <div style={styles.metricValue}>0</div>
        </div>
      </div>

      <div style={styles.mainGrid}>
        {/* Chart Section */}
        <div className="glass-panel" style={styles.chartCard}>
          <h2 style={styles.cardTitle}>System Activity</h2>
          <div style={{ height: '300px', marginTop: '20px' }}>
            <ResponsiveContainer width="100%" height="100%">
              <LineChart data={chartData}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--border-glass)" vertical={false} />
                <XAxis dataKey="time" stroke="var(--text-secondary)" fontSize={12} tickLine={false} axisLine={false} />
                <YAxis stroke="var(--text-secondary)" fontSize={12} tickLine={false} axisLine={false} />
                <Tooltip 
                  contentStyle={{ backgroundColor: 'var(--bg-surface)', border: '1px solid var(--border-glass)', borderRadius: '8px' }}
                  itemStyle={{ color: 'var(--text-primary)' }}
                />
                <Line type="monotone" dataKey="events" stroke="var(--color-primary)" strokeWidth={3} dot={{ r: 4, fill: 'var(--color-primary)' }} activeDot={{ r: 6 }} />
              </LineChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Quick Feed / Recent Events */}
        <div className="glass-panel" style={styles.feedCard}>
          <h2 style={styles.cardTitle}>Recent Events</h2>
          <div style={styles.feedList}>
            {devices.slice(0, 5).map(d => (
              <div key={d.id} style={styles.feedItem}>
                <div style={{ ...styles.feedDot, background: d.status === 'ONLINE' ? 'var(--color-success)' : 'var(--text-muted)' }} />
                <div style={styles.feedContent}>
                  <span style={styles.feedText}><strong>{d.name}</strong> is {d.status.toLowerCase()}</span>
                  <span style={styles.feedTime}>{new Date(d.lastSeen).toLocaleTimeString()}</span>
                </div>
              </div>
            ))}
            {devices.length === 0 && (
              <p style={{ color: 'var(--text-secondary)', fontSize: '13px', textAlign: 'center', marginTop: '40px' }}>No devices registered yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '32px',
    maxWidth: '1400px',
    margin: '0 auto',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '32px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    color: 'var(--text-primary)',
    marginBottom: '8px',
  },
  subtitle: {
    color: 'var(--text-secondary)',
    fontSize: '15px',
  },
  metricsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
    gap: '24px',
    marginBottom: '32px',
  },
  metricCard: {
    padding: '24px',
    display: 'flex',
    flexDirection: 'column' as const,
  },
  metricHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '16px',
  },
  metricTitle: {
    fontSize: '13px',
    fontWeight: 600,
    color: 'var(--text-secondary)',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  metricValue: {
    fontSize: '36px',
    fontWeight: 700,
    color: 'var(--text-primary)',
  },
  mainGrid: {
    display: 'grid',
    gridTemplateColumns: '2fr 1fr',
    gap: '24px',
    '@media (max-width: 1024px)': {
      gridTemplateColumns: '1fr',
    }
  },
  chartCard: {
    padding: '24px',
  },
  feedCard: {
    padding: '24px',
    display: 'flex',
    flexDirection: 'column' as const,
  },
  cardTitle: {
    fontSize: '16px',
    fontWeight: 600,
    color: 'var(--text-primary)',
    marginBottom: '16px',
  },
  feedList: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
    flex: 1,
  },
  feedItem: {
    display: 'flex',
    gap: '12px',
    alignItems: 'flex-start',
    paddingBottom: '16px',
    borderBottom: '1px solid var(--border-glass)',
  },
  feedDot: {
    width: '8px',
    height: '8px',
    borderRadius: '50%',
    marginTop: '6px',
  },
  feedContent: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '4px',
  },
  feedText: {
    fontSize: '13px',
    color: 'var(--text-primary)',
  },
  feedTime: {
    fontSize: '11px',
    color: 'var(--text-secondary)',
  }
};
