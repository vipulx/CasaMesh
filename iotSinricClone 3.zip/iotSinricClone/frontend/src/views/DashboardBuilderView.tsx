import { useState, useEffect } from 'react';
// @ts-ignore
import { Responsive, WidthProvider } from 'react-grid-layout';
import 'react-grid-layout/css/styles.css';
import 'react-resizable/css/styles.css';
import { Plus, Save, Trash2, Settings, LayoutGrid } from 'lucide-react';

const ResponsiveGridLayout = WidthProvider(Responsive);

export default function DashboardBuilderView({ apiBase, token }: { apiBase: string, token: string }) {
  const [dashboards, setDashboards] = useState<any[]>([]);
  const [currentDashboard, setCurrentDashboard] = useState<any>(null);
  
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchData();
  }, [token]);

  const fetchData = async () => {
    try {
      setLoading(true);
      const [dashRes] = await Promise.all([
        fetch(`${apiBase}/api/v1/dashboards`, { headers: { Authorization: `Bearer ${token}` } })
      ]);
      const dashes = await dashRes.json();
      
      setDashboards(dashes);

      if (dashes.length > 0) {
        setCurrentDashboard(dashes[0]);
      } else {
        createNewDashboard();
      }
    } catch (e) {
      console.error('Failed to load dashboard data', e);
    } finally {
      setLoading(false);
    }
  };

  const createNewDashboard = async () => {
    try {
      const res = await fetch(`${apiBase}/api/v1/dashboards`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: 'New Dashboard', widgets: [] })
      });
      const dash = await res.json();
      setDashboards([...dashboards, dash]);
      setCurrentDashboard(dash);
    } catch (e) {
      console.error(e);
    }
  };

  const saveDashboard = async () => {
    if (!currentDashboard) return;
    try {
      await fetch(`${apiBase}/api/v1/dashboards/${currentDashboard.id}`, {
        method: 'PUT',
        headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: currentDashboard.name, widgets: currentDashboard.widgets })
      });
      alert('Dashboard saved!');
    } catch (e) {
      console.error(e);
      alert('Failed to save');
    }
  };

  const onLayoutChange = (layout: any) => {
    if (!currentDashboard) return;
    
    // Merge layout changes into widgets
    const updatedWidgets = currentDashboard.widgets.map((w: any) => {
      const l = layout.find((item: any) => item.i === w.id);
      if (l) {
        const layoutObj = JSON.parse(w.layout || '{}');
        return { ...w, layout: JSON.stringify({ ...layoutObj, x: l.x, y: l.y, w: l.w, h: l.h }) };
      }
      return w;
    });

    setCurrentDashboard({ ...currentDashboard, widgets: updatedWidgets });
  };

  const addWidget = () => {
    if (!currentDashboard) return;
    const newWidget = {
      id: `new-${Date.now()}`,
      type: 'TEXT',
      title: 'New Widget',
      layout: JSON.stringify({ x: 0, y: Infinity, w: 2, h: 2 }),
      config: '{}'
    };
    setCurrentDashboard({
      ...currentDashboard,
      widgets: [...currentDashboard.widgets, newWidget]
    });
  };

  const removeWidget = (id: string) => {
    if (!currentDashboard) return;
    setCurrentDashboard({
      ...currentDashboard,
      widgets: currentDashboard.widgets.filter((w: any) => w.id !== id)
    });
  };

  if (loading) return <div className="p-8 text-slate-400">Loading Dashboards...</div>;
  if (!currentDashboard) return <div className="p-8 text-slate-400">No dashboards found.</div>;

  const layout = currentDashboard.widgets.map((w: any) => {
    const l = JSON.parse(w.layout || '{"x":0,"y":0,"w":2,"h":2}');
    return { i: w.id, x: l.x, y: l.y, w: l.w, h: l.h };
  });

  return (
    <div className="flex flex-col h-full animate-fade-in" style={{ padding: '24px' }}>
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-2xl font-bold text-white flex items-center gap-3">
            <LayoutGrid className="text-indigo-400" />
            Dashboard Builder
          </h1>
          <p className="text-slate-400 mt-1">Design your custom IoT control center.</p>
        </div>

        <div className="flex gap-3">
          <select 
            className="input-field" 
            value={currentDashboard.id}
            onChange={(e) => {
              const d = dashboards.find(dash => dash.id === e.target.value);
              if (d) setCurrentDashboard(d);
            }}
          >
            {dashboards.map(d => (
              <option key={d.id} value={d.id}>{d.name}</option>
            ))}
          </select>
          <button className="btn btn-secondary" onClick={createNewDashboard}>
            <Plus size={16} /> New
          </button>
          <button className="btn btn-primary" onClick={saveDashboard}>
            <Save size={16} /> Save Layout
          </button>
        </div>
      </div>

      <div className="flex items-center justify-between mb-4 bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
        <div className="flex items-center gap-4">
          <input 
            type="text" 
            className="input-field font-semibold text-lg bg-transparent border-none px-0 focus:ring-0 w-64"
            value={currentDashboard.name}
            onChange={(e) => setCurrentDashboard({ ...currentDashboard, name: e.target.value })}
            placeholder="Dashboard Name"
          />
        </div>
        <button className="btn btn-secondary text-sm py-1" onClick={addWidget}>
          <Plus size={14} /> Add Widget
        </button>
      </div>

      <div className="flex-1 bg-slate-900/50 rounded-2xl border border-slate-700/50 overflow-y-auto p-4 relative">
        <ResponsiveGridLayout
          className="layout"
          layouts={{ lg: layout }}
          breakpoints={{ lg: 1200, md: 996, sm: 768, xs: 480, xxs: 0 }}
          cols={{ lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 }}
          rowHeight={100}
          onLayoutChange={onLayoutChange}
          isDraggable={true}
          isResizable={true}
          margin={[16, 16]}
        >
          {currentDashboard.widgets.map((widget: any) => (
            <div key={widget.id} className="glass-panel group overflow-hidden relative cursor-move">
              <div className="flex items-center justify-between p-3 border-b border-slate-700/50 bg-slate-800/80">
                <h3 className="font-medium text-sm text-slate-200">{widget.title}</h3>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button className="text-slate-400 hover:text-white p-1"><Settings size={14} /></button>
                  <button className="text-red-400 hover:text-red-300 p-1" onMouseDown={() => removeWidget(widget.id)}><Trash2 size={14} /></button>
                </div>
              </div>
              <div className="p-4 flex flex-col items-center justify-center h-[calc(100%-45px)] text-slate-400">
                {widget.type === 'TEXT' && <span>Static Text Widget</span>}
                {widget.type === 'SWITCH' && <span>Switch Control</span>}
                {widget.type === 'CHART' && <span>Telemetry Chart</span>}
                {widget.type === 'GAUGE' && <span>Telemetry Gauge</span>}
              </div>
            </div>
          ))}
        </ResponsiveGridLayout>
      </div>
    </div>
  );
}
