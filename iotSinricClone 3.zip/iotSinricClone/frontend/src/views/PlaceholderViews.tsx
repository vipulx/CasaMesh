import { Layout, BarChart3, Bell } from 'lucide-react';

export function DashboardBuilderView() {
  return (
    <div style={styles.container}>
      <div style={styles.content}>
        <div style={styles.iconBox}><Layout size={40} color="#a855f7" /></div>
        <h1 style={styles.title}>Dashboard Builder</h1>
        <p style={styles.subtitle}>Drag-and-drop widget builder is coming soon in Phase 4.</p>
        <button style={styles.btn} disabled>Create Dashboard</button>
      </div>
    </div>
  );
}

export function AnalyticsView() {
  return (
    <div style={styles.container}>
      <div style={styles.content}>
        <div style={styles.iconBox}><BarChart3 size={40} color="#3b82f6" /></div>
        <h1 style={styles.title}>Advanced Analytics</h1>
        <p style={styles.subtitle}>Historical data, device uptime, and deep telemetry reports coming soon.</p>
      </div>
    </div>
  );
}

export function NotificationsView() {
  return (
    <div style={styles.container}>
      <div style={styles.content}>
        <div style={styles.iconBox}><Bell size={40} color="#f59e0b" /></div>
        <h1 style={styles.title}>Alerts & Notifications</h1>
        <p style={styles.subtitle}>Unified alert pipeline for Push, Email, and Webhooks coming soon.</p>
      </div>
    </div>
  );
}

const styles = {
  container: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '80vh',
    padding: '32px',
  },
  content: {
    textAlign: 'center' as const,
    background: 'rgba(255,255,255,0.02)',
    border: '1px dashed rgba(255,255,255,0.1)',
    padding: '60px 40px',
    borderRadius: '24px',
    maxWidth: '500px',
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
  },
  iconBox: {
    width: '80px',
    height: '80px',
    borderRadius: '20px',
    background: 'rgba(255,255,255,0.05)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: '24px',
  },
  title: {
    fontSize: '24px',
    fontWeight: 700,
    color: '#fff',
    marginBottom: '12px',
  },
  subtitle: {
    color: '#94a3b8',
    fontSize: '15px',
    lineHeight: 1.6,
    marginBottom: '24px',
  },
  btn: {
    background: 'rgba(255,255,255,0.05)',
    color: '#64748b',
    border: 'none',
    padding: '12px 24px',
    borderRadius: '8px',
    fontSize: '14px',
    fontWeight: 600,
    cursor: 'not-allowed',
  }
};
