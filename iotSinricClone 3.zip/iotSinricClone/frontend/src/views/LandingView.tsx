import { Link } from 'react-router-dom';
import { Cpu, Lock, Zap, Activity, Grid, Play } from 'lucide-react';

export default function LandingView() {
  return (
    <div style={styles.container}>
      {/* Navbar */}
      <nav style={styles.navbar}>
        <div style={styles.brand}>
          <Cpu size={24} color="#a855f7" />
          <span style={styles.brandText}>Casa<span>Mesh</span></span>
        </div>
        <div style={styles.navLinks}>
          <a href="#features" style={styles.link}>Features</a>
          <a href="#devices" style={styles.link}>Devices</a>
          <a href="#integrations" style={styles.link}>Integrations</a>
          <a href="#pricing" style={styles.link}>Pricing</a>
          <Link to="/login" style={styles.loginBtn}>Login</Link>
          <Link to="/signup" style={styles.signupBtn}>Get Started</Link>
        </div>
      </nav>

      {/* Hero Section */}
      <section style={styles.hero}>
        <div style={styles.heroContent}>
          <h1 style={styles.heroTitle}>Build, Connect, <br/>Control Everything.</h1>
          <p style={styles.heroSubtitle}>
            CasaMesh is a production-grade, self-hosted IoT cloud. Connect ESP32 devices, build realtime dashboards, and automate your home or enterprise effortlessly.
          </p>
          <div style={styles.heroCta}>
            <Link to="/signup" style={styles.primaryBtn}><Play size={18} /> Start Self-Hosting Free</Link>
            <a href="#docs" style={styles.secondaryBtn}>Read the Docs</a>
          </div>
        </div>
        <div style={styles.heroGraphic}>
          <div style={styles.mockup}>
            {/* Abstract UI representation */}
            <div style={styles.mockupHeader}></div>
            <div style={styles.mockupBody}>
              <div style={styles.mockupCard}></div>
              <div style={styles.mockupCard}></div>
              <div style={styles.mockupCardLarge}></div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" style={styles.section}>
        <h2 style={styles.sectionTitle}>Everything you need to build IoT</h2>
        <div style={styles.grid}>
          <FeatureCard 
            icon={Zap} 
            title="Real-time Telemetry" 
            desc="Sub-millisecond latency powered by WebSockets and native MQTT support."
          />
          <FeatureCard 
            icon={Grid} 
            title="Dashboard Builder" 
            desc="Drag-and-drop widgets to build custom interfaces for your devices."
          />
          <FeatureCard 
            icon={Activity} 
            title="Automation Engine" 
            desc="Powerful IF/THEN rules to trigger events, webhooks, and alerts."
          />
          <FeatureCard 
            icon={Lock} 
            title="Enterprise Security" 
            desc="JWT device provisioning, OTA updates, and secure NVS credential storage."
          />
        </div>
      </section>

      {/* Device Support */}
      <section id="devices" style={styles.sectionDark}>
        <h2 style={styles.sectionTitle}>Any Device, Anywhere</h2>
        <p style={styles.sectionSubtitle}>Drop-in SDKs and templates for the world's most popular maker hardware.</p>
        <div style={styles.deviceList}>
          <span style={styles.deviceTag}>ESP32</span>
          <span style={styles.deviceTag}>ESP8266</span>
          <span style={styles.deviceTag}>Raspberry Pi</span>
          <span style={styles.deviceTag}>Arduino</span>
          <span style={styles.deviceTag}>Linux</span>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" style={styles.section}>
        <h2 style={styles.sectionTitle}>Simple, Transparent Pricing</h2>
        <div style={styles.pricingGrid}>
          <div style={styles.priceCard}>
            <h3>Community</h3>
            <div style={styles.price}>$0<span>/mo</span></div>
            <ul style={styles.priceFeatures}>
              <li>Unlimited Local Devices</li>
              <li>Self-Hosted (Docker)</li>
              <li>Basic Automations</li>
              <li>Community Support</li>
            </ul>
            <Link to="/signup" style={styles.outlineBtn}>Deploy Now</Link>
          </div>
          <div style={{...styles.priceCard, ...styles.priceCardPro}}>
            <h3>Cloud Pro</h3>
            <div style={styles.price}>$9<span>/mo</span></div>
            <ul style={styles.priceFeatures}>
              <li>Fully Managed Cloud</li>
              <li>Alexa & Google Home</li>
              <li>Advanced Analytics</li>
              <li>Priority Support</li>
            </ul>
            <Link to="/signup" style={styles.primaryBtn}>Start 14-Day Trial</Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer style={styles.footer}>
        <div style={styles.footerBrand}>CasaMesh © {new Date().getFullYear()}</div>
        <div style={styles.footerLinks}>
          <a href="#">Blog</a>
          <a href="#">Documentation</a>
          <a href="#">Contact</a>
          <a href="#">GitHub</a>
        </div>
      </footer>
    </div>
  );
}

function FeatureCard({ icon: Icon, title, desc }: any) {
  return (
    <div style={styles.featureCard}>
      <div style={styles.featureIcon}><Icon size={24} color="#a855f7" /></div>
      <h3 style={styles.featureTitle}>{title}</h3>
      <p style={styles.featureDesc}>{desc}</p>
    </div>
  );
}

const styles = {
  container: {
    minHeight: '100vh',
    background: 'var(--bg-base)',
    color: 'var(--text-primary)',
    fontFamily: 'Inter, system-ui, sans-serif',
    overflowX: 'hidden' as const,
  },
  navbar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '20px 5%',
    background: 'var(--bg-glass)',
    backdropFilter: 'blur(10px)',
    position: 'sticky' as const,
    top: 0,
    zIndex: 100,
    borderBottom: '1px solid var(--border-glass)',
  },
  brand: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  },
  brandText: {
    fontSize: '22px',
    fontWeight: 800,
    letterSpacing: '-0.5px',
    span: { color: '#a855f7' }
  },
  navLinks: {
    display: 'flex',
    alignItems: 'center',
    gap: '24px',
  },
  link: {
    color: 'var(--text-secondary)',
    textDecoration: 'none',
    fontSize: '14px',
    fontWeight: 500,
    transition: 'color 0.2s',
  },
  loginBtn: {
    color: 'var(--text-primary)',
    textDecoration: 'none',
    fontSize: '14px',
    fontWeight: 600,
  },
  signupBtn: {
    background: 'var(--color-primary)',
    color: '#fff',
    padding: '8px 16px',
    borderRadius: '8px',
    textDecoration: 'none',
    fontSize: '14px',
    fontWeight: 600,
  },
  hero: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '100px 5%',
    minHeight: '80vh',
    gap: '40px',
    background: 'radial-gradient(circle at 80% 20%, rgba(168, 85, 247, 0.15) 0%, transparent 40%)',
  },
  heroContent: {
    flex: 1,
    maxWidth: '600px',
  },
  heroTitle: {
    fontSize: '64px',
    fontWeight: 800,
    lineHeight: 1.1,
    marginBottom: '24px',
  },
  heroSubtitle: {
    fontSize: '18px',
    color: 'var(--text-secondary)',
    lineHeight: 1.6,
    marginBottom: '40px',
  },
  heroCta: {
    display: 'flex',
    gap: '16px',
  },
  primaryBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    background: 'var(--color-primary)',
    color: '#fff',
    padding: '14px 28px',
    borderRadius: '10px',
    textDecoration: 'none',
    fontSize: '16px',
    fontWeight: 600,
    transition: 'transform 0.2s',
  },
  secondaryBtn: {
    display: 'flex',
    alignItems: 'center',
    background: 'var(--btn-secondary-bg)',
    color: 'var(--text-primary)',
    padding: '14px 28px',
    borderRadius: '10px',
    textDecoration: 'none',
    fontSize: '16px',
    fontWeight: 600,
    border: '1px solid var(--border-glass)',
  },
  outlineBtn: {
    display: 'block',
    textAlign: 'center' as const,
    padding: '12px',
    borderRadius: '8px',
    border: '1px solid var(--border-glass)',
    color: 'var(--text-primary)',
    textDecoration: 'none',
    fontWeight: 600,
  },
  heroGraphic: {
    flex: 1,
    display: 'flex',
    justifyContent: 'center',
  },
  mockup: {
    width: '100%',
    maxWidth: '500px',
    height: '400px',
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-glass)',
    borderRadius: '16px',
    boxShadow: 'var(--shadow-card)',
    display: 'flex',
    flexDirection: 'column' as const,
    overflow: 'hidden',
  },
  mockupHeader: {
    height: '24px',
    background: 'var(--btn-secondary-bg)',
    borderBottom: '1px solid var(--border-glass)',
  },
  mockupBody: {
    padding: '20px',
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
  },
  mockupCard: {
    height: '100px',
    background: 'var(--btn-secondary-bg)',
    borderRadius: '12px',
  },
  mockupCardLarge: {
    gridColumn: '1 / -1',
    height: '150px',
    background: 'var(--color-primary-glow)',
    borderRadius: '12px',
    border: '1px solid var(--color-primary)',
  },
  section: {
    padding: '100px 5%',
  },
  sectionDark: {
    padding: '100px 5%',
    background: 'var(--bg-surface)',
    textAlign: 'center' as const,
  },
  sectionTitle: {
    fontSize: '36px',
    fontWeight: 700,
    textAlign: 'center' as const,
    marginBottom: '16px',
    color: 'var(--text-primary)',
  },
  sectionSubtitle: {
    textAlign: 'center' as const,
    color: 'var(--text-secondary)',
    marginBottom: '40px',
    fontSize: '18px',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(250px, 1fr))',
    gap: '24px',
    marginTop: '60px',
  },
  featureCard: {
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-glass)',
    padding: '32px',
    borderRadius: '16px',
  },
  featureIcon: {
    width: '48px',
    height: '48px',
    background: 'var(--color-primary-glow)',
    borderRadius: '12px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: '20px',
  },
  featureTitle: {
    fontSize: '20px',
    fontWeight: 600,
    marginBottom: '12px',
  },
  featureDesc: {
    color: 'var(--text-secondary)',
    lineHeight: 1.6,
  },
  deviceList: {
    display: 'flex',
    justifyContent: 'center',
    flexWrap: 'wrap' as const,
    gap: '16px',
  },
  deviceTag: {
    padding: '12px 24px',
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-glass)',
    borderRadius: '30px',
    fontSize: '16px',
    fontWeight: 600,
  },
  pricingGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))',
    gap: '32px',
    maxWidth: '800px',
    margin: '40px auto 0',
  },
  priceCard: {
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-glass)',
    padding: '40px',
    borderRadius: '24px',
    display: 'flex',
    flexDirection: 'column' as const,
  },
  priceCardPro: {
    background: 'var(--color-primary-glow)',
    border: '1px solid var(--color-primary)',
    transform: 'scale(1.05)',
  },
  price: {
    fontSize: '48px',
    fontWeight: 800,
    margin: '20px 0',
    span: { fontSize: '16px', color: 'var(--text-secondary)', fontWeight: 500 }
  },
  priceFeatures: {
    listStyle: 'none',
    padding: 0,
    margin: '0 0 32px 0',
    color: 'var(--text-primary)',
    lineHeight: 2,
  },
  footer: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '40px 5%',
    borderTop: '1px solid var(--border-glass)',
    color: 'var(--text-secondary)',
  },
  footerBrand: {
    fontWeight: 600,
  },
  footerLinks: {
    display: 'flex',
    gap: '24px',
    a: { color: 'var(--text-secondary)', textDecoration: 'none' }
  }
};
