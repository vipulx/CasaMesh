import React, { useState, useEffect, useRef } from 'react';
import { Routes, Route, Navigate, useLocation } from 'react-router-dom';

import { Login, Signup } from './views/AuthViews';
import DashboardView from './views/DashboardView'; // This is actually the Devices Grid
import AutomationsView from './views/AutomationsView';
import IntegrationsView from './views/IntegrationsView';
import AdminConsoleView from './views/AdminConsoleView';
import LandingView from './views/LandingView';
import HomeView from './views/HomeView';
import DashboardBuilderView from './views/DashboardBuilderView';
import NotificationsView from './views/NotificationsView';
import { AnalyticsView } from './views/PlaceholderViews';
import AppLayout from './components/AppLayout';

// Determine API and WebSocket paths dynamically to support both local Vite and Cloudflare Tunnels
const API_BASE = window.location.port === '5173'
  ? `http://${window.location.hostname}:3001`
  : window.location.origin;

const isSsl = window.location.protocol === 'https:';
const wsProto = isSsl ? 'wss' : 'ws';
const WS_BASE = window.location.port === '5173'
  ? `${wsProto}://${window.location.hostname}:3001`
  : `${wsProto}://${window.location.host}`;

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('casamesh_token'));
  const [user, setUser] = useState<any>(JSON.parse(localStorage.getItem('casamesh_user') || 'null'));
  const [devices, setDevices] = useState<any[]>([]);

  // WebSockets States
  const [wsMessage, setWsMessage] = useState<any>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };

  const handleAuthSuccess = (newToken: string, newUser: any) => {
    localStorage.setItem('casamesh_token', newToken);
    localStorage.setItem('casamesh_user', JSON.stringify(newUser));
    setToken(newToken);
    setUser(newUser);
  };

  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const urlToken = params.get('token');
    if (urlToken) {
      // Clear URL
      window.history.replaceState({}, document.title, window.location.pathname);
      
      // Fetch user profile
      fetch(`${API_BASE}/api/v1/auth/me`, {
        headers: { 'Authorization': `Bearer ${urlToken}` }
      })
      .then(res => res.json())
      .then(data => {
        if (data.user) {
          handleAuthSuccess(urlToken, data.user);
        }
      })
      .catch(err => console.error('OAuth login failed', err));
    }
  }, []);

  const handleSignOut = () => {
    localStorage.removeItem('casamesh_token');
    localStorage.removeItem('casamesh_user');
    setToken(null);
    setUser(null);
    setDevices([]);
    setWsConnected(false);
    if (wsRef.current) wsRef.current.close();
  };

  // Fetch list of registered devices
  const fetchDevices = async () => {
    if (!token) return;
    try {
      const res = await fetch(`${API_BASE}/api/v1/devices`, { headers });
      const data = await res.json();
      if (res.ok) {
        setDevices(data);
      }
    } catch (e) {
      console.error('Fetch devices error:', e);
    }
  };

  useEffect(() => {
    if (token) {
      fetchDevices();
    }
  }, [token]);

  // Handle Client WebSockets link for real-time telemetry updates
  useEffect(() => {
    if (!token) return;

    let reconnectTimeout: any;

    const connectWs = () => {
      const wsUrl = `${WS_BASE}/api/v1/ws/client?token=${token}`;
      console.log(`[WebSocket] Connecting client: ${wsUrl}...`);
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('[WebSocket] Client channel established successfully.');
        setWsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          setWsMessage(msg);
        } catch (e) {}
      };

      ws.onclose = () => {
        console.log('[WebSocket] Connection closed. Reconnecting in 5s...');
        setWsConnected(false);
        reconnectTimeout = setTimeout(connectWs, 5000);
      };

      ws.onerror = (err) => {
        console.error('[WebSocket] Error caught:', err);
        ws.close();
      };
    };

    connectWs();

    return () => {
      clearTimeout(reconnectTimeout);
      if (wsRef.current) {
        wsRef.current.onclose = null; // Prevent reconnect
        wsRef.current.close();
      }
    };
  }, [token]);

  // Helper to publish control data packets
  const sendWsMessage = (msg: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
    }
  };

  // Require Auth Wrapper Component
  const RequireAuth = ({ children }: { children: React.JSX.Element }) => {
    const location = useLocation();
    if (!token) {
      return <Navigate to="/login" state={{ from: location }} replace />;
    }
    return children;
  };

  // Redirect if already authenticated
  const IfGuest = ({ children }: { children: React.JSX.Element }) => {
    if (token) {
      return <Navigate to="/dashboard" replace />;
    }
    return children;
  };

  return (
    <Routes>
      {/* Public Landing Page */}
      <Route path="/" element={<IfGuest><LandingView /></IfGuest>} />
      
      {/* Auth Pages */}
      <Route path="/login" element={
        <IfGuest>
          <div style={authWrapperStyle}>
            <Login apiBase={API_BASE} onAuthSuccess={handleAuthSuccess} />
          </div>
        </IfGuest>
      } />
      <Route path="/signup" element={
        <IfGuest>
          <div style={authWrapperStyle}>
            <Signup apiBase={API_BASE} onAuthSuccess={handleAuthSuccess} onToggleAuth={() => {}} />
          </div>
        </IfGuest>
      } />

      {/* Protected Routes Wrapper */}
      <Route element={<RequireAuth><AppLayout user={user} wsConnected={wsConnected} onSignOut={handleSignOut} /></RequireAuth>}>
        <Route path="/dashboard" element={<HomeView devices={devices} telemetry={wsMessage} />} />
        
        {/* The old DashboardView is actually the Devices Grid */}
        <Route path="/devices" element={
          <DashboardView 
            apiBase={API_BASE} 
            token={token!} 
            devices={devices} 
            setDevices={setDevices} 
            wsMessage={wsMessage}
            sendWsMessage={sendWsMessage}
          />
        } />
        
        <Route path="/automations" element={<AutomationsView apiBase={API_BASE} token={token!} devices={devices} />} />
        <Route path="/integrations" element={<IntegrationsView user={user} />} />
        <Route path="/dashboards" element={<DashboardBuilderView apiBase={API_BASE} token={token!} />} />
        <Route path="/analytics" element={<AnalyticsView />} />
        <Route path="/alerts" element={<NotificationsView apiBase={API_BASE} token={token!} wsMessage={wsMessage} />} />

        {/* Admin only */}
        {user?.role === 'ADMIN' && (
          <Route path="/settings" element={<AdminConsoleView apiBase={API_BASE} token={token!} />} />
        )}

        {/* Fallback for protected routes */}
        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  );
}

const authWrapperStyle = {
  display: 'flex',
  flexDirection: 'column' as const,
  alignItems: 'center',
  justifyContent: 'center',
  minHeight: '100vh',
  background: '#0a0814',
  position: 'relative' as const,
  zIndex: 1,
};
