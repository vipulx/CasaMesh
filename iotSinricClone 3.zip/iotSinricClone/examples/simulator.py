#!/usr/bin/env python3
"""
CasaMesh Device Simulator — Python
Simulates a provisioned ESP32/RPi device with full production flow:
  1. Load cached tokens OR call /provision on first boot
  2. Connect via secure WebSocket using JWT Bearer token
  3. Auto-reconnect with exponential backoff
  4. Send periodic sensor telemetry
  5. Handle incoming commands and send state confirmations

Usage:
  pip install websockets aiohttp
  python3 simulator.py

  # Override server (e.g. local dev):
  CASAMESH_API=http://localhost:3002 python3 simulator.py
"""

import asyncio
import json
import os
import random
import time
import websockets
import aiohttp

# ── Configuration ─────────────────────────────────────────────────────────────
# Copy these from your CasaMesh dashboard → Device → Credentials panel
DEVICE_ID       = os.environ.get("DEVICE_ID",       "PASTE_DEVICE_ID_HERE")
PROVISION_TOKEN = os.environ.get("PROVISION_TOKEN",  "PASTE_PROVISION_TOKEN_HERE")

API_BASE  = os.environ.get("CASAMESH_API",  "https://iot.siddhart.qzz.io")
WS_BASE   = os.environ.get("CASAMESH_WS",   "wss://iot.siddhart.qzz.io")
WS_PATH   = "/api/v1/ws/device"

CONFIG_FILE = f"casamesh_{DEVICE_ID[:8]}.json"

# ── Token State ───────────────────────────────────────────────────────────────
access_token  = None
refresh_token = None


# ── Config Persistence ────────────────────────────────────────────────────────
def save_config():
    with open(CONFIG_FILE, "w") as f:
        json.dump({"access_token": access_token, "refresh_token": refresh_token}, f)
    print(f"[Config] Tokens cached to {CONFIG_FILE}")


def load_config() -> bool:
    global access_token, refresh_token
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE) as f:
                cfg = json.load(f)
            access_token  = cfg.get("access_token")
            refresh_token = cfg.get("refresh_token")
            if access_token:
                print(f"[Config] Loaded cached tokens from {CONFIG_FILE}")
                return True
        except Exception:
            pass
    return False


# ── Provisioning ──────────────────────────────────────────────────────────────
async def provision():
    """Exchange provision_token for access + refresh tokens. Runs only once."""
    global access_token, refresh_token
    print(f"[Provision] Provisioning device {DEVICE_ID[:12]}...")
    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{API_BASE}/api/v1/devices/provision",
            json={"device_id": DEVICE_ID, "provision_token": PROVISION_TOKEN},
            ssl=API_BASE.startswith("https"),
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                access_token  = data["access_token"]
                refresh_token = data["refresh_token"]
                save_config()
                print(f"[Provision] ✅ Provisioned as: {data['device_name']} ({data['device_type']})")
            else:
                text = await resp.text()
                raise RuntimeError(f"[Provision] ❌ Failed ({resp.status}): {text}")


async def do_refresh():
    """Rotate expired access token using refresh_token."""
    global access_token, refresh_token
    print("[Auth] Refreshing tokens...")
    async with aiohttp.ClientSession() as session:
        async with session.post(
            f"{API_BASE}/api/v1/devices/refresh",
            json={"refresh_token": refresh_token},
            ssl=API_BASE.startswith("https"),
        ) as resp:
            if resp.status == 200:
                data = await resp.json()
                access_token  = data["access_token"]
                refresh_token = data["refresh_token"]
                save_config()
                print("[Auth] ✅ Tokens refreshed.")
                return True
            else:
                print("[Auth] ❌ Refresh failed — will re-provision.")
                return False


# ── Telemetry ─────────────────────────────────────────────────────────────────
async def telemetry_loop(ws):
    """Sends periodic telemetry in the standardized CasaMesh format."""
    while True:
        payload = {
            "type":        "telemetry",
            "temperature": round(20.0 + random.uniform(-3, 5), 1),
            "humidity":    round(50.0 + random.uniform(-10, 10), 1),
            "timestamp":   int(time.time()),
        }
        await ws.send(json.dumps(payload))
        print(f"[Telemetry] Sent: temp={payload['temperature']}°C, hum={payload['humidity']}%")
        await asyncio.sleep(10)


# ── Command Handler ───────────────────────────────────────────────────────────
async def handle_message(ws, raw: str):
    """Handle commands from the cloud dashboard."""
    try:
        msg = json.loads(raw)
    except json.JSONDecodeError:
        return

    msg_type = msg.get("type", "")

    if msg_type == "command":
        cmd     = msg.get("command", "")
        value   = msg.get("value")
        req_id  = msg.get("request_id", "")
        print(f"[Command] {cmd} = {value}  (req_id={req_id})")

        # ── Simulate physical hardware action here ────────────────────────────
        # e.g. GPIO.output(17, GPIO.HIGH if value else GPIO.LOW)

        # Send standardized state confirmation
        confirm = {
            "type":       "state",
            "request_id": req_id,
            "success":    True,
        }
        await ws.send(json.dumps(confirm))
        print(f"[State] Confirmation sent for {cmd}")

    elif msg_type == "ping":
        await ws.send(json.dumps({"type": "pong"}))


# ── Main Connection Loop ──────────────────────────────────────────────────────
async def connect():
    ws_url = f"{WS_BASE}{WS_PATH}?token={access_token}"
    reconnect_delay = 5
    print(f"\n[WS] Connecting to {WS_BASE}{WS_PATH}")

    while True:
        try:
            async for ws in websockets.connect(ws_url, ping_interval=15, ping_timeout=10):
                print("[WS] ✅ Connected to CasaMesh cloud!")
                reconnect_delay = 5

                tasks = [asyncio.create_task(telemetry_loop(ws))]
                try:
                    async for raw in ws:
                        await handle_message(ws, raw)
                except websockets.ConnectionClosed as e:
                    print(f"[WS] Disconnected: {e.code} — {e.reason}")
                finally:
                    for t in tasks:
                        t.cancel()

        except websockets.exceptions.InvalidStatusCode as e:
            if e.status_code == 403:
                print("[WS] 403 Forbidden — attempting token refresh...")
                if not await do_refresh():
                    await provision()
                ws_url = f"{WS_BASE}{WS_PATH}?token={access_token}"
            else:
                print(f"[WS] Error: {e}")

        except Exception as e:
            print(f"[WS] Connection error: {e}")

        print(f"[WS] Reconnecting in {reconnect_delay}s...")
        await asyncio.sleep(reconnect_delay)
        reconnect_delay = min(reconnect_delay * 2, 60)


# ── Entry Point ───────────────────────────────────────────────────────────────
async def main():
    print("=" * 60)
    print("  CasaMesh Device Simulator")
    print(f"  Device ID: {DEVICE_ID[:12]}...")
    print(f"  Server:    {API_BASE}")
    print("=" * 60)

    if DEVICE_ID == "PASTE_DEVICE_ID_HERE":
        print("\n⚠️  Please set DEVICE_ID and PROVISION_TOKEN at the top of this script")
        print("   or via environment variables: DEVICE_ID=... PROVISION_TOKEN=... python3 simulator.py")
        return

    if not load_config():
        await provision()

    await connect()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        print("\n[Simulator] Stopped.")
