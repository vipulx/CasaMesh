import { WebSocket } from 'ws';
import { prisma } from '../services/db';
import { evaluateRules } from '../automations/ruleEngine';
import { publishHADiscovery } from '../mqtt/mqttBroker';
import { sendMqttCommand } from '../mqtt/mqttBroker';
import { redisPublisher, redisSubscriber } from '../redis/pubsub';

class SocketManager {
  // Map of User ID -> Array of WebSocket connections for browser dashboards
  private userSockets: Map<string, WebSocket[]> = new Map();
  // Map of Device ID -> Active WebSocket connection for physical device
  private deviceSockets: Map<string, WebSocket> = new Map();

  constructor() {
    redisSubscriber.subscribe('casamesh:user_events');
    redisSubscriber.on('message', (channel, message) => {
      if (channel === 'casamesh:user_events') {
        try {
          const data = JSON.parse(message);
          this.localSendToUser(data.userId, data.payload);
        } catch (e) {
          console.error('[SocketManager] Redis parse error', e);
        }
      }
    });
  }

  // DASHBOARD CLIENTS REGISTER
  public addUserSocket(userId: string, ws: WebSocket) {
    const sockets = this.userSockets.get(userId) || [];
    sockets.push(ws);
    this.userSockets.set(userId, sockets);
    console.log(`[SocketManager] Dashboard client connected for user ${userId}. Total: ${sockets.length}`);
  }

  public removeUserSocket(userId: string, ws: WebSocket) {
    const sockets = this.userSockets.get(userId) || [];
    const index = sockets.indexOf(ws);
    if (index > -1) {
      sockets.splice(index, 1);
      if (sockets.length === 0) {
        this.userSockets.delete(userId);
      } else {
        this.userSockets.set(userId, sockets);
      }
    }
    console.log(`[SocketManager] Dashboard client disconnected for user ${userId}. Remaining: ${sockets.length}`);
  }

  // PHYSICAL DEVICES REGISTER
  public async addDeviceSocket(deviceId: string, ws: WebSocket, userId: string) {
    // If there is an existing socket, close it
    const existing = this.deviceSockets.get(deviceId);
    if (existing) {
      try {
        existing.close();
      } catch (e) {}
    }

    this.deviceSockets.set(deviceId, ws);
    console.log(`[SocketManager] Physical device ${deviceId} connected.`);

    try {
      // Set device state to ONLINE in DB
      const device = await prisma.device.update({
        where: { id: deviceId },
        data: { status: 'ONLINE', lastSeen: new Date() },
      });

      publishHADiscovery(device);

      // Broadcast update to user's dashboards
      this.sendToUser(userId, {
        type: 'deviceConnectionChanged',
        deviceId,
        status: 'ONLINE',
      });

      // Create log entry
      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_CONNECTED',
          details: `Device ${deviceId} is online`,
        },
      });
    } catch (err) {
      console.error('[SocketManager] DB update error on device connect:', err);
    }
  }

  public async removeDeviceSocket(deviceId: string, userId: string) {
    this.deviceSockets.delete(deviceId);
    console.log(`[SocketManager] Physical device ${deviceId} disconnected.`);

    try {
      // Set device state to OFFLINE in DB
      await prisma.device.update({
        where: { id: deviceId },
        data: { status: 'OFFLINE', lastSeen: new Date() },
      });

      // Broadcast update to user's dashboards
      this.sendToUser(userId, {
        type: 'deviceConnectionChanged',
        deviceId,
        status: 'OFFLINE',
      });

      // Create notification
      const deviceObj = await prisma.device.findUnique({ where: { id: deviceId } });
      const notification = await prisma.notification.create({
        data: {
          userId,
          type: 'DEVICE_OFFLINE',
          title: 'Device Offline',
          message: `Device ${deviceObj?.name || deviceId} went offline.`,
        }
      });

      // Broadcast notification
      this.sendToUser(userId, {
        type: 'notification',
        notification,
      });

      // Create log entry
      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_DISCONNECTED',
          details: `Device ${deviceId} went offline`,
        },
      });
    } catch (err) {
      console.error('[SocketManager] DB update error on device disconnect:', err);
    }
  }

  // SEND CONTROL PAYLOAD FROM DASHBOARD -> PHYSICAL DEVICE
  public sendToDevice(deviceId: string, payload: any): boolean {
    // Try sending over WebSocket first
    const ws = this.deviceSockets.get(deviceId);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(payload));
      return true;
    }
    // Fallback to sending over MQTT broker
    return sendMqttCommand(deviceId, payload);
  }

  // BROADCAST STATE UPDATE -> USER DASHBOARD CLIENTS (Global via Redis)
  public sendToUser(userId: string, payload: any) {
    // Publish to Redis so all instances can send to their local connected users
    redisPublisher.publish('casamesh:user_events', JSON.stringify({ userId, payload }));
  }

  // Send to user but only on this specific Node instance
  private localSendToUser(userId: string, payload: any) {
    const sockets = this.userSockets.get(userId);
    if (sockets) {
      const message = JSON.stringify(payload);
      for (const ws of sockets) {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(message);
        }
      }
    }
  }

  // HANDLE DEVICE MESSAGES — supports both standardized and legacy formats
  public async handleDeviceMessage(deviceId: string, userId: string, rawMessage: string) {
    try {
      const msg = JSON.parse(rawMessage);

      // ── Standardized format: { type, ... } ──────────────────────────────────
      // type = "telemetry" | "state" | "heartbeat" | "pong"
      // Legacy format: { action, properties } — also handled below

      const msgType   = msg.type   || msg.action;   // support both
      const properties = msg.reportedState || msg.properties || {};

      // Heartbeat / pong acknowledgement
      if (msgType === 'heartbeat' || msgType === 'pong') {
        return; // acknowledged; keep-alive handled by WS ping/pong
      }

      await prisma.systemLog.create({
        data: { action: 'MESSAGE_PROCESSED', details: `Device ${deviceId}: ${rawMessage.slice(0, 200)}` },
      });

      // ── Telemetry ────────────────────────────────────────────────────────────
      if (msgType === 'telemetry') {
        // Standardized: { type:"telemetry", temperature: 24.5, humidity: 65 }
        // Legacy:       { action:"telemetry", properties: { temperature: 24.5 } }
        const readings = Object.keys(properties).length > 0
          ? properties
          : (({ type, action, timestamp, ...rest }: any) => rest)(msg); // strip meta fields

        const device = await prisma.device.findUnique({ where: { id: deviceId } });
        if (!device) return;

        for (const [key, val] of Object.entries(readings)) {
          await prisma.telemetry.create({ data: { deviceId, property: key, value: String(val) } });
          await evaluateRules(deviceId, key, val, userId);
        }

        this.sendToUser(userId, { type: 'deviceTelemetry', deviceId, reportedState: readings });
      }

      // ── State Confirmation ───────────────────────────────────────────────────
      else if (msgType === 'state' || msgType === 'updateState') {
        const stateProps = Object.keys(properties).length > 0 ? properties : msg;
        const device = await prisma.device.findUnique({ where: { id: deviceId } });
        if (!device) return;

        let currentProps: any = {};
        try { currentProps = JSON.parse(device.reportedState); } catch (_) {}

        const updatedProps = { ...currentProps, ...stateProps };
        await prisma.device.update({
          where: { id: deviceId },
          data: { reportedState: JSON.stringify(updatedProps), lastSeen: new Date() },
        });

        for (const [key, val] of Object.entries(stateProps)) {
          await evaluateRules(deviceId, key, val, userId);
        }

        this.sendToUser(userId, { type: 'deviceStateChanged', deviceId, reportedState: updatedProps });
      }
    } catch (err) {
      console.error('[SocketManager] Error handling device message:', err);
    }
  }

  // HANDLE FRONTEND DASHBOARD MESSAGES
  public async handleDashboardMessage(userId: string, rawMessage: string) {
    try {
      const msg = JSON.parse(rawMessage);
      const { action, deviceId, property, value } = msg;

      if (action === 'control' && deviceId && property && value !== undefined) {
        const cmd = property === 'powerState'         ? 'setPowerState'
                  : property === 'brightness'         ? 'setBrightness'
                  : property === 'targetTemperature'  ? 'setTargetTemperature'
                  : property === 'lockState'          ? 'setLockState'
                  : property === 'speed'              ? 'setSpeed'
                  : `set${property.charAt(0).toUpperCase()}${property.slice(1)}`;

        const device = await prisma.device.findFirst({ where: { id: deviceId, userId } });

        if (device) {
          // Standardized command packet
          const command = {
            type:       'command',
            request_id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
            device:     deviceId,
            command:    cmd,
            value,
            timestamp:  Date.now(),
          };

          const isOnline = this.sendToDevice(deviceId, command);

          // Update shadow state in DB
          let currentDesired: any = {};
          try { currentDesired = JSON.parse(device.desiredState); } catch (_) {}
          const updatedDesired = { ...currentDesired, [property]: value };

          await prisma.device.update({ where: { id: deviceId }, data: { desiredState: JSON.stringify(updatedDesired) } });
          this.sendToUser(userId, { type: 'deviceStateChanged', deviceId, desiredState: updatedDesired });

          await prisma.systemLog.create({
            data: {
              action: 'MESSAGE_PROCESSED',
              details: `Dashboard → ${device.name}: ${cmd}=${value} (online=${isOnline})`,
            },
          });
        }
      }
    } catch (err) {
      console.error('[SocketManager] Error handling dashboard message:', err);
    }
  }
}

export const socketManager = new SocketManager();
