import { Request, Response } from 'express';
import { prisma } from '../services/db';

export const getNotifications = async (req: Request, res: Response) => {
  const user = (req as any).user;
  try {
    const notifications = await prisma.notification.findMany({
      where: { userId: user.id },
      orderBy: { createdAt: 'desc' },
      take: 50,
    });
    res.json(notifications);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch notifications' });
  }
};

export const markAsRead = async (req: Request, res: Response): Promise<any> => {
  const { id } = req.params;
  const user = (req as any).user;

  try {
    const existing = await prisma.notification.findFirst({ where: { id, userId: user.id } });
    if (!existing) return res.status(404).json({ error: 'Not found' });

    const updated = await prisma.notification.update({
      where: { id },
      data: { read: true }
    });
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update notification' });
  }
};

export const clearAll = async (req: Request, res: Response) => {
  const user = (req as any).user;
  try {
    await prisma.notification.deleteMany({ where: { userId: user.id } });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to clear notifications' });
  }
};
