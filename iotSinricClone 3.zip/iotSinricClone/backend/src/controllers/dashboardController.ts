import { Request, Response } from 'express';
import { prisma } from '../services/db';

export const getDashboards = async (req: Request, res: Response) => {
  const user = (req as any).user;
  try {
    const dashboards = await prisma.dashboard.findMany({
      where: { userId: user.id },
      include: { widgets: true },
    });
    res.json(dashboards);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch dashboards' });
  }
};

export const createDashboard = async (req: Request, res: Response) => {
  const user = (req as any).user;
  const { name, widgets } = req.body;
  try {
    const dashboard = await prisma.dashboard.create({
      data: {
        name: name || 'New Dashboard',
        userId: user.id,
        widgets: {
          create: widgets || []
        }
      },
      include: { widgets: true },
    });
    res.status(201).json(dashboard);
  } catch (error) {
    res.status(500).json({ error: 'Failed to create dashboard' });
  }
};

export const updateDashboard = async (req: Request, res: Response): Promise<any> => {
  const { id } = req.params;
  const { name, widgets } = req.body;
  const user = (req as any).user;

  try {
    const existing = await prisma.dashboard.findFirst({ where: { id, userId: user.id } });
    if (!existing) return res.status(404).json({ error: 'Not found' });

    // Update name
    if (name) {
      await prisma.dashboard.update({ where: { id }, data: { name } });
    }

    // Update widgets
    if (widgets && Array.isArray(widgets)) {
      // Simplest way: delete all existing widgets and recreate them
      await prisma.widget.deleteMany({ where: { dashboardId: id } });
      
      const newWidgets = widgets.map((w: any) => ({
        ...w,
        dashboardId: id,
        id: undefined, // let Prisma generate new UUIDs, or keep existing if safe
      }));

      for (const widget of newWidgets) {
        await prisma.widget.create({ data: widget });
      }
    }

    const updated = await prisma.dashboard.findUnique({ where: { id }, include: { widgets: true } });
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: 'Failed to update dashboard' });
  }
};

export const deleteDashboard = async (req: Request, res: Response): Promise<any> => {
  const { id } = req.params;
  const user = (req as any).user;

  try {
    const existing = await prisma.dashboard.findFirst({ where: { id, userId: user.id } });
    if (!existing) return res.status(404).json({ error: 'Not found' });

    await prisma.dashboard.delete({ where: { id } });
    res.json({ success: true });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete dashboard' });
  }
};
