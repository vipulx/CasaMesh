import { Response, Request } from 'express';
import { prisma } from '../services/db';
import { AuthenticatedRequest } from '../middleware/auth';
import { v4 as uuidv4 } from 'uuid';
import jwt from 'jsonwebtoken';
import path from 'path';
import fs from 'fs';
import semver from 'semver';

const JWT_SECRET = process.env.JWT_SECRET || 'casamesh_super_secret_key_12345!';
// Short-lived device access token (24h)
const DEVICE_TOKEN_EXPIRES = '24h';
// Long-lived refresh token (30 days)
const DEVICE_REFRESH_EXPIRES = '30d';

// Directory to store OTA firmware binaries
const FIRMWARE_DIR = path.join(process.cwd(), 'firmware');
if (!fs.existsSync(FIRMWARE_DIR)) {
  fs.mkdirSync(FIRMWARE_DIR, { recursive: true });
}

// ─── Helper ────────────────────────────────────────────────────────────────

const getDefaultState = (type: string) => {
  switch (type.toUpperCase()) {
    case 'SWITCH': return JSON.stringify({ powerState: 'Off' });
    case 'LIGHT': return JSON.stringify({ powerState: 'Off', brightness: 100, color: { r: 255, g: 255, b: 255 } });
    case 'THERMOSTAT': return JSON.stringify({ temperature: 21.0, targetTemperature: 22.0, thermostatMode: 'auto' });
    case 'SENSOR': return JSON.stringify({ temperature: 22.0, humidity: 45.0 });
    case 'FAN': return JSON.stringify({ powerState: 'Off', speed: 1 });
    case 'LOCK': return JSON.stringify({ lockState: 'Locked' });
    default: return JSON.stringify({});
  }
};

function issueDeviceTokens(deviceId: string, userId: string) {
  const accessToken = jwt.sign(
    { deviceId, userId, type: 'device_access' },
    JWT_SECRET,
    { expiresIn: DEVICE_TOKEN_EXPIRES }
  );
  const refreshToken = jwt.sign(
    { deviceId, userId, type: 'device_refresh' },
    JWT_SECRET,
    { expiresIn: DEVICE_REFRESH_EXPIRES }
  );
  return { accessToken, refreshToken };
}

// ─── Device CRUD ───────────────────────────────────────────────────────────

export async function createDevice(req: AuthenticatedRequest, res: Response) {
  const { name, type } = req.body;
  const userId = req.user?.id;
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  if (!name || !type) return res.status(400).json({ error: 'Device name and type are required' });

  const validTypes = ['SWITCH', 'LIGHT', 'THERMOSTAT', 'SENSOR', 'FAN', 'LOCK', 'CUSTOM'];
  if (!validTypes.includes(type.toUpperCase())) {
    return res.status(400).json({ error: `Invalid device type. Allowed: ${validTypes.join(', ')}` });
  }

  try {
    const device = await prisma.device.create({
      data: {
        name,
        type: type.toUpperCase(),
        key: uuidv4(),
        secret: uuidv4(),
        provisionToken: uuidv4(),
        desiredState: getDefaultState(type),
        reportedState: getDefaultState(type),
        userId,
      },
    });

    await prisma.systemLog.create({
      data: { action: 'DEVICE_CREATED', details: `Device "${device.name}" (${device.type}) registered by user ${userId}` },
    });

    return res.status(201).json(device);
  } catch (err) {
    console.error('Create device error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getDevices(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const devices = await prisma.device.findMany({ where: { userId }, orderBy: { name: 'asc' } });
    return res.status(200).json(devices);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getDevice(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const device = await prisma.device.findFirst({ where: { id, userId } });
    if (!device) return res.status(404).json({ error: 'Device not found' });
    return res.status(200).json(device);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function deleteDevice(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const device = await prisma.device.findFirst({ where: { id, userId } });
    if (!device) return res.status(404).json({ error: 'Device not found' });

    // Delete associated firmware files
    const firmwares = await prisma.otaFirmware.findMany({ where: { deviceId: id } });
    for (const fw of firmwares) {
      const fwPath = path.join(FIRMWARE_DIR, fw.filename);
      if (fs.existsSync(fwPath)) fs.unlinkSync(fwPath);
    }

    await prisma.device.delete({ where: { id } });
    await prisma.systemLog.create({
      data: { action: 'DEVICE_DELETED', details: `Device "${device.name}" deleted by user ${userId}` },
    });
    return res.status(200).json({ message: 'Device deleted successfully' });
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getDeviceTelemetry(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const device = await prisma.device.findFirst({ where: { id, userId } });
    if (!device) return res.status(404).json({ error: 'Device not found' });
    const telemetry = await prisma.telemetry.findMany({
      where: { deviceId: id },
      orderBy: { timestamp: 'desc' },
      take: limit,
    });
    return res.status(200).json(telemetry.reverse());
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// ─── Provisioning ──────────────────────────────────────────────────────────

/**
 * POST /api/v1/devices/provision
 * Public endpoint. Device sends { device_id, provision_token } on first boot.
 * Returns access_token + refresh_token. Stores no plain-text secret on the device.
 */
export async function provisionDevice(req: Request, res: Response) {
  const { device_id, provision_token } = req.body;

  if (!device_id || !provision_token) {
    return res.status(400).json({ error: 'device_id and provision_token are required' });
  }

  try {
    const device = await prisma.device.findFirst({
      where: { id: device_id, provisionToken: provision_token },
    });

    if (!device) {
      return res.status(403).json({ error: 'Invalid device credentials' });
    }

    const { accessToken, refreshToken } = issueDeviceTokens(device.id, device.userId);

    await prisma.systemLog.create({
      data: { action: 'DEVICE_PROVISIONED', details: `Device ${device.id} (${device.name}) provisioned via token` },
    });

    return res.status(200).json({
      access_token: accessToken,
      refresh_token: refreshToken,
      expires_in: 86400, // 24h in seconds
      device_id: device.id,
      device_name: device.name,
      device_type: device.type,
    });
  } catch (err) {
    console.error('Provision device error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

/**
 * POST /api/v1/devices/refresh
 * Device exchanges a refresh_token for a new access_token pair.
 */
export async function refreshDeviceToken(req: Request, res: Response) {
  const { refresh_token } = req.body;
  if (!refresh_token) return res.status(400).json({ error: 'refresh_token is required' });

  try {
    const payload = jwt.verify(refresh_token, JWT_SECRET) as any;
    if (payload.type !== 'device_refresh') {
      return res.status(403).json({ error: 'Invalid token type' });
    }

    const device = await prisma.device.findUnique({ where: { id: payload.deviceId } });
    if (!device) return res.status(403).json({ error: 'Device not found' });

    const { accessToken, refreshToken } = issueDeviceTokens(device.id, device.userId);

    return res.status(200).json({
      access_token: accessToken,
      refresh_token: refreshToken,
      expires_in: 86400,
    });
  } catch (err) {
    return res.status(403).json({ error: 'Invalid or expired refresh token' });
  }
}

// ─── OTA ───────────────────────────────────────────────────────────────────

/**
 * POST /api/v1/devices/:id/ota/upload
 * Protected: dashboard admin uploads a compiled .bin firmware file.
 * Body: raw binary (Content-Type: application/octet-stream), Query: ?version=1.0.1
 */
export async function uploadDeviceOta(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  const version = req.query.version as string;

  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  if (!version || !semver.valid(version)) {
    return res.status(400).json({ error: 'A valid semver version query param is required (e.g. ?version=1.0.1)' });
  }

  try {
    const device = await prisma.device.findFirst({ where: { id, userId } });
    if (!device) return res.status(404).json({ error: 'Device not found' });

    const filename = `${id}_${version}.bin`;
    const filepath = path.join(FIRMWARE_DIR, filename);

    // req.body is a Buffer when express.raw() is applied
    fs.writeFileSync(filepath, req.body);

    // Upsert OTA record for this version
    const existing = await prisma.otaFirmware.findFirst({ where: { deviceId: id, version } });
    if (existing) {
      await prisma.otaFirmware.update({ where: { id: existing.id }, data: { filename, uploadedAt: new Date() } });
    } else {
      await prisma.otaFirmware.create({ data: { deviceId: id, version, filename } });
    }

    await prisma.systemLog.create({
      data: { action: 'OTA_UPLOADED', details: `Firmware v${version} uploaded for device ${device.name} (${id})` },
    });

    return res.status(200).json({ message: `Firmware v${version} uploaded successfully`, filename });
  } catch (err) {
    console.error('OTA upload error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

/**
 * GET /api/v1/devices/ota/check
 * Public (device auth via JWT Bearer or device_id + provision_token in query).
 * Query: ?device_id=...&current_version=1.0.0
 */
export async function checkDeviceOta(req: Request, res: Response) {
  const { device_id, current_version } = req.query as Record<string, string>;

  if (!device_id || !current_version) {
    return res.status(400).json({ error: 'device_id and current_version are required' });
  }

  // Authenticate: Bearer token or provision_token
  let authenticatedDeviceId: string | null = null;

  const authHeader = req.headers.authorization;
  if (authHeader?.startsWith('Bearer ')) {
    try {
      const payload = jwt.verify(authHeader.slice(7), JWT_SECRET) as any;
      if (payload.deviceId === device_id) authenticatedDeviceId = payload.deviceId;
    } catch (_) {}
  }

  if (!authenticatedDeviceId) {
    return res.status(403).json({ error: 'Valid device Bearer token required' });
  }

  try {
    const firmwares = await prisma.otaFirmware.findMany({
      where: { deviceId: device_id },
      orderBy: { uploadedAt: 'desc' },
    });

    if (!firmwares.length) return res.status(200).json({ update_available: false });

    const latest = firmwares[0];
    if (semver.gt(latest.version, current_version)) {
      const baseUrl = `${req.protocol}://${req.get('host')}`;
      return res.status(200).json({
        update_available: true,
        version: latest.version,
        url: `${baseUrl}/api/v1/devices/ota/download/${latest.filename}`,
      });
    }

    return res.status(200).json({ update_available: false, current: current_version });
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

/**
 * GET /api/v1/devices/ota/download/:filename
 * Streams the compiled binary firmware to the device.
 */
export async function downloadDeviceOta(req: Request, res: Response) {
  const { filename } = req.params;
  // Sanitize: prevent path traversal
  const safeName = path.basename(filename);
  const filepath = path.join(FIRMWARE_DIR, safeName);

  if (!fs.existsSync(filepath)) {
    return res.status(404).json({ error: 'Firmware file not found' });
  }

  res.setHeader('Content-Type', 'application/octet-stream');
  res.setHeader('Content-Disposition', `attachment; filename="${safeName}"`);
  fs.createReadStream(filepath).pipe(res);
  return;
}

/**
 * GET /api/v1/devices/:id/ota/list
 * Protected: returns all uploaded firmware versions for a device.
 */
export async function listDeviceOta(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });
  try {
    const device = await prisma.device.findFirst({ where: { id, userId } });
    if (!device) return res.status(404).json({ error: 'Device not found' });
    const firmwares = await prisma.otaFirmware.findMany({
      where: { deviceId: id },
      orderBy: { uploadedAt: 'desc' },
    });
    return res.status(200).json(firmwares);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

// ─── Code Templates ────────────────────────────────────────────────────────

export async function getDeviceTemplate(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  const { type } = req.query;
  if (!userId) return res.status(401).json({ error: 'Unauthorized' });

  try {
    const device = await prisma.device.findFirst({ where: { id, userId } });
    if (!device) return res.status(404).json({ error: 'Device not found' });

    const host = req.headers.host || 'api.casamesh.io';
    const isSsl = req.secure || req.headers['x-forwarded-proto'] === 'https';
    const baseUrl = isSsl ? `https://${host}` : `http://${host}`;
    const wsUrl = `${isSsl ? 'wss' : 'ws'}://${host}/api/v1/ws/device`;

    if (type === 'python') {
      const pyCode = `#!/usr/bin/env python3
"""
CasaMesh Device SDK — Python
Device: ${device.name} (${device.type})
Generated: ${new Date().toISOString()}
"""

import asyncio
import json
import os
import websockets
import aiohttp
import random
import time

# ── Provisioning Config ──────────────────────────────────────────────────────
DEVICE_ID      = "${device.id}"
PROVISION_TOKEN = "${device.provisionToken}"   # Used only on first boot
API_BASE       = "${baseUrl}"
WS_URL         = "${wsUrl}"
CONFIG_FILE    = "casamesh_config.json"

# ── State ────────────────────────────────────────────────────────────────────
access_token  = None
refresh_token = None

# ── Token Management ─────────────────────────────────────────────────────────
async def provision():
    """Exchange provision_token for access + refresh tokens on first boot."""
    global access_token, refresh_token
    print("[CasaMesh] Provisioning device...")
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{API_BASE}/api/v1/devices/provision", json={
            "device_id": DEVICE_ID,
            "provision_token": PROVISION_TOKEN
        }) as resp:
            if resp.status != 200:
                raise RuntimeError(f"Provision failed: {resp.status} {await resp.text()}")
            data = await resp.json()
            access_token  = data["access_token"]
            refresh_token = data["refresh_token"]
            save_config()
            print(f"[CasaMesh] Provisioned as: {data['device_name']} ({data['device_type']})")

async def do_refresh():
    """Rotate tokens using the refresh_token."""
    global access_token, refresh_token
    async with aiohttp.ClientSession() as session:
        async with session.post(f"{API_BASE}/api/v1/devices/refresh", json={
            "refresh_token": refresh_token
        }) as resp:
            if resp.status == 200:
                data = await resp.json()
                access_token  = data["access_token"]
                refresh_token = data["refresh_token"]
                save_config()
                print("[CasaMesh] Tokens refreshed.")
            else:
                print("[CasaMesh] Refresh failed, re-provisioning...")
                await provision()

# ── Config Persistence ────────────────────────────────────────────────────────
def save_config():
    with open(CONFIG_FILE, "w") as f:
        json.dump({"access_token": access_token, "refresh_token": refresh_token}, f)

def load_config():
    global access_token, refresh_token
    if os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE) as f:
            cfg = json.load(f)
            access_token  = cfg.get("access_token")
            refresh_token = cfg.get("refresh_token")
            return True
    return False

# ── Device Logic ──────────────────────────────────────────────────────────────
async def send_telemetry(ws):
    """Periodically send sensor telemetry."""
    while True:
        payload = json.dumps({
            "type": "telemetry",
            "temperature": round(20.0 + random.uniform(-3, 5), 1),
            "humidity":    round(50.0 + random.uniform(-10, 10), 1),
            "timestamp":   int(time.time())
        })
        await ws.send(payload)
        print(f"[CasaMesh] Telemetry sent: {payload}")
        await asyncio.sleep(10)

async def handle_command(ws, msg: dict):
    """Process an incoming command and send a state confirmation."""
    cmd     = msg.get("command")
    value   = msg.get("value")
    req_id  = msg.get("request_id", "")
    print(f"[CasaMesh] Command received: {cmd} = {value}")

    # ─ Execute hardware action here ─
    # e.g. GPIO.output(PIN, GPIO.HIGH if value else GPIO.LOW)

    confirm = json.dumps({
        "type":       "state",
        "request_id": req_id,
        "success":    True,
        "reportedState": {cmd.replace("set", "").lower() if cmd else "state": value}
    })
    await ws.send(confirm)

async def connect():
    """Main connection loop with auto-reconnect."""
    headers = {"Authorization": f"Bearer {access_token}"}
    reconnect_delay = 5

    while True:
        try:
            async for ws in websockets.connect(WS_URL, additional_headers=headers):
                print("[CasaMesh] Connected to cloud!")
                reconnect_delay = 5  # Reset on successful connection
                tasks = [asyncio.create_task(send_telemetry(ws))]
                try:
                    async for raw in ws:
                        msg = json.loads(raw)
                        if msg.get("type") == "command":
                            await handle_command(ws, msg)
                        elif msg.get("type") == "ping":
                            await ws.send(json.dumps({"type": "pong"}))
                except websockets.ConnectionClosed:
                    print(f"[CasaMesh] Disconnected. Reconnecting in {reconnect_delay}s...")
                finally:
                    for t in tasks:
                        t.cancel()
        except Exception as e:
            print(f"[CasaMesh] Error: {e}. Retrying in {reconnect_delay}s...")
        await asyncio.sleep(reconnect_delay)
        reconnect_delay = min(reconnect_delay * 2, 60)

# ── Entry Point ───────────────────────────────────────────────────────────────
async def main():
    if not load_config():
        await provision()
    else:
        print("[CasaMesh] Loaded cached tokens.")
    await connect()

if __name__ == "__main__":
    asyncio.run(main())
`;
      return res.status(200).json({ code: pyCode });
    }

    // Arduino ESP32 template
    const ws_host = host.split(':')[0];
    const ws_port = host.split(':')[1] ? parseInt(host.split(':')[1]) : (isSsl ? 443 : 80);
    const inoCode = `/*
 * CasaMesh ESP32 Production Template
 * Device : ${device.name} (${device.type})
 * Generated: ${new Date().toISOString()}
 *
 * Libraries required:
 *   - ArduinoWebsockets  (by Gil Maimon) via Library Manager
 *   - ArduinoJson        via Library Manager
 *   - HTTPClient         (built-in ESP32)
 *   - Preferences        (built-in ESP32 NVS)
 */

#include <WiFi.h>
#include <HTTPClient.h>
#include <ArduinoWebsockets.h>
#include <ArduinoJson.h>
#include <Preferences.h>

using namespace websockets;

// ── WiFi ──────────────────────────────────────────────────────────────────────
const char* WIFI_SSID     = "YOUR_WIFI_SSID";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

// ── CasaMesh Identity ─────────────────────────────────────────────────────────
const char* DEVICE_ID       = "${device.id}";
const char* PROVISION_TOKEN = "${device.provisionToken}";  // Copy from dashboard ONCE
const char* API_BASE        = "${baseUrl}";
const char* WS_HOST         = "${ws_host}";
const int   WS_PORT         = ${ws_port};
const char* WS_PATH         = "/api/v1/ws/device";
const bool  USE_TLS         = ${isSsl ? 'true' : 'false'};

// ── NVS Token Storage ─────────────────────────────────────────────────────────
Preferences prefs;
String accessToken;
String refreshToken;

// ── WebSocket Client ──────────────────────────────────────────────────────────
WebsocketsClient wsClient;
bool wsConnected = false;
unsigned long lastHeartbeat = 0;
unsigned long lastTelemetry = 0;
const unsigned long HEARTBEAT_INTERVAL = 15000;
const unsigned long TELEMETRY_INTERVAL = 10000;

// ─────────────────────────────────────────────────────────────────────────────
// Token Management
// ─────────────────────────────────────────────────────────────────────────────
bool loadTokens() {
  prefs.begin("casamesh", true);
  accessToken  = prefs.getString("access_token",  "");
  refreshToken = prefs.getString("refresh_token", "");
  prefs.end();
  return accessToken.length() > 0;
}

void saveTokens(const String& at, const String& rt) {
  prefs.begin("casamesh", false);
  prefs.putString("access_token",  at);
  prefs.putString("refresh_token", rt);
  prefs.end();
}

bool provisionDevice() {
  Serial.println("[CasaMesh] Provisioning...");
  HTTPClient http;
  String url = String(API_BASE) + "/api/v1/devices/provision";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> body;
  body["device_id"]       = DEVICE_ID;
  body["provision_token"] = PROVISION_TOKEN;
  String bodyStr;
  serializeJson(body, bodyStr);

  int code = http.POST(bodyStr);
  if (code == 200) {
    StaticJsonDocument<512> resp;
    deserializeJson(resp, http.getString());
    accessToken  = resp["access_token"].as<String>();
    refreshToken = resp["refresh_token"].as<String>();
    saveTokens(accessToken, refreshToken);
    Serial.println("[CasaMesh] Provisioned OK.");
    http.end();
    return true;
  }
  Serial.printf("[CasaMesh] Provision failed: %d\\n", code);
  http.end();
  return false;
}

bool refreshTokens() {
  HTTPClient http;
  String url = String(API_BASE) + "/api/v1/devices/refresh";
  http.begin(url);
  http.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> body;
  body["refresh_token"] = refreshToken;
  String bodyStr;
  serializeJson(body, bodyStr);

  int code = http.POST(bodyStr);
  if (code == 200) {
    StaticJsonDocument<512> resp;
    deserializeJson(resp, http.getString());
    accessToken  = resp["access_token"].as<String>();
    refreshToken = resp["refresh_token"].as<String>();
    saveTokens(accessToken, refreshToken);
    Serial.println("[CasaMesh] Tokens refreshed.");
    http.end();
    return true;
  }
  http.end();
  return false;
}

// ─────────────────────────────────────────────────────────────────────────────
// OTA Check
// ─────────────────────────────────────────────────────────────────────────────
void checkOta(const char* currentVersion) {
  HTTPClient http;
  String url = String(API_BASE) + "/api/v1/devices/ota/check?device_id=" + DEVICE_ID + "&current_version=" + currentVersion;
  http.begin(url);
  http.addHeader("Authorization", "Bearer " + accessToken);
  int code = http.GET();
  if (code == 200) {
    StaticJsonDocument<512> resp;
    deserializeJson(resp, http.getString());
    if (resp["update_available"].as<bool>()) {
      Serial.printf("[OTA] Update available: v%s -> %s\\n", currentVersion, resp["version"].as<const char*>());
      // Implement esp_https_ota() here with resp["url"]
    }
  }
  http.end();
}

// ─────────────────────────────────────────────────────────────────────────────
// WebSocket Handlers
// ─────────────────────────────────────────────────────────────────────────────
void onWsMessage(WebsocketsMessage message) {
  StaticJsonDocument<512> doc;
  if (deserializeJson(doc, message.data()) != DeserializationError::Ok) return;

  const char* type = doc["type"] | "";

  if (strcmp(type, "command") == 0) {
    const char* cmd   = doc["command"]    | "";
    const char* reqId = doc["request_id"] | "";

    Serial.printf("[CasaMesh] Command: %s\\n", cmd);
    // ─ Handle hardware control here ─
    // e.g.: if (strcmp(cmd, "setPowerState") == 0) digitalWrite(RELAY_PIN, doc["value"].as<bool>());

    // Send state confirmation
    StaticJsonDocument<256> confirm;
    confirm["type"]       = "state";
    confirm["request_id"] = reqId;
    confirm["success"]    = true;
    String out;
    serializeJson(confirm, out);
    wsClient.send(out);

  } else if (strcmp(type, "ping") == 0) {
    wsClient.send("{\\"type\\":\\"pong\\"}");
  }
}

void onWsEvent(WebsocketsEvent event, String data) {
  if (event == WebsocketsEvent::ConnectionOpened) {
    wsConnected = true;
    Serial.println("[CasaMesh] WebSocket connected!");
  } else if (event == WebsocketsEvent::ConnectionClosed) {
    wsConnected = false;
    Serial.println("[CasaMesh] WebSocket disconnected.");
  }
}

bool connectWebSocket() {
  wsClient.setExtraHeaders(("Authorization: Bearer " + accessToken).c_str());
  wsClient.onMessage(onWsMessage);
  wsClient.onEvent(onWsEvent);
  bool ok = USE_TLS
    ? wsClient.connectSSL(WS_HOST, WS_PORT, WS_PATH)
    : wsClient.connect(WS_HOST, WS_PORT, WS_PATH);
  return ok;
}

// ─────────────────────────────────────────────────────────────────────────────
// Telemetry
// ─────────────────────────────────────────────────────────────────────────────
void sendTelemetry() {
  if (!wsConnected) return;
  StaticJsonDocument<256> doc;
  doc["type"]        = "telemetry";
  doc["timestamp"]   = millis();
  // ─ Replace with real sensor readings ─
  doc["temperature"] = 22.0 + (random(0, 50) / 10.0);
  doc["humidity"]    = 45.0 + (random(0, 100) / 10.0);
  String out;
  serializeJson(doc, out);
  wsClient.send(out);
  Serial.println("[CasaMesh] Telemetry sent: " + out);
}

// ─────────────────────────────────────────────────────────────────────────────
// Setup & Loop
// ─────────────────────────────────────────────────────────────────────────────
void setup() {
  Serial.begin(115200);

  // Connect WiFi
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);
  Serial.print("[WiFi] Connecting");
  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }
  Serial.println("\\n[WiFi] Connected: " + WiFi.localIP().toString());

  // Auth: load cached tokens or provision fresh
  if (!loadTokens()) {
    if (!provisionDevice()) {
      Serial.println("[CasaMesh] Fatal: Cannot provision. Check DEVICE_ID and PROVISION_TOKEN.");
      ESP.restart();
    }
  } else {
    Serial.println("[CasaMesh] Loaded cached tokens from NVS.");
  }

  // Optional: check for firmware update on boot
  checkOta("1.0.0");

  // Connect WebSocket
  if (!connectWebSocket()) {
    Serial.println("[CasaMesh] WS connect failed — attempting token refresh...");
    if (refreshTokens()) connectWebSocket();
  }
}

void loop() {
  if (WiFi.status() != WL_CONNECTED) {
    WiFi.reconnect();
    delay(5000);
    return;
  }

  if (!wsConnected) {
    Serial.println("[CasaMesh] Reconnecting WS in 5s...");
    delay(5000);
    connectWebSocket();
    return;
  }

  wsClient.poll();

  unsigned long now = millis();

  // Heartbeat
  if (now - lastHeartbeat >= HEARTBEAT_INTERVAL) {
    wsClient.send("{\\"type\\":\\"heartbeat\\"}");
    lastHeartbeat = now;
  }

  // Telemetry (SENSOR types)
  if (now - lastTelemetry >= TELEMETRY_INTERVAL) {
    sendTelemetry();
    lastTelemetry = now;
  }
}
`;
    return res.status(200).json({ code: inoCode });
  } catch (err) {
    console.error('Get device template error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
