import Redis from 'ioredis';

const REDIS_URL = process.env.REDIS_URL || 'redis://localhost:6379';

// One client for publishing, one for subscribing
export const redisPublisher = new Redis(REDIS_URL);
export const redisSubscriber = new Redis(REDIS_URL);

redisPublisher.on('connect', () => {
  console.log('[Redis] Publisher connected to', REDIS_URL);
});

redisSubscriber.on('connect', () => {
  console.log('[Redis] Subscriber connected to', REDIS_URL);
});

redisPublisher.on('error', (err) => {
  console.error('[Redis] Publisher error:', err);
});

redisSubscriber.on('error', (err) => {
  console.error('[Redis] Subscriber error:', err);
});
