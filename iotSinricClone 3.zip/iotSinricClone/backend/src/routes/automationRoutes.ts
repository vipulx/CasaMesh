import { Router } from 'express';
import { createRule, getRules, toggleRule, deleteRule } from '../controllers/automationController';
import { authenticateToken } from '../middleware/auth';

import { requireRole } from '../middleware/rbac';

const router = Router();

router.use(authenticateToken);

const readRoles = ['OWNER', 'ADMIN', 'MEMBER', 'VIEWER'];
const writeRoles = ['OWNER', 'ADMIN'];

router.post('/', requireRole(writeRoles), createRule as any);
router.get('/', requireRole(readRoles), getRules as any);
router.patch('/:id', requireRole(writeRoles), toggleRule as any);
router.delete('/:id', requireRole(writeRoles), deleteRule as any);

export default router;
