import { Router, Request, Response } from 'express';
import jwt from 'jsonwebtoken';
import { prisma } from '../services/db';
import { socketManager } from '../websocket/socketManager';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'nimbus_iot_super_secret_key_12345!';

// ==========================================
// 1. OAUTH2 FLOW FOR ALEXA / GOOGLE HOME
// ==========================================

// Simple login page stub for authorization code grant link page
router.get('/oauth/authorize', async (req: Request, res: Response) => {
  const { client_id, redirect_uri, state } = req.query;

  if (!client_id || !redirect_uri) {
    return res.status(400).send('Missing client_id or redirect_uri parameters');
  }

  // Find user by clientID
  const user = await prisma.user.findUnique({
    where: { clientID: client_id as string },
  });

  if (!user) {
    return res.status(400).send('Invalid client_id. Check your client credentials on your NimbusIoT profile.');
  }

  // Render a simple HTML form for account linking authorization
  const html = `
    <!DOCTYPE html>
    <html>
    <head>
      <title>NimbusIoT Account Linking</title>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
        body { font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif; background-color: #0f0c1b; color: #fff; display: flex; align-items: center; justify-content: center; height: 100vh; margin: 0; }
        .card { background: rgba(255, 255, 255, 0.05); backdrop-filter: blur(10px); padding: 30px; border-radius: 12px; border: 1px solid rgba(255, 255, 255, 0.1); width: 320px; text-align: center; }
        h2 { margin-bottom: 20px; font-weight: 500; }
        input { width: 100%; padding: 10px; margin: 10px 0; border-radius: 6px; border: 1px solid rgba(255,255,255,0.2); background: rgba(0,0,0,0.3); color: #fff; box-sizing: border-box; }
        button { width: 100%; padding: 12px; border-radius: 6px; border: none; background: #6366f1; color: #fff; font-weight: 600; cursor: pointer; margin-top: 15px; transition: background 0.2s; }
        button:hover { background: #4f46e5; }
        p { font-size: 12px; color: rgba(255,255,255,0.5); }
      </style>
    </head>
    <body>
      <div class="card">
        <h2>NimbusIoT Account Link</h2>
        <p>Authorize this integration to access and control your devices.</p>
        <form method="POST" action="/oauth/authorize-submit">
          <input type="hidden" name="client_id" value="${client_id}">
          <input type="hidden" name="redirect_uri" value="${redirect_uri}">
          <input type="hidden" name="state" value="${state || ''}">
          <input type="email" name="email" placeholder="Your Email" required>
          <input type="password" name="password" placeholder="Password" required>
          <button type="submit">Authorize and Link</button>
        </form>
      </div>
    </body>
    </html>
  `;
  return res.send(html);
});

// Process account link submissions
router.post('/oauth/authorize-submit', async (req: Request, res: Response) => {
  const { client_id, redirect_uri, state, email, password } = req.body;
  const bcrypt = require('bcryptjs');

  try {
    const user = await prisma.user.findUnique({ where: { email } });
    if (!user || user.clientID !== client_id) {
      return res.status(400).send('Authentication failed or invalid client ID.');
    }

    const isMatch = await bcrypt.compare(password, user.passwordHash);
    if (!isMatch) {
      return res.status(400).send('Invalid password.');
    }

    // Generate an auth code
    const authCode = jwt.sign({ userId: user.id, type: 'auth_code' }, JWT_SECRET, { expiresIn: '10m' });

    // Redirect to integration client callback with authorization code
    const redirectUrl = `${redirect_uri}?code=${authCode}&state=${state || ''}`;
    return res.redirect(redirectUrl);
  } catch (err) {
    return res.status(500).send('Internal Server Error');
  }
});

// OAuth2 Token exchange endpoint
router.post('/oauth/token', async (req: Request, res: Response) => {
  const { grant_type, code, client_id, client_secret, refresh_token } = req.body;

  try {
    let userId = '';

    if (grant_type === 'authorization_code') {
      if (!code) return res.status(400).json({ error: 'invalid_grant', error_description: 'Code is required' });
      
      const decoded = jwt.verify(code, JWT_SECRET) as { userId: string; type: string };
      if (decoded.type !== 'auth_code') {
        return res.status(400).json({ error: 'invalid_grant', error_description: 'Invalid code type' });
      }

      const user = await prisma.user.findUnique({ where: { id: decoded.userId } });
      if (!user || user.clientID !== client_id || user.clientSecret !== client_secret) {
        return res.status(400).json({ error: 'invalid_client', error_description: 'Client verification failed' });
      }

      userId = user.id;
    } 
    else if (grant_type === 'refresh_token') {
      if (!refresh_token) return res.status(400).json({ error: 'invalid_grant', error_description: 'Refresh token is required' });

      const decoded = jwt.verify(refresh_token, JWT_SECRET) as { userId: string; type: string };
      if (decoded.type !== 'refresh') {
        return res.status(400).json({ error: 'invalid_grant', error_description: 'Invalid refresh token' });
      }

      userId = decoded.userId;
    } 
    else {
      return res.status(400).json({ error: 'unsupported_grant_type' });
    }

    // Generate credentials
    const accessToken = jwt.sign({ userId, type: 'access' }, JWT_SECRET, { expiresIn: '1d' });
    const newRefreshToken = jwt.sign({ userId, type: 'refresh' }, JWT_SECRET, { expiresIn: '30d' });

    return res.json({
      token_type: 'Bearer',
      access_token: accessToken,
      expires_in: 86400,
      refresh_token: newRefreshToken,
    });
  } catch (err) {
    return res.status(400).json({ error: 'invalid_grant', error_description: 'Token processing failed' });
  }
});


// ==========================================
// 2. ALEXA SMART HOME SKILL WEBHOOK MOCK
// ==========================================
router.post('/api/v1/smarthome/alexa', async (req: Request, res: Response) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    const userId = decoded.userId;

    const request = req.body;
    const namespace = request.directive?.header?.namespace;
    const name = request.directive?.header?.name;

    if (namespace === 'Alexa.Discovery' && name === 'Discover') {
      const devices = await prisma.device.findMany({ where: { userId } });
      
      const endpoints = devices.map((d: any) => ({
        endpointId: d.id,
        manufacturerName: 'NimbusIoT Self-Hosted',
        friendlyName: d.name,
        description: `Self-hosted ${d.type} device`,
        displayCategories: d.type === 'LIGHT' ? ['LIGHT'] : d.type === 'THERMOSTAT' ? ['THERMOSTAT'] : ['SWITCH'],
        capabilities: [
          {
            type: 'AlexaInterface',
            interface: 'Alexa',
            version: '3'
          },
          {
            type: 'AlexaInterface',
            interface: 'Alexa.PowerController',
            version: '3',
            properties: {
              supported: [{ name: 'powerState' }],
              proactivelyReported: true,
              retrievable: true
            }
          }
        ]
      }));

      return res.json({
        event: {
          header: {
            namespace: 'Alexa.Discovery',
            name: 'Discover.Response',
            payloadVersion: '3',
            messageId: request.directive.header.messageId + '-rsp'
          },
          payload: { endpoints }
        }
      });
    }

    if (namespace === 'Alexa.PowerController') {
      const endpointId = request.directive.endpoint.endpointId;
      const powerState = name === 'TurnOn' ? 'On' : 'Off';

      const device = await prisma.device.findFirst({
        where: { id: endpointId, userId },
      });

      if (device) {
        socketManager.sendToDevice(endpointId, {
          action: 'setPowerState',
          value: powerState,
        });

        let currentProps = {};
        try { currentProps = JSON.parse(device.desiredState); } catch (e) {}
        const updatedProps = { ...currentProps, powerState };

        await prisma.device.update({
          where: { id: endpointId },
          data: { desiredState: JSON.stringify(updatedProps) },
        });

        socketManager.sendToUser(userId, {
          type: 'deviceStateChanged',
          deviceId: endpointId,
          desiredState: updatedProps,
        });

        return res.json({
          context: {
            properties: [
              {
                namespace: 'Alexa.PowerController',
                name: 'powerState',
                value: powerState === 'On' ? 'ON' : 'OFF',
                timeOfSample: new Date().toISOString(),
                uncertaintyInMilliseconds: 200
              }
            ]
          },
          event: {
            header: {
              namespace: 'Alexa',
              name: 'Response',
              payloadVersion: '3',
              messageId: request.directive.header.messageId + '-rsp',
              correlationToken: request.directive.header.correlationToken
            },
            endpoint: {
              endpointId
            },
            payload: {}
          }
        });
      }
    }

    return res.status(400).json({ error: 'Unsupported directive' });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid Token' });
  }
});


// ==========================================
// 3. GOOGLE HOME SMART HOME ACTION WEBHOOK
// ==========================================
router.post('/api/v1/smarthome/google', async (req: Request, res: Response) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
    const userId = decoded.userId;

    const request = req.body;
    const intent = request.inputs?.[0]?.intent;

    if (intent === 'action.devices.SYNC') {
      const devices = await prisma.device.findMany({ where: { userId } });
      const googleDevices = devices.map((d: any) => ({
        id: d.id,
        type: d.type === 'LIGHT' ? 'action.devices.types.LIGHT' : d.type === 'THERMOSTAT' ? 'action.devices.types.THERMOSTAT' : 'action.devices.types.OUTLET',
        traits: [
          'action.devices.traits.OnOff'
        ],
        name: {
          name: d.name
        },
        willReportState: true,
      }));

      return res.json({
        requestId: request.requestId,
        payload: {
          agentUserId: userId,
          devices: googleDevices
        }
      });
    }

    if (intent === 'action.devices.EXECUTE') {
      const command = request.inputs[0].payload.commands[0];
      const execution = command.execution[0];
      const deviceId = command.devices[0].id;

      if (execution.command === 'action.devices.commands.OnOff') {
        const on = execution.params.on;
        const powerState = on ? 'On' : 'Off';

        const device = await prisma.device.findFirst({
          where: { id: deviceId, userId },
        });

        if (device) {
          socketManager.sendToDevice(deviceId, {
            action: 'setPowerState',
            value: powerState,
          });

          let currentProps = {};
          try { currentProps = JSON.parse(device.desiredState); } catch (e) {}
          const updatedProps = { ...currentProps, powerState };

          await prisma.device.update({
            where: { id: deviceId },
            data: { desiredState: JSON.stringify(updatedProps) },
          });

          socketManager.sendToUser(userId, {
            type: 'deviceStateChanged',
            deviceId,
            desiredState: updatedProps,
          });

          return res.json({
            requestId: request.requestId,
            payload: {
              commands: [
                {
                  ids: [deviceId],
                  status: 'SUCCESS',
                  states: {
                    on,
                    online: true
                  }
                }
              ]
            }
          });
        }
      }
    }

    return res.json({
      requestId: request.requestId,
      payload: {
        devices: {}
      }
    });
  } catch (err) {
    return res.status(401).json({ error: 'Invalid Token' });
  }
});

export default router;
