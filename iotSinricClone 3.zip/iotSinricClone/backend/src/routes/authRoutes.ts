import { Router } from 'express';
import { register, login, me } from '../controllers/authController';
import { authenticateToken } from '../middleware/auth';
import { authLimiter } from '../middleware/rateLimiter';

import passport from '../config/passport';
import jwt from 'jsonwebtoken';

const router = Router();
const JWT_SECRET = process.env.JWT_SECRET || 'nimbus_iot_super_secret_key_12345!';
const FRONTEND_URL = process.env.NODE_ENV === 'production' ? 'https://casamesh.example.com' : 'http://localhost:5173';

router.post('/register', authLimiter, register);
router.post('/login', authLimiter, login);
router.get('/me', authenticateToken, me);

// Google OAuth routes
router.get('/google', authLimiter, passport.authenticate('google', { scope: ['profile', 'email'], session: false }));

router.get('/google/callback', authLimiter, passport.authenticate('google', { failureRedirect: `${FRONTEND_URL}/login?error=oauth_failed`, session: false }), (req, res) => {
  // Successful authentication, issue JWT
  const user = req.user as any;
  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
  
  // Pass token to frontend via URL hash or query params
  res.redirect(`${FRONTEND_URL}/login?token=${token}`);
});

export default router;
