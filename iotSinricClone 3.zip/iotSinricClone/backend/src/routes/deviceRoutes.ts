import { Router } from 'express';
import {
  createDevice,
  getDevices,
  getDevice,
  deleteDevice,
  getDeviceTelemetry,
  getDeviceTemplate,
  provisionDevice,
  refreshDeviceToken,
  uploadDeviceOta,
  checkDeviceOta,
  downloadDeviceOta,
  listDeviceOta,
} from '../controllers/deviceController';
import { authenticateToken } from '../middleware/auth';
import express from 'express';
import { authLimiter } from '../middleware/rateLimiter';
import { requireRole } from '../middleware/rbac';

const router = Router();

// ── Public Device Auth Routes (no user JWT needed) ────────────────────────────
router.post('/provision', authLimiter, provisionDevice);
router.post('/refresh', authLimiter, refreshDeviceToken);

// ── Public OTA Routes (device Bearer token authenticated internally) ───────────
router.get('/ota/check', checkDeviceOta);
router.get('/ota/download/:filename', downloadDeviceOta);

// ── Protected Routes (user JWT required) ──────────────────────────────────────
router.use(authenticateToken);

const readRoles = ['OWNER', 'ADMIN', 'MEMBER', 'VIEWER'];
const writeRoles = ['OWNER', 'ADMIN'];

router.post('/', requireRole(writeRoles), createDevice as any);
router.get('/', requireRole(readRoles), getDevices as any);
router.get('/:id', requireRole(readRoles), getDevice as any);
router.delete('/:id', requireRole(writeRoles), deleteDevice as any);
router.get('/:id/telemetry', requireRole(readRoles), getDeviceTelemetry as any);
router.get('/:id/template', requireRole(readRoles), getDeviceTemplate as any);

// OTA Management (protected — dashboard admin only)
router.post('/:id/ota/upload', requireRole(writeRoles), express.raw({ type: 'application/octet-stream', limit: '16mb' }), uploadDeviceOta as any);
router.get('/:id/ota/list', requireRole(readRoles), listDeviceOta as any);

export default router;
