import { Router } from 'express';
import { getStats, getSystemLogs, getUsers } from '../controllers/adminController';
import { authenticateToken } from '../middleware/auth';
import { requireRole } from '../middleware/rbac';

const router = Router();

router.use(authenticateToken);
router.use(requireRole(['OWNER', 'ADMIN']));

router.get('/stats', getStats as any);
router.get('/logs', getSystemLogs as any);
router.get('/users', getUsers as any);

export default router;
