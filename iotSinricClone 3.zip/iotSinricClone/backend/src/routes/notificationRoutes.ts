import { Router } from 'express';
import { authenticateToken } from '../middleware/auth';
import { getNotifications, markAsRead, clearAll } from '../controllers/notificationController';

const router = Router();

router.use(authenticateToken);

router.get('/', getNotifications as any);
router.patch('/:id/read', markAsRead as any);
router.delete('/', clearAll as any);

export default router;
