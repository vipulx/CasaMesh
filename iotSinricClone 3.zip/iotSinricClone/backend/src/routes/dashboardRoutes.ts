import { Router } from 'express';
import { authenticateToken } from '../middleware/auth';
import { requireRole } from '../middleware/rbac';
import { getDashboards, createDashboard, updateDashboard, deleteDashboard } from '../controllers/dashboardController';

const router = Router();

router.use(authenticateToken);

const readRoles = ['OWNER', 'ADMIN', 'MEMBER', 'VIEWER'];
const writeRoles = ['OWNER', 'ADMIN', 'MEMBER']; // Members can edit their dashboards

router.get('/', requireRole(readRoles), getDashboards as any);
router.post('/', requireRole(writeRoles), createDashboard as any);
router.put('/:id', requireRole(writeRoles), updateDashboard as any);
router.delete('/:id', requireRole(writeRoles), deleteDashboard as any);

export default router;
