import passport from 'passport';
import { Strategy as GoogleStrategy } from 'passport-google-oauth20';
import { prisma } from '../services/db';
import { v4 as uuidv4 } from 'uuid';

const GOOGLE_CLIENT_ID = process.env.GOOGLE_CLIENT_ID || 'placeholder_client_id';
const GOOGLE_CLIENT_SECRET = process.env.GOOGLE_CLIENT_SECRET || 'placeholder_client_secret';

// Use dynamic callback URL based on environment
const CALLBACK_URL = process.env.NODE_ENV === 'production' 
  ? 'https://casamesh.example.com/api/v1/auth/google/callback'
  : 'http://localhost:3001/api/v1/auth/google/callback';

passport.use(new GoogleStrategy({
  clientID: GOOGLE_CLIENT_ID,
  clientSecret: GOOGLE_CLIENT_SECRET,
  callbackURL: CALLBACK_URL
}, async (_accessToken, _refreshToken, profile, done) => {
  try {
    const email = profile.emails?.[0].value;
    if (!email) {
      return done(new Error('No email found from Google profile'), undefined);
    }

    // Check if user exists
    let user = await prisma.user.findUnique({
      where: { email }
    });

    if (!user) {
      // Create new user via Google
      const userCount = await prisma.user.count();
      const role = userCount === 0 ? 'ADMIN' : 'USER';

      user = await prisma.$transaction(async (tx) => {
        const newUser = await tx.user.create({
          data: {
            email,
            passwordHash: 'oauth2_user', // placeholder since they login via Google
            role,
            clientID: uuidv4(),
            clientSecret: uuidv4(),
          },
        });

        const org = await tx.organization.create({
          data: { name: 'Personal Organization' }
        });

        await tx.organizationMember.create({
          data: {
            organizationId: org.id,
            userId: newUser.id,
            role: 'OWNER'
          }
        });

        return newUser;
      });
    }

    return done(null, user);
  } catch (error) {
    return done(error, undefined);
  }
}));

// We aren't using session cookies, so we don't strictly need serialize/deserialize
// But passport might complain if we don't define them when using some strategies.
passport.serializeUser((user: any, done) => {
  done(null, user.id);
});

passport.deserializeUser(async (id: string, done) => {
  try {
    const user = await prisma.user.findUnique({ where: { id } });
    done(null, user);
  } catch (error) {
    done(error, null);
  }
});

export default passport;
