import Aedes from 'aedes';
import net from 'net';
import jwt from 'jsonwebtoken';
import { prisma } from '../services/db';
import { socketManager } from '../websocket/socketManager';


export const aedesBroker = new Aedes();

const JWT_SECRET = process.env.JWT_SECRET || 'casamesh_super_secret_key_12345!';

export function setupMqttBroker() {
  const server = net.createServer(aedesBroker.handle);
  const port = 1883;

  server.listen(port, () => {
    console.log(`[MQTT] Broker running on port ${port}`);
  });

  // Client Authentication — supports JWT device tokens (preferred) OR legacy key auth
  aedesBroker.authenticate = async (client: any, username: any, password: any, callback: any) => {
    if (!username || !password) {
      console.log('[MQTT Auth] Missing credentials');
      return callback(null, false);
    }

    const passStr = password.toString();

    // ── Method 1: JWT device access token ─────────────────────────────────────
    // username = device_id, password = JWT access token
    try {
      const payload = jwt.verify(passStr, JWT_SECRET) as any;
      if (payload.type === 'device_access' && payload.deviceId === username) {
        const device = await prisma.device.findUnique({ where: { id: payload.deviceId } });
        if (device) {
          client.userId   = payload.userId;
          client.deviceId = device.id;
          console.log(`[MQTT Auth] JWT authenticated: ${device.name} (${device.id})`);
          return callback(null, true);
        }
      }
    } catch (_) {
      // Not a valid JWT — fall through to legacy auth
    }

    // ── Method 2: Legacy key auth (username = clientID, password = device key) ──
    try {
      const user = await prisma.user.findUnique({ where: { clientID: username } });
      if (!user) {
        console.log(`[MQTT Auth] Invalid clientID: ${username}`);
        return callback(null, false);
      }

      const device = await prisma.device.findFirst({
        where: { id: client.id, key: passStr, userId: user.id },
      });

      if (!device) {
        console.log(`[MQTT Auth] Legacy auth failed for device: ${client.id}`);
        return callback(null, false);
      }

      client.userId   = user.id;
      client.deviceId = device.id;
      console.log(`[MQTT Auth] Legacy authenticated: ${device.name} (${device.id})`);
      callback(null, true);
    } catch (err) {
      console.error('[MQTT Auth] Error:', err);
      callback(null, false);
    }
  };


  // Authorize Publish Topics (Restrict to device's own telemetry/state topic)
  aedesBroker.authorizePublish = (client: any, packet: any, callback: any) => {
    if (!client) {
      // Allow internal/server publishing
      return callback(null);
    }

    const deviceId = client.deviceId;
    // Expected topics: device/{deviceId}/telemetry or device/{deviceId}/updateState
    const expectedPrefix = `device/${deviceId}/`;

    if (packet.topic.startsWith(expectedPrefix)) {
      callback(null);
    } else {
      console.warn(`[MQTT Publish Denied] Device ${client.id} tried to publish to ${packet.topic}`);
      callback(new Error('Unauthorized topic'));
    }
  };

  // Authorize Subscribe Topics (Restrict to device's own command topic)
  aedesBroker.authorizeSubscribe = (client: any, subscription: any, callback: any) => {
    const deviceId = client.deviceId;
    const expectedTopic = `device/${deviceId}/command`;

    if (subscription.topic === expectedTopic) {
      callback(null, subscription);
    } else {
      console.warn(`[MQTT Subscribe Denied] Device ${client.id} tried to subscribe to ${subscription.topic}`);
      callback(new Error('Unauthorized subscription'));
    }
  };

  // Track Device Connection Event
  aedesBroker.on('client', async (client: any) => {
    if (!client.deviceId || !client.userId) return;

    try {
      const device = await prisma.device.update({
        where: { id: client.deviceId },
        data: { status: 'ONLINE', lastSeen: new Date() },
      });

      publishHADiscovery(device);

      socketManager.sendToUser(client.userId, {
        type: 'deviceConnectionChanged',
        deviceId: client.deviceId,
        status: 'ONLINE',
      });

      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_CONNECTED',
          details: `Device ${client.deviceId} connected via MQTT`,
        },
      });
    } catch (err) {
      console.error('[MQTT Client Event] DB update failed:', err);
    }
  });

  // Track Device Disconnection Event
  aedesBroker.on('clientDisconnect', async (client: any) => {
    if (!client.deviceId || !client.userId) return;

    try {
      await prisma.device.update({
        where: { id: client.deviceId },
        data: { status: 'OFFLINE', lastSeen: new Date() },
      });

      socketManager.sendToUser(client.userId, {
        type: 'deviceConnectionChanged',
        deviceId: client.deviceId,
        status: 'OFFLINE',
      });

      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_DISCONNECTED',
          details: `Device ${client.deviceId} disconnected from MQTT`,
        },
      });
    } catch (err) {
      console.error('[MQTT Disconnect Event] DB update failed:', err);
    }
  });

  // Process Published Packets
  aedesBroker.on('publish', async (packet: any, client: any) => {
    if (!client) return; // Ignore internal server messages

    const deviceId = client.deviceId;
    const userId = client.userId;
    if (!deviceId || !userId) return;

    const topic = packet.topic;
    const clientId = client.id;

    // State confirmation
    if (topic === `casamesh/${deviceId}/state`) {
      const payloadStr = packet.payload.toString();
      socketManager.handleDeviceMessage(deviceId, clientId, JSON.stringify({
        type: 'state',
        reportedState: JSON.parse(payloadStr),
      }));
    }

    // Telemetry
    if (topic === `casamesh/${deviceId}/telemetry`) {
      const payloadStr = packet.payload.toString();
      socketManager.handleDeviceMessage(deviceId, clientId, JSON.stringify({
        type: 'telemetry',
        reportedState: JSON.parse(payloadStr),
      }));
    }
  });
}

// Publish command to physical MQTT client device
export function sendMqttCommand(deviceId: string, payload: any): boolean {
  const expectedTopic = `device/${deviceId}/command`;
  const message = JSON.stringify(payload);

  aedesBroker.publish({
    cmd: 'publish',
    qos: 1,
    topic: expectedTopic,
    payload: Buffer.from(message),
    dup: false,
    retain: false
  }, (err: any) => {
    if (err) {
      console.error(`[MQTT Publish Command Error] Device ${deviceId}:`, err);
    }
  });
  return true;
}

// Publish Home Assistant MQTT Discovery Payload
export function publishHADiscovery(device: any) {
  if (!device || !device.type) return;

  const typeMap: any = {
    'SWITCH': 'switch',
    'LIGHT': 'light',
    'THERMOSTAT': 'climate',
    'SENSOR': 'sensor',
    'FAN': 'fan',
    'LOCK': 'lock',
    'CUSTOM': 'switch',
  };

  const component = typeMap[device.type] || 'switch';
  const objectId = `casamesh_${device.id.split('-')[0]}`;
  const topic = `homeassistant/${component}/${device.id}/${objectId}/config`;

  const payload: any = {
    name: device.name,
    unique_id: device.id,
    device: {
      identifiers: [device.id],
      name: device.name,
      manufacturer: 'CasaMesh',
      model: device.type,
      sw_version: '2.0',
    },
    // Listen for state changes (Device -> CasaMesh -> HA)
    state_topic: `casamesh/${device.id}/state`,
    // Send commands (HA -> CasaMesh -> Device)
    command_topic: `device/${device.id}/command`,
  };

  if (component === 'switch' || component === 'light') {
    payload.payload_on = '{"powerState": "On"}';
    payload.payload_off = '{"powerState": "Off"}';
    payload.state_value_template = '{{ value_json.powerState }}';
  } else if (component === 'sensor') {
    payload.state_topic = `casamesh/${device.id}/telemetry`;
    payload.value_template = '{{ value_json.temperature }}';
    payload.unit_of_measurement = '°C';
    payload.device_class = 'temperature';
  }

  aedesBroker.publish({
    cmd: 'publish',
    qos: 0,
    topic: topic,
    payload: Buffer.from(JSON.stringify(payload)),
    dup: false,
    retain: true // Retain the config so HA picks it up on restart
  }, (err: any) => {
    if (err) console.error(`[HA Discovery] Publish error for ${device.id}:`, err);
    else console.log(`[HA Discovery] Published discovery payload for ${device.name}`);
  });
}
