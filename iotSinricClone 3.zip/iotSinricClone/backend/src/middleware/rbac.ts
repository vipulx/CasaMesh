import { Request, Response, NextFunction, RequestHandler } from 'express';
import { prisma } from '../services/db';
import { AuthenticatedRequest } from './auth';

export const requireRole = (allowedRoles: string[]): RequestHandler => {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      // req.user is set by authenticateToken
      const user = (req as AuthenticatedRequest).user;
      if (!user) {
        return res.status(401).json({ error: 'Unauthorized' });
      }

      // Check if user is system admin
      if (user.role === 'ADMIN') {
        return next();
      }

      // Find the user's memberships
      const memberships = await prisma.organizationMember.findMany({
        where: { userId: user.id }
      });

      if (memberships.length === 0) {
        return res.status(403).json({ error: 'User does not belong to any organization' });
      }

      // For now, check if ANY of their memberships have an allowed role
      // In a multi-tenant app, you'd check against a specific org ID from the request header/params
      const hasRole = memberships.some(m => allowedRoles.includes(m.role));

      if (!hasRole) {
        return res.status(403).json({ error: 'Forbidden: Insufficient role permissions' });
      }

      next();
    } catch (error) {
      console.error('[RBAC] Error:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  };
};
