import { prisma } from '../services/db';
import { socketManager } from '../websocket/socketManager';

export async function evaluateRules(
  deviceId: string,
  property: string,
  value: any,
  userId: string
) {
  try {
    // Fetch all active rules triggered by this device and property
    const rules = await prisma.automationRule.findMany({
      where: {
        userId,
        triggerDeviceId: deviceId,
        triggerProperty: property,
        active: true,
      },
    });

    for (const rule of rules) {
      let isTriggered = false;
      const numVal = parseFloat(value);
      const numTrigger = parseFloat(rule.triggerValue);

      switch (rule.operator) {
        case 'EQUALS':
          isTriggered = String(value).toLowerCase() === String(rule.triggerValue).toLowerCase();
          break;
        case 'GREATER_THAN':
          if (!isNaN(numVal) && !isNaN(numTrigger)) {
            isTriggered = numVal > numTrigger;
          }
          break;
        case 'LESS_THAN':
          if (!isNaN(numVal) && !isNaN(numTrigger)) {
            isTriggered = numVal < numTrigger;
          }
          break;
      }

      if (isTriggered) {
        console.log(`[Automation] Rule "${rule.name}" triggered! Action: Set ${rule.actionDeviceId} -> ${rule.actionProperty} = ${rule.actionValue}`);
        
        // Formulate target action command
        let actionCommand = '';
        if (rule.actionProperty === 'powerState') {
          actionCommand = 'setPowerState';
        } else if (rule.actionProperty === 'brightness') {
          actionCommand = 'setBrightness';
        } else if (rule.actionProperty === 'targetTemperature') {
          actionCommand = 'setTargetTemperature';
        } else {
          actionCommand = `set${rule.actionProperty.charAt(0).toUpperCase()}${rule.actionProperty.slice(1)}`;
        }

        const payload = {
          action: actionCommand,
          value: rule.actionValue,
        };

        // 1. Send command to physical device via WebSocket (if connected online)
        const sent = socketManager.sendToDevice(rule.actionDeviceId, payload);
        
        // 2. Update DB device shadow state
        const targetDevice = await prisma.device.findUnique({
          where: { id: rule.actionDeviceId }
        });
        
        if (targetDevice) {
          let currentProps = {};
          try {
            currentProps = JSON.parse(targetDevice.desiredState);
          } catch (e) {}

          const updatedProps = { ...currentProps, [rule.actionProperty]: rule.actionValue };
          
          await prisma.device.update({
            where: { id: rule.actionDeviceId },
            data: { desiredState: JSON.stringify(updatedProps) }
          });

          // Inform user dashboards about target state modification
          socketManager.sendToUser(targetDevice.userId, {
            type: 'deviceStateChanged',
            deviceId: targetDevice.id,
            desiredState: updatedProps,
          });

          // Log the execution
          await prisma.systemLog.create({
            data: {
              action: 'RULE_EXECUTED',
              details: `Rule "${rule.name}" triggered action: set device ${targetDevice.name} ${rule.actionProperty} = ${rule.actionValue} (WebSocket sent: ${sent})`,
            },
          });
        }
      }
    }
  } catch (err) {
    console.error('[Automation] Error evaluating rules:', err);
  }
}
