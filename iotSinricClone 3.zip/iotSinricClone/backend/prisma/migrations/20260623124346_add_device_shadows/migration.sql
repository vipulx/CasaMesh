/*
  Warnings:

  - You are about to drop the column `properties` on the `Device` table. All the data in the column will be lost.

*/
-- RedefineTables
PRAGMA defer_foreign_keys=ON;
PRAGMA foreign_keys=OFF;
CREATE TABLE "new_Device" (
    "id" TEXT NOT NULL PRIMARY KEY,
    "name" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'OFFLINE',
    "key" TEXT NOT NULL,
    "secret" TEXT NOT NULL,
    "provisionToken" TEXT NOT NULL,
    "desiredState" TEXT NOT NULL DEFAULT '{}',
    "reportedState" TEXT NOT NULL DEFAULT '{}',
    "lastSeen" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "userId" TEXT NOT NULL,
    CONSTRAINT "Device_userId_fkey" FOREIGN KEY ("userId") REFERENCES "User" ("id") ON DELETE CASCADE ON UPDATE CASCADE
);
INSERT INTO "new_Device" ("id", "key", "lastSeen", "name", "provisionToken", "secret", "status", "type", "userId") SELECT "id", "key", "lastSeen", "name", "provisionToken", "secret", "status", "type", "userId" FROM "Device";
DROP TABLE "Device";
ALTER TABLE "new_Device" RENAME TO "Device";
CREATE UNIQUE INDEX "Device_key_key" ON "Device"("key");
CREATE UNIQUE INDEX "Device_provisionToken_key" ON "Device"("provisionToken");
PRAGMA foreign_keys=ON;
PRAGMA defer_foreign_keys=OFF;
