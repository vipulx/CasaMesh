const express = require('express');
const router = express.Router();
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// API Key Guard
const apiKeyGuard = async (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey) return res.status(401).json({ error: 'x-api-key header required' });
  
  const project = await prisma.project.findUnique({ where: { apiKey } });
  if (!project) return res.status(401).json({ error: 'Invalid API Key' });
  
  req.project = project;
  next();
};

router.use(apiKeyGuard);

// Helper to ensure collection exists
const ensureCollection = async (projectId, name) => {
  let collection = await prisma.collection.findUnique({
    where: { projectId_name: { projectId, name } }
  });
  if (!collection) {
    collection = await prisma.collection.create({
      data: { name, projectId }
    });
  }
  return collection;
};

// GET /api/db/:projectId/:collection
// Get all records in a collection
router.get('/:projectId/:collection', async (req, res) => {
  try {
    if (req.project.id !== req.params.projectId) {
      return res.status(403).json({ error: 'Project ID mismatch with API Key' });
    }
    const collection = await prisma.collection.findUnique({
      where: { projectId_name: { projectId: req.params.projectId, name: req.params.collection } }
    });
    
    if (!collection) return res.json([]); // Return empty array if collection doesn't exist
    
    const records = await prisma.record.findMany({
      where: { collectionId: collection.id }
    });
    
    res.json(records.map(r => ({ id: r.id, _created: r.createdAt, ...r.data })));
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// POST /api/db/:projectId/:collection
// Create a new record
router.post('/:projectId/:collection', async (req, res) => {
  try {
    if (req.project.id !== req.params.projectId) {
      return res.status(403).json({ error: 'Project ID mismatch with API Key' });
    }
    
    const data = req.body;
    const collection = await ensureCollection(req.project.id, req.params.collection);
    
    const record = await prisma.record.create({
      data: {
        data,
        collectionId: collection.id,
        projectId: req.project.id
      }
    });
    
    res.status(201).json({ id: record.id, _created: record.createdAt, ...record.data });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/db/:projectId/:collection/:id
router.get('/:projectId/:collection/:id', async (req, res) => {
    try {
        const record = await prisma.record.findUnique({
            where: { id: req.params.id }
        });
        if(!record || record.projectId !== req.params.projectId) return res.status(404).json({error: "Not Found"});
        res.json({ id: record.id, _created: record.createdAt, ...record.data });
    } catch(err) {
        res.status(500).json({ error: err.message });
    }
});

// PUT /api/db/:projectId/:collection/:id
router.put('/:projectId/:collection/:id', async (req, res) => {
    try {
        const record = await prisma.record.update({
            where: { id: req.params.id },
            data: { data: req.body }
        });
        res.json({ id: record.id, _created: record.createdAt, ...record.data });
    } catch(err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE /api/db/:projectId/:collection/:id
router.delete('/:projectId/:collection/:id', async (req, res) => {
    try {
        await prisma.record.delete({
            where: { id: req.params.id }
        });
        res.json({ success: true });
    } catch(err) {
        res.status(500).json({ error: err.message });
    }
});

module.exports = router;
