const express = require('express');
const router = express.Router();
const jwt = require('jsonwebtoken');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

const JWT_SECRET = process.env.JWT_SECRET || 'secret';

// Middleware to protect routes
const authGuard = (req, res, next) => {
  const authHeader = req.headers.authorization;
  if (!authHeader) return res.status(401).json({ error: 'Unauthorized' });
  
  const token = authHeader.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    req.userId = payload.userId;
    next();
  } catch (e) {
    res.status(401).json({ error: 'Invalid token' });
  }
};

router.use(authGuard);

// Create Project
router.post('/', async (req, res) => {
  try {
    const { name, description } = req.body;
    const project = await prisma.project.create({
      data: { name, description, userId: req.userId }
    });
    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// List Projects
router.get('/', async (req, res) => {
  const projects = await prisma.project.findMany({ where: { userId: req.userId } });
  res.json(projects);
});

// Get Project Details & Stats
router.get('/:id', async (req, res) => {
  const project = await prisma.project.findFirst({
    where: { id: req.params.id, userId: req.userId },
    include: { collections: true }
  });
  if (!project) return res.status(404).json({ error: 'Not found' });
  
  // Get records count per collection for analytics
  const stats = await prisma.record.groupBy({
    by: ['collectionId'],
    where: { projectId: project.id },
    _count: { id: true }
  });
  
  res.json({ ...project, stats });
});

// Create Collection
router.post('/:id/collections', async (req, res) => {
  try {
    const { name, schema } = req.body;
    const project = await prisma.project.findFirst({ where: { id: req.params.id, userId: req.userId } });
    if (!project) return res.status(404).json({ error: 'Project not found' });
    
    const collection = await prisma.collection.create({
      data: { name, schema, projectId: project.id }
    });
    
    res.status(201).json(collection);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Get Collections
router.get('/:id/collections', async (req, res) => {
  const collections = await prisma.collection.findMany({ where: { projectId: req.params.id } });
  res.json(collections);
});

module.exports = router;
