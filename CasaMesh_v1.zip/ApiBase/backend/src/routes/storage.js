const express = require('express');
const router = express.Router();
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const { PrismaClient } = require('@prisma/client');
const prisma = new PrismaClient();

// API Key Guard for uploads
const apiKeyGuard = async (req, res, next) => {
  const apiKey = req.headers['x-api-key'];
  if (!apiKey) return res.status(401).json({ error: 'x-api-key header required' });
  
  const project = await prisma.project.findUnique({ where: { apiKey } });
  if (!project) return res.status(401).json({ error: 'Invalid API Key' });
  
  req.project = project;
  next();
};

// Storage setup
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    const projectId = req.project.id;
    const projectUploadDir = path.join(__dirname, '../../uploads', projectId);
    
    if (!fs.existsSync(projectUploadDir)) {
      fs.mkdirSync(projectUploadDir, { recursive: true });
    }
    cb(null, projectUploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1EB9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({ 
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 } // 5MB limit
});

router.use(apiKeyGuard);

router.post('/upload', upload.single('file'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: 'No file uploaded' });
  }

  // Generate public URL
  const publicUrl = `/uploads/${req.project.id}/${req.file.filename}`;
  
  res.status(201).json({
    url: publicUrl,
    filename: req.file.filename,
    mimetype: req.file.mimetype,
    size: req.file.size
  });
});

module.exports = router;
