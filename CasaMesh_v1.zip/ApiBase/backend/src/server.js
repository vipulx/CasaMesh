const express = require('express');
const cors = require('cors');
const path = require('path');
const fs = require('fs');
const dotenv = require('dotenv');

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Ensure uploads directory exists
const uploadsDir = path.join(__dirname, '../uploads');
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

// Static serve for uploads
app.use('/uploads', express.static(uploadsDir));

// Routes
const authRoutes = require('./routes/auth');
const projectRoutes = require('./routes/projects');
const apiRoutes = require('./routes/api');
const storageRoutes = require('./routes/storage');

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/storage', storageRoutes);

// The dynamic REST API generated per project
// Route: /api/db/:projectId/:collection
app.use('/api/db', apiRoutes);

// Health check
app.get('/health', (req, res) => {
  res.status(200).json({ status: 'ok', uptime: process.uptime() });
});

app.listen(PORT, () => {
  console.log(`DataNest Backend running on http://localhost:${PORT}`);
});
