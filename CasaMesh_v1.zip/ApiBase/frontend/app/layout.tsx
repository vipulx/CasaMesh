import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "DataNest - Cloud BaaS",
  description: "Self-hosted Backend as a Service",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="dark">
      <body>{children}</body>
    </html>
  );
}
