"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { LayoutDashboard, Database, FileJson, Settings, LogOut } from "lucide-react";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  const links = [
    { href: "/dashboard", label: "Overview", icon: LayoutDashboard },
    { href: "/dashboard/collections", label: "Collections", icon: Database },
    { href: "/dashboard/docs", label: "API Docs", icon: FileJson },
    { href: "/dashboard/settings", label: "Settings", icon: Settings },
  ];

  return (
    <div className="flex h-screen bg-[#09090b] text-white">
      {/* Sidebar */}
      <aside className="w-64 border-r border-zinc-800 bg-zinc-950 flex flex-col">
        <div className="h-16 flex items-center px-6 border-b border-zinc-800">
          <Database className="w-5 h-5 text-brand-500 mr-2" />
          <span className="font-bold text-lg tracking-tight">DataNest</span>
        </div>
        
        <div className="p-4 flex-1">
          <div className="text-xs font-semibold text-zinc-500 mb-4 px-2 uppercase tracking-wider">Default Project</div>
          <nav className="space-y-1">
            {links.map((link) => {
              const Icon = link.icon;
              const isActive = pathname === link.href || pathname.startsWith(link.href + '/');
              return (
                <Link key={link.href} href={link.href}
                  className={`flex items-center px-3 py-2 text-sm rounded-md transition-colors ${
                    isActive 
                      ? "bg-brand-500/10 text-brand-500 font-medium" 
                      : "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-100"
                  }`}
                >
                  <Icon className={`w-4 h-4 mr-3 ${isActive ? 'text-brand-500' : 'text-zinc-500'}`} />
                  {link.label}
                </Link>
              );
            })}
          </nav>
        </div>

        <div className="p-4 border-t border-zinc-800">
          <button className="flex items-center w-full px-3 py-2 text-sm text-zinc-400 rounded-md hover:bg-zinc-800/50 transition-colors mt-auto">
            <LogOut className="w-4 h-4 mr-3 text-zinc-500" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <div className="absolute top-[-10%] right-[-10%] w-[40%] h-[40%] bg-brand-500/10 blur-[100px] rounded-full pointer-events-none" />
        <div className="h-16 flex items-center justify-between px-8 border-b border-zinc-800 bg-zinc-950/60 backdrop-blur-md sticky top-0 z-10 w-full">
          <h2 className="font-medium text-zinc-100">Project Workspace</h2>
          <div className="text-sm px-3 py-1 bg-zinc-800 rounded-full border border-zinc-700 text-zinc-300">
            API Key: <span className="font-mono text-xs ml-1 text-zinc-100">prj_test...</span>
          </div>
        </div>
        <div className="flex-1 overflow-auto p-8 z-0">
          {children}
        </div>
      </main>
    </div>
  );
}
