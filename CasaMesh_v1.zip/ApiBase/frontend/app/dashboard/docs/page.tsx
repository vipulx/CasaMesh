"use client";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Copy, Terminal } from "lucide-react";

export default function ApiDocsPage() {
  return (
    <div className="space-y-6 max-w-5xl">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">API Documentation</h1>
        <p className="text-zinc-500">Auto-generated REST APIs for your project collections.</p>
      </div>

      <div className="bg-brand-500/10 border border-brand-500/20 text-brand-500/90 px-4 py-3 rounded-lg flex items-center gap-3">
        <Terminal className="w-5 h-5"/>
        <span className="text-sm">Base URL: <code className="font-mono font-bold">https://datanest.local/api/db/project_id</code></span>
      </div>

      <div className="space-y-8 mt-8">
        
        {/* GET ALL */}
        <Card>
          <CardHeader className="border-b border-zinc-800 bg-zinc-900/30">
            <div className="flex items-center gap-3">
              <span className="bg-blue-500/20 text-blue-400 text-xs font-bold px-2 py-1 rounded">GET</span>
              <CardTitle className="font-mono text-sm tracking-normal">/:collection_name</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <p className="text-sm text-zinc-400">Retrieve all records inside a specific collection.</p>
            <div className="bg-[#1e1e1e] rounded-md p-4 relative group">
              <button className="absolute top-3 right-3 text-zinc-500 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <Copy className="w-4 h-4"/>
              </button>
              <pre className="text-xs text-zinc-300 font-mono overflow-x-auto">
{`curl -X GET https://datanest.local/api/db/prj_test/SensorData \\
  -H "x-api-key: your-api-key"`}
              </pre>
            </div>
          </CardContent>
        </Card>

        {/* POST CREATE */}
        <Card>
          <CardHeader className="border-b border-zinc-800 bg-zinc-900/30">
            <div className="flex items-center gap-3">
              <span className="bg-green-500/20 text-green-400 text-xs font-bold px-2 py-1 rounded">POST</span>
              <CardTitle className="font-mono text-sm tracking-normal">/:collection_name</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <p className="text-sm text-zinc-400">Create a new record. If the collection does not exist, it will be automatically created.</p>
            <div className="bg-[#1e1e1e] rounded-md p-4 relative group">
              <button className="absolute top-3 right-3 text-zinc-500 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <Copy className="w-4 h-4"/>
              </button>
              <pre className="text-xs text-zinc-300 font-mono overflow-x-auto">
{`curl -X POST https://datanest.local/api/db/prj_test/SensorData \\
  -H "x-api-key: your-api-key" \\
  -H "Content-Type: application/json" \\
  -d '{"temperature": 25, "humidity": 60}'`}
              </pre>
            </div>
          </CardContent>
        </Card>

        {/* IMAGE UPLOAD */}
        <Card>
          <CardHeader className="border-b border-zinc-800 bg-zinc-900/30">
            <div className="flex items-center gap-3">
              <span className="bg-purple-500/20 text-purple-400 text-xs font-bold px-2 py-1 rounded">POST</span>
              <CardTitle className="font-mono text-sm tracking-normal">https://datanest.local/api/storage/upload</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="pt-6 space-y-4">
            <p className="text-sm text-zinc-400">Upload an image file using multipart/form-data. Returns a public URL to store in your records.</p>
            <div className="bg-[#1e1e1e] rounded-md p-4 relative group">
              <button className="absolute top-3 right-3 text-zinc-500 hover:text-white opacity-0 group-hover:opacity-100 transition-opacity">
                <Copy className="w-4 h-4"/>
              </button>
              <pre className="text-xs text-zinc-300 font-mono overflow-x-auto">
{`curl -X POST https://datanest.local/api/storage/upload \\
  -H "x-api-key: your-api-key" \\
  -F "file=@/path/to/image.jpg"`}
              </pre>
            </div>
          </CardContent>
        </Card>

      </div>
    </div>
  );
}
