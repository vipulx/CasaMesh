"use client";
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Database, Plus, Search, Table, Trash2, Edit } from "lucide-react";

export default function CollectionsPage() {
  const [collections] = useState([
    { id: '1', name: 'Users', recordCount: 150, lastActive: '2 mins ago' },
    { id: '2', name: 'SensorData', recordCount: 1045, lastActive: 'Just now' },
    { id: '3', name: 'Products', recordCount: 45, lastActive: '3 hours ago' },
  ]);

  return (
    <div className="space-y-6 flex flex-col h-full">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Database Collections</h1>
          <p className="text-zinc-500">Manage your schemaless JSON tables.</p>
        </div>
        <button className="bg-brand-500 hover:bg-brand-400 text-black font-medium py-2 px-4 rounded-lg flex items-center gap-2 transition-colors">
          <Plus className="w-4 h-4" />
          New Collection
        </button>
      </div>

      <div className="flex-1 grid grid-cols-12 gap-6 h-full mt-4">
        {/* Collections List */}
        <div className="col-span-3 space-y-4">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-3 text-zinc-500" />
            <input 
              type="text" 
              placeholder="Search collections..." 
              className="w-full bg-zinc-900 border border-zinc-800 rounded-lg py-2 pl-9 pr-4 text-sm text-zinc-300 focus:outline-none focus:border-brand-500"
            />
          </div>
          
          <div className="space-y-2 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
            {collections.map((col, idx) => (
              <div 
                key={col.id} 
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${idx === 1 ? 'bg-zinc-800/80 border-zinc-700' : 'bg-zinc-950 border-zinc-800/50 hover:border-zinc-700'}`}
              >
                <div className="flex items-center gap-2 mb-2">
                  <Database className={`w-4 h-4 ${idx === 1 ? 'text-brand-500' : 'text-zinc-500'}`} />
                  <span className="font-medium text-sm text-zinc-200">{col.name}</span>
                </div>
                <div className="flex justify-between text-xs text-zinc-500">
                  <span>{col.recordCount} records</span>
                  <span>{col.lastActive}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Data Grid Preview (Focusing on SensorData mock) */}
        <Card className="col-span-9 flex flex-col h-full max-h-[calc(100vh-200px)]">
          <CardHeader className="border-b border-zinc-800 pb-4 flex flex-row items-center justify-between space-y-0">
            <div className="flex items-center gap-2">
              <Table className="w-5 h-5 text-zinc-400" />
              <CardTitle>SensorData</CardTitle>
            </div>
            <button className="text-sm bg-zinc-800 hover:bg-zinc-700 text-zinc-300 py-1.5 px-3 rounded-md transition-colors">
              Add Document
            </button>
          </CardHeader>
          <CardContent className="p-0 flex-1 overflow-auto">
            <table className="w-full text-sm text-left">
              <thead className="text-xs text-zinc-400 bg-zinc-900/50 sticky top-0">
                <tr>
                  <th className="px-6 py-3 font-medium">id</th>
                  <th className="px-6 py-3 font-medium">temperature</th>
                  <th className="px-6 py-3 font-medium">humidity</th>
                  <th className="px-6 py-3 font-medium">_created</th>
                  <th className="px-6 py-3 text-right font-medium">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800 text-zinc-300">
                {[1, 2, 3, 4, 5, 6].map((row) => (
                  <tr key={row} className="hover:bg-zinc-800/20 transition-colors">
                    <td className="px-6 py-3 font-mono text-xs text-zinc-500">rec_{Math.random().toString(36).substring(7)}</td>
                    <td className="px-6 py-3 text-emerald-400">{22 + Math.random() * 5 | 0}°C</td>
                    <td className="px-6 py-3 text-blue-400">{40 + Math.random() * 10 | 0}%</td>
                    <td className="px-6 py-3 text-zinc-500 text-xs">2026-04-19T10:1{row}:00Z</td>
                    <td className="px-6 py-3 flex justify-end gap-2 text-zinc-500">
                      <button className="hover:text-zinc-300"><Edit className="w-4 h-4" /></button>
                      <button className="hover:text-red-400"><Trash2 className="w-4 h-4" /></button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
