"use client";
import { useState } from "react";
import { Server, Lock, ArrowRight, Database, Github } from "lucide-react";

export default function Home() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLogin, setIsLogin] = useState(true);

  return (
    <div className="min-h-screen flex text-white relative overflow-hidden bg-[#09090b]">
      {/* Background Gradients */}
      <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[50%] bg-brand-500/20 blur-[120px] rounded-full pointer-events-none" />
      <div className="absolute bottom-[-20%] right-[-10%] w-[50%] h-[50%] bg-blue-500/10 blur-[120px] rounded-full pointer-events-none" />

      {/* Left info side */}
      <div className="hidden lg:flex flex-col justify-between w-1/2 p-16 z-10 border-r border-[#27272a]/50 bg-black/20 backdrop-blur-sm">
        <div>
          <div className="flex items-center gap-2 mb-12">
            <div className="p-2 bg-brand-500/20 rounded-lg">
              <Database className="w-6 h-6 text-brand-500" />
            </div>
            <span className="text-2xl font-bold tracking-tight">DataNest</span>
          </div>
          <h1 className="text-5xl font-semibold leading-tight mb-6">
            The self-hosted <br /> Backend-as-a-Service<br />
            <span className="text-brand-500">for IoT & Web.</span>
          </h1>
          <p className="text-zinc-400 text-lg max-w-md">
            Build production-ready apps faster with instant REST APIs, dynamic document storage, and powerful analytics right out of the box.
          </p>
        </div>
        
        <div className="flex gap-4 items-center text-sm text-zinc-500">
          <Github className="w-5 h-5"/>
          <span>Fully Open Source</span>
          <span className="w-1 h-1 rounded-full bg-zinc-600"></span>
          <span>Deploy anywhere</span>
        </div>
      </div>

      {/* Right Login side */}
      <div className="w-full lg:w-1/2 flex items-center justify-center p-8 z-10">
        <div className="w-full max-w-md border border-[#27272a] bg-zinc-900/50 backdrop-blur-xl rounded-2xl p-8 shadow-2xl">
          <h2 className="text-2xl font-semibold mb-2">{isLogin ? 'Welcome back' : 'Create an account'}</h2>
          <p className="text-zinc-400 mb-8">{isLogin ? 'Enter your details to access your projects.' : 'Start building faster today.'}</p>
          
          <form className="space-y-4" onSubmit={(e) => { e.preventDefault(); window.location.href = '/dashboard'; }}>
            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300">Email Address</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-500">
                  <Server className="w-4 h-4"/>
                </div>
                <input 
                  type="email" 
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg py-2.5 pl-10 pr-4 text-zinc-300 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all"
                  placeholder="admin@datanest.local"
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-zinc-300">Password</label>
              <div className="relative">
                <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none text-zinc-500">
                  <Lock className="w-4 h-4"/>
                </div>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-lg py-2.5 pl-10 pr-4 text-zinc-300 focus:outline-none focus:border-brand-500 focus:ring-1 focus:ring-brand-500 transition-all"
                  placeholder="••••••••"
                />
              </div>
            </div>

            <button type="submit" className="w-full bg-brand-500 hover:bg-brand-400 text-black font-semibold rounded-lg py-2.5 px-4 mt-6 flex items-center justify-center gap-2 transition-colors">
              {isLogin ? 'Sign In' : 'Sign Up'}
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>

          <p className="text-center text-zinc-500 text-sm mt-8">
            {isLogin ? "Don't have an account? " : "Already have an account? "}
            <button onClick={() => setIsLogin(!isLogin)} className="text-brand-500 hover:text-brand-400 transition-colors">
              {isLogin ? 'Sign up' : 'Log in'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}
