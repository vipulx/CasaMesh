import Aedes from 'aedes';
import net from 'net';
import { prisma } from '../services/db';
import { socketManager } from '../websocket/socketManager';

export const aedesBroker = new Aedes();

export function setupMqttBroker() {
  const server = net.createServer(aedesBroker.handle);
  const port = 1883;

  server.listen(port, () => {
    console.log(`[MQTT] Broker running on port ${port}`);
  });

  // Client Authentication
  aedesBroker.authenticate = async (client: any, username: any, password: any, callback: any) => {
    if (!username || !password) {
      console.log('[MQTT Auth] Missing credentials');
      return callback(null, false);
    }

    try {
      const user = await prisma.user.findUnique({
        where: { clientID: username },
      });

      if (!user) {
        console.log(`[MQTT Auth] Invalid username/clientID: ${username}`);
        return callback(null, false);
      }

      // password is passed as a Buffer from MQTT client
      const passStr = password.toString();

      const device = await prisma.device.findFirst({
        where: {
          id: client.id, // Device ID is client.id
          key: passStr,
          userId: user.id,
        },
      });

      if (!device) {
        console.log(`[MQTT Auth] Authentication failed for device: ${client.id}`);
        return callback(null, false);
      }

      // Store variables on MQTT client session
      client.userId = user.id;
      client.deviceId = device.id;
      console.log(`[MQTT Auth] Authenticated device successfully: ${device.name} (${device.id})`);
      callback(null, true);
    } catch (err) {
      console.error('[MQTT Auth] Error authenticating client:', err);
      callback(null, false);
    }
  };

  // Authorize Publish Topics (Restrict to device's own telemetry/state topic)
  aedesBroker.authorizePublish = (client: any, packet: any, callback: any) => {
    if (!client) {
      // Allow internal/server publishing
      return callback(null);
    }

    const deviceId = client.deviceId;
    // Expected topics: device/{deviceId}/telemetry or device/{deviceId}/updateState
    const expectedPrefix = `device/${deviceId}/`;

    if (packet.topic.startsWith(expectedPrefix)) {
      callback(null);
    } else {
      console.warn(`[MQTT Publish Denied] Device ${client.id} tried to publish to ${packet.topic}`);
      callback(new Error('Unauthorized topic'));
    }
  };

  // Authorize Subscribe Topics (Restrict to device's own command topic)
  aedesBroker.authorizeSubscribe = (client: any, subscription: any, callback: any) => {
    const deviceId = client.deviceId;
    const expectedTopic = `device/${deviceId}/command`;

    if (subscription.topic === expectedTopic) {
      callback(null, subscription);
    } else {
      console.warn(`[MQTT Subscribe Denied] Device ${client.id} tried to subscribe to ${subscription.topic}`);
      callback(new Error('Unauthorized subscription'));
    }
  };

  // Track Device Connection Event
  aedesBroker.on('client', async (client: any) => {
    if (!client.deviceId || !client.userId) return;

    try {
      await prisma.device.update({
        where: { id: client.deviceId },
        data: { status: 'ONLINE', lastSeen: new Date() },
      });

      socketManager.sendToUser(client.userId, {
        type: 'deviceConnectionChanged',
        deviceId: client.deviceId,
        status: 'ONLINE',
      });

      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_CONNECTED',
          details: `Device ${client.deviceId} connected via MQTT`,
        },
      });
    } catch (err) {
      console.error('[MQTT Client Event] DB update failed:', err);
    }
  });

  // Track Device Disconnection Event
  aedesBroker.on('clientDisconnect', async (client: any) => {
    if (!client.deviceId || !client.userId) return;

    try {
      await prisma.device.update({
        where: { id: client.deviceId },
        data: { status: 'OFFLINE', lastSeen: new Date() },
      });

      socketManager.sendToUser(client.userId, {
        type: 'deviceConnectionChanged',
        deviceId: client.deviceId,
        status: 'OFFLINE',
      });

      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_DISCONNECTED',
          details: `Device ${client.deviceId} disconnected from MQTT`,
        },
      });
    } catch (err) {
      console.error('[MQTT Disconnect Event] DB update failed:', err);
    }
  });

  // Process Published Packets
  aedesBroker.on('publish', async (packet: any, client: any) => {
    if (!client) return; // Ignore internal server messages

    const deviceId = client.deviceId;
    const userId = client.userId;
    if (!deviceId || !userId) return;

    const payloadStr = packet.payload.toString();

    // Check action based on topic suffix
    if (packet.topic.endsWith('/telemetry')) {
      const payload = {
        action: 'telemetry',
        properties: JSON.parse(payloadStr),
      };
      await socketManager.handleDeviceMessage(deviceId, userId, JSON.stringify(payload));
    } 
    else if (packet.topic.endsWith('/updateState')) {
      const payload = {
        action: 'updateState',
        properties: JSON.parse(payloadStr),
      };
      await socketManager.handleDeviceMessage(deviceId, userId, JSON.stringify(payload));
    }
  });
}

// Publish command to physical MQTT client device
export function sendMqttCommand(deviceId: string, payload: any): boolean {
  const expectedTopic = `device/${deviceId}/command`;
  const message = JSON.stringify(payload);

  aedesBroker.publish({
    cmd: 'publish',
    qos: 1,
    topic: expectedTopic,
    payload: Buffer.from(message),
    dup: false,
    retain: false
  }, (err: any) => {
    if (err) {
      console.error(`[MQTT Publish Command Error] Device ${deviceId}:`, err);
    }
  });
  return true;
}
