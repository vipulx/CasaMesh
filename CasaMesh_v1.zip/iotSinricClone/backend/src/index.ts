import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import cors from 'cors';
import { createServer } from 'http';
import { setupWebSocketServer } from './websocket/wsServer';
import { setupMqttBroker } from './mqtt/mqttBroker';

// Import Route Handlers
import authRoutes from './routes/authRoutes';
import deviceRoutes from './routes/deviceRoutes';
import automationRoutes from './routes/automationRoutes';
import adminRoutes from './routes/adminRoutes';
import integrationRoutes from './routes/integrationRoutes';

const app = express();
const PORT = process.env.PORT || 3001;

// Middlewares
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve frontend static assets if dist folder exists
import path from 'path';
import fs from 'fs';

const devDistPath = path.join(__dirname, '../../frontend/dist');
const prodDistPath = path.join(__dirname, '../frontend/dist');
const staticPath = fs.existsSync(prodDistPath) ? prodDistPath : devDistPath;

if (fs.existsSync(staticPath)) {
  console.log(`[NimbusIoT Backend] Serving static frontend from: ${staticPath}`);
  app.use(express.static(staticPath));
}

// REST API routes
app.use('/api/v1/auth', authRoutes);
app.use('/api/v1/devices', deviceRoutes);
app.use('/api/v1/automations', automationRoutes);
app.use('/api/v1/admin', adminRoutes);

// Smart home integration / OAuth2 routes (top-level mount since OAuth links target root paths sometimes)
app.use('/', integrationRoutes);

// Static hosting fallback for SPA routing
if (fs.existsSync(staticPath)) {
  app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api/v1') || req.path.startsWith('/oauth') || req.path.startsWith('/health')) {
      return next();
    }
    res.sendFile(path.join(staticPath, 'index.html'));
  });
}

// Health check endpoint
app.get('/health', (_req, res) => {
  res.status(200).json({ status: 'OK', uptime: process.uptime() });
});

// Setup HTTP server
const server = createServer(app);

// Setup WebSocket routing pipeline on HTTP server upgrade
setupWebSocketServer(server);

// Setup Aedes MQTT broker on port 1883
setupMqttBroker();

// Boot application
server.listen(PORT, () => {
  console.log(`[NimbusIoT Backend] REST API and WebSockets running on port ${PORT}`);
});
