import { WebSocket } from 'ws';
import { prisma } from '../services/db';
import { evaluateRules } from '../automations/ruleEngine';
import { sendMqttCommand } from '../mqtt/mqttBroker';

class SocketManager {
  // Map of User ID -> Array of WebSocket connections for browser dashboards
  private userSockets: Map<string, WebSocket[]> = new Map();
  // Map of Device ID -> Active WebSocket connection for physical device
  private deviceSockets: Map<string, WebSocket> = new Map();

  // DASHBOARD CLIENTS REGISTER
  public addUserSocket(userId: string, ws: WebSocket) {
    const sockets = this.userSockets.get(userId) || [];
    sockets.push(ws);
    this.userSockets.set(userId, sockets);
    console.log(`[SocketManager] Dashboard client connected for user ${userId}. Total: ${sockets.length}`);
  }

  public removeUserSocket(userId: string, ws: WebSocket) {
    const sockets = this.userSockets.get(userId) || [];
    const index = sockets.indexOf(ws);
    if (index > -1) {
      sockets.splice(index, 1);
      if (sockets.length === 0) {
        this.userSockets.delete(userId);
      } else {
        this.userSockets.set(userId, sockets);
      }
    }
    console.log(`[SocketManager] Dashboard client disconnected for user ${userId}. Remaining: ${sockets.length}`);
  }

  // PHYSICAL DEVICES REGISTER
  public async addDeviceSocket(deviceId: string, ws: WebSocket, userId: string) {
    // If there is an existing socket, close it
    const existing = this.deviceSockets.get(deviceId);
    if (existing) {
      try {
        existing.close();
      } catch (e) {}
    }

    this.deviceSockets.set(deviceId, ws);
    console.log(`[SocketManager] Physical device ${deviceId} connected.`);

    try {
      // Set device state to ONLINE in DB
      await prisma.device.update({
        where: { id: deviceId },
        data: { status: 'ONLINE', lastSeen: new Date() },
      });

      // Broadcast update to user's dashboards
      this.sendToUser(userId, {
        type: 'deviceConnectionChanged',
        deviceId,
        status: 'ONLINE',
      });

      // Create log entry
      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_CONNECTED',
          details: `Device ${deviceId} is online`,
        },
      });
    } catch (err) {
      console.error('[SocketManager] DB update error on device connect:', err);
    }
  }

  public async removeDeviceSocket(deviceId: string, userId: string) {
    this.deviceSockets.delete(deviceId);
    console.log(`[SocketManager] Physical device ${deviceId} disconnected.`);

    try {
      // Set device state to OFFLINE in DB
      await prisma.device.update({
        where: { id: deviceId },
        data: { status: 'OFFLINE', lastSeen: new Date() },
      });

      // Broadcast update to user's dashboards
      this.sendToUser(userId, {
        type: 'deviceConnectionChanged',
        deviceId,
        status: 'OFFLINE',
      });

      // Create log entry
      await prisma.systemLog.create({
        data: {
          action: 'DEVICE_DISCONNECTED',
          details: `Device ${deviceId} went offline`,
        },
      });
    } catch (err) {
      console.error('[SocketManager] DB update error on device disconnect:', err);
    }
  }

  // SEND CONTROL PAYLOAD FROM DASHBOARD -> PHYSICAL DEVICE
  public sendToDevice(deviceId: string, payload: any): boolean {
    // Try sending over WebSocket first
    const ws = this.deviceSockets.get(deviceId);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(payload));
      return true;
    }
    
    // Fallback to sending over MQTT broker
    return sendMqttCommand(deviceId, payload);
  }

  // BROADCAST BROADCAST STATE UPDATE -> USER DASHBOARD CLIENTS
  public sendToUser(userId: string, payload: any) {
    const sockets = this.userSockets.get(userId);
    if (sockets) {
      const message = JSON.stringify(payload);
      for (const ws of sockets) {
        if (ws.readyState === WebSocket.OPEN) {
          ws.send(message);
        }
      }
    }
  }

  // HANDLE DEVICE TELEMETRY / STATUS UPDATES
  public async handleDeviceMessage(deviceId: string, userId: string, rawMessage: string) {
    try {
      const msg = JSON.parse(rawMessage);
      const action = msg.action; // 'telemetry' or 'updateState'
      const properties = msg.properties || {};

      // Increment global log throughput metric
      await prisma.systemLog.create({
        data: {
          action: 'MESSAGE_PROCESSED',
          details: `Message received from device ${deviceId}: ${rawMessage}`,
        },
      });

      // 1. Process Telemetry data (sensor readings)
      if (action === 'telemetry') {
        const device = await prisma.device.findUnique({ where: { id: deviceId } });
        if (!device) return;

        // Save keys of telemetry into database
        for (const [key, val] of Object.entries(properties)) {
          await prisma.telemetry.create({
            data: {
              deviceId,
              property: key,
              value: String(val),
            },
          });

          // Evaluate automation triggers
          await evaluateRules(deviceId, key, val, userId);
        }

        // Broadast to user dashboard clients
        this.sendToUser(userId, {
          type: 'deviceTelemetry',
          deviceId,
          properties,
        });
      }

      // 2. Process State Update confirmations (e.g. power switch was flipped)
      else if (action === 'updateState') {
        const device = await prisma.device.findUnique({ where: { id: deviceId } });
        if (!device) return;

        let currentProps = {};
        try {
          currentProps = JSON.parse(device.properties);
        } catch (e) {}

        const updatedProps = { ...currentProps, ...properties };

        // Save to DB
        await prisma.device.update({
          where: { id: deviceId },
          data: { properties: JSON.stringify(updatedProps), lastSeen: new Date() },
        });

        // Evaluate automation triggers for state updates as well
        for (const [key, val] of Object.entries(properties)) {
          await evaluateRules(deviceId, key, val, userId);
        }

        // Broadcast to user dashboard clients
        this.sendToUser(userId, {
          type: 'deviceStateChanged',
          deviceId,
          properties: updatedProps,
        });
      }
    } catch (err) {
      console.error('[SocketManager] Error handling device message:', err);
    }
  }

  // HANDLE FRONTEND DASHBOARD MESSAGES (actions triggered by owners)
  public async handleDashboardMessage(userId: string, rawMessage: string) {
    try {
      const msg = JSON.parse(rawMessage);
      const { action, deviceId, property, value } = msg;

      // When the dashboard requests a state toggle (e.g. setPowerState)
      if (action === 'control' && deviceId && property && value !== undefined) {
        let cmd = '';
        if (property === 'powerState') {
          cmd = 'setPowerState';
        } else if (property === 'brightness') {
          cmd = 'setBrightness';
        } else if (property === 'targetTemperature') {
          cmd = 'setTargetTemperature';
        } else {
          cmd = `set${property.charAt(0).toUpperCase()}${property.slice(1)}`;
        }

        const device = await prisma.device.findFirst({
          where: { id: deviceId, userId },
        });

        if (device) {
          // Send control packet directly to device WebSocket
          const isOnline = this.sendToDevice(deviceId, {
            action: cmd,
            value: value,
          });

          // Even if offline, update properties in local DB to simulate state persistence
          let currentProps = {};
          try {
            currentProps = JSON.parse(device.properties);
          } catch (e) {}

          const updatedProps = { ...currentProps, [property]: value };

          await prisma.device.update({
            where: { id: deviceId },
            data: { properties: JSON.stringify(updatedProps) },
          });

          // Sync database state changes to all dashboards
          this.sendToUser(userId, {
            type: 'deviceStateChanged',
            deviceId,
            properties: updatedProps,
          });

          await prisma.systemLog.create({
            data: {
              action: 'MESSAGE_PROCESSED',
              details: `Control request from user dashboard to ${device.name}: set ${property} = ${value} (Sent to device: ${isOnline})`,
            },
          });
        }
      }
    } catch (err) {
      console.error('[SocketManager] Error handling dashboard message:', err);
    }
  }
}

export const socketManager = new SocketManager();
