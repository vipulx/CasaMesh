import { Server } from 'http';
import { WebSocketServer, WebSocket, createWebSocketStream } from 'ws';
import jwt from 'jsonwebtoken';
import { parse as parseUrl } from 'url';
import { prisma } from '../services/db';
import { socketManager } from './socketManager';
import { aedesBroker } from '../mqtt/mqttBroker';

const JWT_SECRET = process.env.JWT_SECRET || 'nimbus_iot_super_secret_key_12345!';

export function setupWebSocketServer(server: Server) {
  const wss = new WebSocketServer({ noServer: true });

  // Handle HTTP upgrade requests and route them to their respective channels
  server.on('upgrade', async (request, socket, head) => {
    const { pathname, query } = parseUrl(request.url || '', true);

    if (pathname === '/api/v1/ws/client') {
      // Authenticate browser client via JWT token (passed as search query)
      const token = query.token as string;
      if (!token) {
        socket.write('HTTP/1.1 401 Unauthorized\r\n\r\n');
        socket.destroy();
        return;
      }

      try {
        const decoded = jwt.verify(token, JWT_SECRET) as { userId: string };
        const user = await prisma.user.findUnique({ where: { id: decoded.userId } });

        if (!user) {
          socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
          socket.destroy();
          return;
        }

        wss.handleUpgrade(request, socket, head, (ws) => {
          handleClientConnection(ws, user.id);
        });
      } catch (err) {
        socket.write('HTTP/1.1 403 Forbidden\r\n\r\n');
        socket.destroy();
        return;
      }
    } 
    else if (pathname === '/api/v1/ws/device') {
      // Authenticate physical IoT device via headers or query parameters
      const clientId = (request.headers['x-client-id'] as string) || (query.clientId as string);
      const deviceId = (request.headers['x-device-id'] as string) || (query.deviceId as string);
      const deviceKey = (request.headers['x-device-key'] as string) || (query.deviceKey as string);
      const deviceSecret = (request.headers['x-device-secret'] as string) || (query.deviceSecret as string);

      if (!clientId || !deviceId || !deviceKey || !deviceSecret) {
        socket.write('HTTP/1.1 401 Unauthorized - Missing Auth Info\r\n\r\n');
        socket.destroy();
        return;
      }

      try {
        const user = await prisma.user.findUnique({ where: { clientID: clientId } });
        if (!user) {
          socket.write('HTTP/1.1 403 Forbidden - User client ID invalid\r\n\r\n');
          socket.destroy();
          return;
        }

        const device = await prisma.device.findFirst({
          where: {
            id: deviceId,
            key: deviceKey,
            secret: deviceSecret,
            userId: user.id,
          },
        });

        if (!device) {
          socket.write('HTTP/1.1 403 Forbidden - Device keys invalid\r\n\r\n');
          socket.destroy();
          return;
        }

        wss.handleUpgrade(request, socket, head, (ws) => {
          handleDeviceConnection(ws, device.id, user.id);
        });
      } catch (err) {
        socket.write('HTTP/1.1 500 Internal Server Error\r\n\r\n');
        socket.destroy();
        return;
      }
    } 
    else if (pathname === '/mqtt') {
      // Aedes MQTT-over-WebSockets pipeline
      wss.handleUpgrade(request, socket, head, (ws) => {
        const stream = createWebSocketStream(ws);
        aedesBroker.handle(stream as any);
      });
    }
    else {
      socket.write('HTTP/1.1 404 Not Found\r\n\r\n');
      socket.destroy();
    }
  });

  // Keep-alive check for connections
  const interval = setInterval(() => {
    wss.clients.forEach((ws: any) => {
      if (ws.isAlive === false) {
        return ws.terminate();
      }
      ws.isAlive = false;
      ws.ping();
    });
  }, 30000);

  wss.on('close', () => {
    clearInterval(interval);
  });
}

function handleClientConnection(ws: WebSocket, userId: string) {
  const customWs = ws as any;
  customWs.isAlive = true;
  
  socketManager.addUserSocket(userId, ws);

  ws.on('pong', () => {
    customWs.isAlive = true;
  });

  ws.on('message', (message: string) => {
    socketManager.handleDashboardMessage(userId, message.toString());
  });

  ws.on('close', () => {
    socketManager.removeUserSocket(userId, ws);
  });

  ws.on('error', (err) => {
    console.error(`[WS Client Error] User ${userId}:`, err);
    socketManager.removeUserSocket(userId, ws);
  });
}

function handleDeviceConnection(ws: WebSocket, deviceId: string, userId: string) {
  const customWs = ws as any;
  customWs.isAlive = true;

  socketManager.addDeviceSocket(deviceId, ws, userId);

  ws.on('pong', () => {
    customWs.isAlive = true;
  });

  ws.on('message', (message: string) => {
    socketManager.handleDeviceMessage(deviceId, userId, message.toString());
  });

  ws.on('close', () => {
    socketManager.removeDeviceSocket(deviceId, userId);
  });

  ws.on('error', (err) => {
    console.error(`[WS Device Error] Device ${deviceId}:`, err);
    socketManager.removeDeviceSocket(deviceId, userId);
  });
}
