import { Response } from 'express';
import { prisma } from '../services/db';
import { AuthenticatedRequest } from '../middleware/auth';

export async function createRule(req: AuthenticatedRequest, res: Response) {
  const { name, triggerDeviceId, triggerProperty, operator, triggerValue, actionDeviceId, actionProperty, actionValue } = req.body;
  const userId = req.user?.id;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (!name || !triggerDeviceId || !triggerProperty || !operator || !triggerValue || !actionDeviceId || !actionProperty || !actionValue) {
    return res.status(400).json({ error: 'Missing required automation rule fields' });
  }

  const validOperators = ['EQUALS', 'GREATER_THAN', 'LESS_THAN'];
  if (!validOperators.includes(operator.toUpperCase())) {
    return res.status(400).json({ error: `Invalid operator. Allowed: ${validOperators.join(', ')}` });
  }

  try {
    const rule = await prisma.automationRule.create({
      data: {
        name,
        triggerDeviceId,
        triggerProperty,
        operator: operator.toUpperCase(),
        triggerValue,
        actionDeviceId,
        actionProperty,
        actionValue,
        userId,
      },
    });

    return res.status(201).json(rule);
  } catch (err) {
    console.error('Create rule error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getRules(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const rules = await prisma.automationRule.findMany({
      where: { userId },
      orderBy: { name: 'asc' },
    });
    return res.status(200).json(rules);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function toggleRule(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  const { active } = req.body;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const rule = await prisma.automationRule.findFirst({
      where: { id, userId },
    });

    if (!rule) {
      return res.status(404).json({ error: 'Automation rule not found' });
    }

    const updatedRule = await prisma.automationRule.update({
      where: { id },
      data: { active: Boolean(active) },
    });

    return res.status(200).json(updatedRule);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function deleteRule(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const rule = await prisma.automationRule.findFirst({
      where: { id, userId },
    });

    if (!rule) {
      return res.status(404).json({ error: 'Automation rule not found' });
    }

    await prisma.automationRule.delete({
      where: { id },
    });

    return res.status(200).json({ message: 'Automation rule deleted successfully' });
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}
