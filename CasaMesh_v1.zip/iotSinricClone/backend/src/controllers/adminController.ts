import { Response } from 'express';
import { prisma } from '../services/db';
import { AuthenticatedRequest } from '../middleware/auth';
import os from 'os';

export async function getStats(_req: AuthenticatedRequest, res: Response) {
  try {
    const totalUsers = await prisma.user.count();
    const totalDevices = await prisma.device.count();
    const onlineDevices = await prisma.device.count({ where: { status: 'ONLINE' } });
    const totalTelemetry = await prisma.telemetry.count();
    
    // Calculate message processing counts in the last 24 hours
    const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
    const messagesLastDay = await prisma.systemLog.count({
      where: {
        action: 'MESSAGE_PROCESSED',
        timestamp: { gte: oneDayAgo },
      },
    });

    // Gather host OS system performance stats
    const freeMem = os.freemem();
    const totalMem = os.totalmem();
    const usedMem = totalMem - freeMem;
    const memoryUsagePercent = Math.round((usedMem / totalMem) * 100);

    const systemStats = {
      cpuLoad: os.loadavg(), // 1, 5, 15 min load average
      uptime: os.uptime(),
      memoryUsage: {
        total: Math.round(totalMem / (1024 * 1024)), // MB
        used: Math.round(usedMem / (1024 * 1024)),
        free: Math.round(freeMem / (1024 * 1024)),
        percentage: memoryUsagePercent,
      },
      platform: os.platform(),
      arch: os.arch(),
    };

    return res.status(200).json({
      dbStats: {
        totalUsers,
        totalDevices,
        onlineDevices,
        offlineDevices: totalDevices - onlineDevices,
        totalTelemetry,
        messagesLastDay,
      },
      systemStats,
    });
  } catch (err) {
    console.error('Get admin stats error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getSystemLogs(req: AuthenticatedRequest, res: Response) {
  const limit = req.query.limit ? parseInt(req.query.limit as string) : 100;

  try {
    const logs = await prisma.systemLog.findMany({
      orderBy: { timestamp: 'desc' },
      take: limit,
    });
    return res.status(200).json(logs);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getUsers(_req: AuthenticatedRequest, res: Response) {
  try {
    const users = await prisma.user.findMany({
      select: {
        id: true,
        email: true,
        role: true,
        clientID: true,
        createdAt: true,
        _count: {
          select: { devices: true },
        },
      },
      orderBy: { createdAt: 'desc' },
    });

    const formattedUsers = users.map((u) => ({
      id: u.id,
      email: u.email,
      role: u.role,
      clientID: u.clientID,
      createdAt: u.createdAt,
      deviceCount: u._count.devices,
    }));

    return res.status(200).json(formattedUsers);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}
