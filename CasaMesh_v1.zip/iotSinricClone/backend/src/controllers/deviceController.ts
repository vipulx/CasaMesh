import { Response } from 'express';
import { prisma } from '../services/db';
import { AuthenticatedRequest } from '../middleware/auth';
import { v4 as uuidv4 } from 'uuid';

// Helper to set default properties based on device type
const getDefaultProperties = (type: string) => {
  switch (type.toUpperCase()) {
    case 'SWITCH':
      return JSON.stringify({ powerState: 'Off' });
    case 'LIGHT':
      return JSON.stringify({ powerState: 'Off', brightness: 100, color: { r: 255, g: 255, b: 255 } });
    case 'THERMOSTAT':
      return JSON.stringify({ temperature: 21.0, targetTemperature: 22.0, thermostatMode: 'auto' });
    case 'SENSOR':
      return JSON.stringify({ temperature: 22.0, humidity: 45.0 });
    default:
      return JSON.stringify({});
  }
};

export async function createDevice(req: AuthenticatedRequest, res: Response) {
  const { name, type } = req.body;
  const userId = req.user?.id;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  if (!name || !type) {
    return res.status(400).json({ error: 'Device name and type are required' });
  }

  const validTypes = ['SWITCH', 'LIGHT', 'THERMOSTAT', 'SENSOR'];
  if (!validTypes.includes(type.toUpperCase())) {
    return res.status(400).json({ error: `Invalid device type. Allowed: ${validTypes.join(', ')}` });
  }

  try {
    const device = await prisma.device.create({
      data: {
        name,
        type: type.toUpperCase(),
        key: uuidv4(),
        secret: uuidv4(),
        properties: getDefaultProperties(type),
        userId,
      },
    });

    await prisma.systemLog.create({
      data: {
        action: 'DEVICE_CREATED',
        details: `Device ${device.name} (type: ${device.type}) registered by user ID ${userId}`,
      },
    });

    return res.status(201).json(device);
  } catch (err) {
    console.error('Create device error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getDevices(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const devices = await prisma.device.findMany({
      where: { userId },
      orderBy: { name: 'asc' },
    });
    return res.status(200).json(devices);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getDevice(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const device = await prisma.device.findFirst({
      where: { id, userId },
    });

    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }

    return res.status(200).json(device);
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function deleteDevice(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const device = await prisma.device.findFirst({
      where: { id, userId },
    });

    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }

    await prisma.device.delete({
      where: { id },
    });

    await prisma.systemLog.create({
      data: {
        action: 'DEVICE_DELETED',
        details: `Device ${device.name} (type: ${device.type}) deleted by user ID ${userId}`,
      },
    });

    return res.status(200).json({ message: 'Device deleted successfully' });
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getDeviceTelemetry(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  const limit = req.query.limit ? parseInt(req.query.limit as string) : 50;

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const device = await prisma.device.findFirst({
      where: { id, userId },
    });

    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }

    const telemetry = await prisma.telemetry.findMany({
      where: { deviceId: id },
      orderBy: { timestamp: 'desc' },
      take: limit,
    });

    return res.status(200).json(telemetry.reverse());
  } catch (err) {
    return res.status(500).json({ error: 'Internal server error' });
  }
}

export async function getDeviceTemplate(req: AuthenticatedRequest, res: Response) {
  const userId = req.user?.id;
  const { id } = req.params;
  const { type } = req.query; // 'arduino' or 'python'

  if (!userId) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  try {
    const device = await prisma.device.findFirst({
      where: { id, userId },
    });

    if (!device) {
      return res.status(404).json({ error: 'Device not found' });
    }

    const host = req.headers.host || 'iot.siddhart.qzz.io';
    const isSsl = req.secure || req.headers['x-forwarded-proto'] === 'https';
    const wsProto = isSsl ? 'wss' : 'ws';
    const wsUrl = `${wsProto}://${host}/api/v1/ws/device`;

    if (type === 'python') {
      const pyCode = `import asyncio
import websockets
import json
import random
import time

DEVICE_ID = "${device.id}"
DEVICE_KEY = "${device.key}"
DEVICE_SECRET = "${device.secret}"
WS_URL = "${wsUrl}"

async function connect_device():
    print(f"Connecting to NimbusIoT: {WS_URL}...")
    headers = {
        "x-client-id": "${req.user?.clientID}",
        "x-device-id": DEVICE_ID,
        "x-device-key": DEVICE_KEY,
        "x-device-secret": DEVICE_SECRET
    }
    
    async for websocket in websockets.connect(WS_URL, extra_headers=headers):
        try:
            print("Connected to cloud!")
            # Spawn a task to send periodic telemetry if device is a SENSOR
            if "${device.type}" == "SENSOR":
                asyncio.create_task(send_telemetry(websocket))
            
            async for message in websocket:
                data = json.loads(message)
                print("Received command:", data)
                
                # Handle control action
                action = data.get("action")
                if action == "setPowerState":
                    state = data.get("value")
                    print(f"Setting physical power to: {state}")
                    # Respond with updateState confirmation
                    confirm = {
                        "action": "updateState",
                        "properties": {
                            "powerState": state
                        }
                    }
                    await websocket.send(json.dumps(confirm))
                elif action == "setBrightness":
                    val = data.get("value")
                    print(f"Setting physical brightness to: {val}")
                    confirm = {
                        "action": "updateState",
                        "properties": {
                            "brightness": val
                        }
                    }
                    await websocket.send(json.dumps(confirm))
                elif action == "setTargetTemperature":
                    val = data.get("value")
                    print(f"Setting target temperature to: {val}")
                    confirm = {
                        "action": "updateState",
                        "properties": {
                            "targetTemperature": val
                        }
                    }
                    await websocket.send(json.dumps(confirm))
        except websockets.ConnectionClosed:
            print("Connection lost. Retrying in 5 seconds...")
            await asyncio.sleep(5)
        except Exception as e:
            print("Error:", e)
            await asyncio.sleep(5)

async def send_telemetry(websocket):
    while True:
        try:
            # Simulate real sensor readings
            temp = round(20.0 + random.uniform(-3, 5), 1)
            hum = round(50.0 + random.uniform(-10, 10), 1)
            
            payload = {
                "action": "telemetry",
                "properties": {
                    "temperature": temp,
                    "humidity": hum
                }
            }
            await websocket.send(json.dumps(payload))
            print(f"Sent sensor telemetry: temp={temp}C, hum={hum}%")
            await asyncio.sleep(10)  # Telemetry interval (seconds)
        except Exception as e:
            print("Telemetry send failed:", e)
            break

if __name__ == "__main__":
    asyncio.run(connect_device())
`;
      return res.status(200).json({ code: pyCode });
    } else {
      // Default to Arduino/C++ ESP32/ESP8266 WebSocket template
      const inoCode = `/*
 * NimbusIoT ESP32 Device Template
 * Redesigned for self-hosted secure WebSocket connections.
 */

#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>

const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

const char* ws_host = "${host.split(':')[0]}";
const int ws_port = ${host.split(':')[1] ? parseInt(host.split(':')[1]) : (isSsl ? 443 : 80)};
const char* ws_path = "/api/v1/ws/device";

const char* deviceId = "${device.id}";
const char* deviceKey = "${device.key}";
const char* deviceSecret = "${device.secret}";
const char* clientId = "${req.user?.clientID}";

WebSocketsClient webSocket;
unsigned long lastTelemetryTime = 0;

void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
  switch(type) {
    case WStype_DISCONNECTED:
      Serial.println("[WS] Disconnected!");
      break;
    case WStype_CONNECTED:
      Serial.println("[WS] Connected to NimbusIoT cloud!");
      break;
    case WStype_TEXT: {
      Serial.printf("[WS] Received payload: %s\\n", payload);
      
      StaticJsonDocument<256> doc;
      DeserializationError error = deserializeJson(doc, payload, length);
      if (error) {
        Serial.print(F("deserializeJson() failed: "));
        Serial.println(error.f_str());
        return;
      }
      
      const char* action = doc["action"];
      if (strcmp(action, "setPowerState") == 0) {
        const char* val = doc["value"];
        Serial.printf("Setting physical power to: %s\\n", val);
        
        // Control your hardware pin here (e.g. digitalWrite)
        
        // Send state confirmation back to dashboard
        StaticJsonDocument<256> confirmDoc;
        confirmDoc["action"] = "updateState";
        JsonObject props = confirmDoc.createNestedObject("properties");
        props["powerState"] = val;
        
        String response;
        serializeJson(confirmDoc, response);
        webSocket.sendTXT(response);
      }
      break;
    }
    case WStype_BIN:
      break;
  }
}

void setup() {
  Serial.begin(115200);
  
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\\nWiFi connected!");

  // Build HTTP Header auth fields
  String headers = "x-client-id: " + String(clientId) + "\\r\\n" +
                   "x-device-id: " + String(deviceId) + "\\r\\n" +
                   "x-device-key: " + String(deviceKey) + "\\r\\n" +
                   "x-device-secret: " + String(deviceSecret);

  // Setup WS Connection
  if (${isSsl ? 'true' : 'false'}) {
    webSocket.beginSSL(ws_host, ws_port, ws_path);
  } else {
    webSocket.begin(ws_host, ws_port, ws_path);
  }
  webSocket.setExtraHeaders(headers.c_str());
  webSocket.onEvent(webSocketEvent);
  webSocket.enableHeartbeat(15000, 3000, 2);
}

void loop() {
  webSocket.loop();
  
  // Periodic sensor readings for SENSOR type
  if (strcmp("${device.type}", "SENSOR") == 0) {
    unsigned long now = millis();
    if (now - lastTelemetryTime > 10000) { // every 10s
      lastTelemetryTime = now;
      
      StaticJsonDocument<256> telemetryDoc;
      telemetryDoc["action"] = "telemetry";
      JsonObject props = telemetryDoc.createNestedObject("properties");
      
      // Simulate physical sensor values
      props["temperature"] = 22.0 + (rand() % 20) / 10.0;
      props["humidity"] = 45.0 + (rand() % 100) / 10.0;
      
      String payload;
      serializeJson(telemetryDoc, payload);
      webSocket.sendTXT(payload);
      Serial.println("[WS] Sent simulated telemetry data");
    }
  }
}
`;
      return res.status(200).json({ code: inoCode });
    }
  } catch (err) {
    console.error('Get device template error:', err);
    return res.status(500).json({ error: 'Internal server error' });
  }
}
