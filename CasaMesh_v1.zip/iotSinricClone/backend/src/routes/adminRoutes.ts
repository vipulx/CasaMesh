import { Router } from 'express';
import { getStats, getSystemLogs, getUsers } from '../controllers/adminController';
import { authenticateToken, isAdmin } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);
router.use(isAdmin);

router.get('/stats', getStats);
router.get('/logs', getSystemLogs);
router.get('/users', getUsers);

export default router;
