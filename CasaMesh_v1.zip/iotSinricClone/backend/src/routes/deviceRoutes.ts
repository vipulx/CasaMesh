import { Router } from 'express';
import {
  createDevice,
  getDevices,
  getDevice,
  deleteDevice,
  getDeviceTelemetry,
  getDeviceTemplate,
} from '../controllers/deviceController';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);

router.post('/', createDevice);
router.get('/', getDevices);
router.get('/:id', getDevice);
router.delete('/:id', deleteDevice);
router.get('/:id/telemetry', getDeviceTelemetry);
router.get('/:id/template', getDeviceTemplate);

export default router;
