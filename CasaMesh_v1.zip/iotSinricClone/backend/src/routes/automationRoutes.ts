import { Router } from 'express';
import { createRule, getRules, toggleRule, deleteRule } from '../controllers/automationController';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);

router.post('/', createRule);
router.get('/', getRules);
router.patch('/:id', toggleRule);
router.delete('/:id', deleteRule);

export default router;
