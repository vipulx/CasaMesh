import { useState, useEffect, useRef } from 'react';
import { 
  Cpu, LayoutDashboard, Settings, LogOut, Shield, 
  Menu, X, User, Activity 
} from 'lucide-react';

import { Login, Signup } from './views/AuthViews';
import DashboardView from './views/DashboardView';
import AutomationsView from './views/AutomationsView';
import IntegrationsView from './views/IntegrationsView';
import AdminConsoleView from './views/AdminConsoleView';

// Determine API and WebSocket paths dynamically to support both local Vite and Cloudflare Tunnels
const API_BASE = window.location.port === '5173'
  ? `http://${window.location.hostname}:3001`
  : window.location.origin;

const isSsl = window.location.protocol === 'https:';
const wsProto = isSsl ? 'wss' : 'ws';
const WS_BASE = window.location.port === '5173'
  ? `${wsProto}://${window.location.hostname}:3001`
  : `${wsProto}://${window.location.host}`;

export default function App() {
  const [token, setToken] = useState<string | null>(localStorage.getItem('nimbus_token'));
  const [user, setUser] = useState<any>(JSON.parse(localStorage.getItem('nimbus_user') || 'null'));
  const [devices, setDevices] = useState<any[]>([]);
  const [activeView, setActiveView] = useState<'dashboard' | 'automations' | 'integrations' | 'admin'>('dashboard');
  
  // Auth view toggles
  const [showSignup, setShowSignup] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  // WebSockets States
  const [wsMessage, setWsMessage] = useState<any>(null);
  const [wsConnected, setWsConnected] = useState(false);
  const wsRef = useRef<WebSocket | null>(null);

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json'
  };

  const handleAuthSuccess = (newToken: string, newUser: any) => {
    localStorage.setItem('nimbus_token', newToken);
    localStorage.setItem('nimbus_user', JSON.stringify(newUser));
    setToken(newToken);
    setUser(newUser);
  };

  const handleSignOut = () => {
    localStorage.removeItem('nimbus_token');
    localStorage.removeItem('nimbus_user');
    setToken(null);
    setUser(null);
    setDevices([]);
    setWsConnected(false);
    if (wsRef.current) wsRef.current.close();
  };

  // Fetch list of registered devices
  const fetchDevices = async () => {
    if (!token) return;
    try {
      const res = await fetch(`${API_BASE}/api/v1/devices`, { headers });
      const data = await res.json();
      if (res.ok) {
        setDevices(data);
      }
    } catch (e) {
      console.error('Fetch devices error:', e);
    }
  };

  useEffect(() => {
    if (token) {
      fetchDevices();
    }
  }, [token]);

  // Handle Client WebSockets link for real-time telemetry updates
  useEffect(() => {
    if (!token) return;

    let reconnectTimeout: any;

    const connectWs = () => {
      const wsUrl = `${WS_BASE}/api/v1/ws/client?token=${token}`;
      console.log(`[WebSocket] Connecting client: ${wsUrl}...`);
      
      const ws = new WebSocket(wsUrl);
      wsRef.current = ws;

      ws.onopen = () => {
        console.log('[WebSocket] Client channel established successfully.');
        setWsConnected(true);
      };

      ws.onmessage = (event) => {
        try {
          const msg = JSON.parse(event.data);
          setWsMessage(msg);
        } catch (e) {}
      };

      ws.onclose = () => {
        console.log('[WebSocket] Connection closed. Reconnecting in 5s...');
        setWsConnected(false);
        reconnectTimeout = setTimeout(connectWs, 5000);
      };

      ws.onerror = (err) => {
        console.error('[WebSocket] Error caught:', err);
        ws.close();
      };
    };

    connectWs();

    return () => {
      clearTimeout(reconnectTimeout);
      if (wsRef.current) {
        wsRef.current.onclose = null; // Prevent reconnect
        wsRef.current.close();
      }
    };
  }, [token]);

  // Helper to publish control data packets
  const sendWsMessage = (msg: any) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify(msg));
    }
  };

  if (!token) {
    return (
      <div style={styles.authWrapper}>
        {showSignup ? (
          <Signup 
            apiBase={API_BASE} 
            onAuthSuccess={handleAuthSuccess} 
            onToggleAuth={() => setShowSignup(false)} 
          />
        ) : (
          <Login 
            apiBase={API_BASE} 
            onAuthSuccess={handleAuthSuccess} 
          />
        )}
        
        <button 
          onClick={() => setShowSignup(!showSignup)} 
          style={styles.authToggleBtn}
          className="btn btn-secondary"
        >
          {showSignup ? 'Already have an account? Sign In' : 'Need a self-hosted account? Register'}
        </button>
      </div>
    );
  }

  return (
    <div style={styles.layout}>
      {/* Sidebar Navigation */}
      <aside style={{ ...styles.sidebar, left: mobileMenuOpen ? '0' : '-260px' }} className="glass-panel">
        <div style={styles.branding}>
          <div style={styles.logoCircle}>
            <Cpu size={24} color="var(--color-primary)" />
          </div>
          <span style={styles.brandName}>Nimbus<span>IoT</span></span>
        </div>

        <nav style={styles.navigation}>
          <button 
            onClick={() => { setActiveView('dashboard'); setMobileMenuOpen(false); }}
            style={{ ...styles.navBtn, background: activeView === 'dashboard' ? 'rgba(99, 102, 241, 0.1)' : 'transparent', color: activeView === 'dashboard' ? '#fff' : 'var(--text-secondary)' }}
          >
            <LayoutDashboard size={18} />
            Devices Grid
          </button>

          <button 
            onClick={() => { setActiveView('automations'); setMobileMenuOpen(false); }}
            style={{ ...styles.navBtn, background: activeView === 'automations' ? 'rgba(99, 102, 241, 0.1)' : 'transparent', color: activeView === 'automations' ? '#fff' : 'var(--text-secondary)' }}
          >
            <Activity size={18} />
            Automations
          </button>

          <button 
            onClick={() => { setActiveView('integrations'); setMobileMenuOpen(false); }}
            style={{ ...styles.navBtn, background: activeView === 'integrations' ? 'rgba(99, 102, 241, 0.1)' : 'transparent', color: activeView === 'integrations' ? '#fff' : 'var(--text-secondary)' }}
          >
            <Settings size={18} />
            Integrations
          </button>

          {user?.role === 'ADMIN' && (
            <button 
              onClick={() => { setActiveView('admin'); setMobileMenuOpen(false); }}
              style={{ ...styles.navBtn, background: activeView === 'admin' ? 'rgba(99, 102, 241, 0.1)' : 'transparent', color: activeView === 'admin' ? '#fff' : 'var(--text-secondary)' }}
            >
              <Shield size={18} />
              Owner Console
            </button>
          )}
        </nav>

        <div style={styles.sidebarFooter}>
          <div style={styles.profileRow}>
            <div style={styles.avatar}>
              <User size={16} />
            </div>
            <div style={styles.profileDetails}>
              <span style={styles.profileEmail}>{user?.email}</span>
              <span style={styles.profileRole}>{user?.role}</span>
            </div>
          </div>

          <button onClick={handleSignOut} style={styles.signOutBtn} className="btn btn-secondary">
            <LogOut size={16} />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Panel Frame */}
      <div style={styles.mainFrame}>
        {/* Top Navbar */}
        <header style={styles.navbar} className="glass-panel">
          <div style={styles.navLeft}>
            <button style={styles.menuToggle} onClick={() => setMobileMenuOpen(!mobileMenuOpen)}>
              {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
            </button>
            <div style={styles.wsIndicator}>
              <span className={`status-indicator ${wsConnected ? 'status-online' : 'status-offline'}`}></span>
              <span style={styles.wsText}>{wsConnected ? 'Cloud Sync Online' : 'Connecting to Cloud...'}</span>
            </div>
          </div>
          <div style={styles.navRight}>
            <span style={styles.tag}>v1.0.0 Stable</span>
          </div>
        </header>

        {/* View Router */}
        <main style={styles.content}>
          {activeView === 'dashboard' && (
            <DashboardView 
              apiBase={API_BASE} 
              token={token} 
              devices={devices} 
              setDevices={setDevices} 
              wsMessage={wsMessage}
              sendWsMessage={sendWsMessage}
            />
          )}

          {activeView === 'automations' && (
            <AutomationsView 
              apiBase={API_BASE} 
              token={token} 
              devices={devices} 
            />
          )}

          {activeView === 'integrations' && (
            <IntegrationsView 
              user={user} 
            />
          )}

          {activeView === 'admin' && user?.role === 'ADMIN' && (
            <AdminConsoleView 
              apiBase={API_BASE} 
              token={token} 
            />
          )}
        </main>
      </div>
    </div>
  );
}

const styles = {
  authWrapper: {
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    background: '#0a0814',
    position: 'relative' as const,
    zIndex: 1,
  },
  authToggleBtn: {
    marginTop: '16px',
    fontSize: '13px',
    padding: '8px 16px',
    background: 'transparent',
    border: 'none',
    color: '#94a3b8',
    cursor: 'pointer',
    textDecoration: 'underline',
  },
  layout: {
    display: 'flex',
    minHeight: '100vh',
    position: 'relative' as const,
  },
  sidebar: {
    width: '260px',
    height: '100vh',
    position: 'fixed' as const,
    top: 0,
    bottom: 0,
    zIndex: 50,
    borderRadius: '0',
    borderTop: 'none',
    borderBottom: 'none',
    borderLeft: 'none',
    display: 'flex',
    flexDirection: 'column' as const,
    padding: '24px 16px',
    gap: '24px',
    transition: 'left 0.3s cubic-bezier(0.4, 0, 0.2, 1)',
    '@media (max-width: 991px)': {
      boxShadow: '4px 0 30px rgba(0,0,0,0.8)',
    },
  },
  branding: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    paddingLeft: '8px',
  },
  logoCircle: {
    width: '40px',
    height: '40px',
    borderRadius: '10px',
    background: 'rgba(99, 102, 241, 0.08)',
    border: '1px solid rgba(99, 102, 241, 0.2)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    boxShadow: '0 0 15px rgba(99, 102, 241, 0.2)',
  },
  brandName: {
    fontSize: '20px',
    fontWeight: 700,
    color: '#fff',
    span: { color: 'var(--color-primary)' },
  },
  navigation: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '8px',
    flex: 1,
  },
  navBtn: {
    display: 'flex',
    alignItems: 'center',
    gap: '12px',
    padding: '12px 16px',
    borderRadius: '10px',
    border: 'none',
    fontSize: '14px',
    fontWeight: 600,
    textAlign: 'left' as const,
    cursor: 'pointer',
    transition: 'all 0.2s',
    outline: 'none',
    '&:hover': {
      background: 'rgba(255,255,255,0.03)',
      color: '#fff',
    },
  },
  sidebarFooter: {
    borderTop: '1px solid rgba(255, 255, 255, 0.06)',
    paddingTop: '16px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '14px',
  },
  profileRow: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    paddingLeft: '6px',
  },
  avatar: {
    width: '32px',
    height: '32px',
    borderRadius: '50%',
    background: 'rgba(255,255,255,0.05)',
    border: '1px solid rgba(255,255,255,0.1)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    color: '#fff',
  },
  profileDetails: {
    display: 'flex',
    flexDirection: 'column' as const,
    width: '150px',
  },
  profileEmail: {
    fontSize: '12px',
    color: '#fff',
    fontWeight: 500,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap' as const,
  },
  profileRole: {
    fontSize: '10px',
    color: 'var(--color-primary)',
    fontWeight: 600,
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  signOutBtn: {
    width: '100%',
    padding: '10px',
    fontSize: '13px',
  },
  mainFrame: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column' as const,
    marginLeft: '260px',
    minHeight: '100vh',
    width: 'calc(100% - 260px)',
    '@media (max-width: 991px)': {
      marginLeft: '0',
      width: '100%',
    },
  },
  navbar: {
    height: '64px',
    borderRadius: '0',
    borderTop: 'none',
    borderRight: 'none',
    borderLeft: 'none',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '0 24px',
    position: 'sticky' as const,
    top: 0,
    zIndex: 40,
  },
  navLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
  },
  menuToggle: {
    background: 'transparent',
    border: 'none',
    color: '#fff',
    cursor: 'pointer',
    display: 'none',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '4px',
    '@media (max-width: 991px)': {
      display: 'flex',
    },
  },
  wsIndicator: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  wsText: {
    fontSize: '13px',
    color: '#94a3b8',
    fontWeight: 500,
  },
  navRight: {
    display: 'flex',
    alignItems: 'center',
  },
  tag: {
    background: 'rgba(255, 255, 255, 0.03)',
    border: '1px solid rgba(255,255,255,0.06)',
    padding: '4px 10px',
    borderRadius: '20px',
    fontSize: '11px',
    fontWeight: 600,
    color: 'var(--text-secondary)',
  },
  content: {
    flex: 1,
    position: 'relative' as const,
  },
};
