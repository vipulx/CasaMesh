import React, { useState } from 'react';
import { LogIn, UserPlus, ShieldAlert, Cpu } from 'lucide-react';

interface AuthProps {
  apiBase: string;
  onAuthSuccess: (token: string, user: any) => void;
}

export function Login({ apiBase, onAuthSuccess }: AuthProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const res = await fetch(`${apiBase}/api/v1/auth/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Login failed');
      }

      onAuthSuccess(data.token, data.user);
    } catch (err: any) {
      setError(err.message || 'Server connection error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.authContainer} className="animate-fade-in">
      <div style={styles.branding}>
        <div style={styles.logoCircle}>
          <Cpu size={32} color="#6366f1" />
        </div>
        <h1 style={styles.brandTitle}>Nimbus<span>IoT</span></h1>
        <p style={styles.brandSubtitle}>Production-Grade Self-Hosted IoT Platform</p>
      </div>

      <div className="glass-panel" style={styles.authCard}>
        <h2 style={styles.cardHeader}>Welcome Back</h2>
        <p style={styles.cardSubheader}>Sign in to control and monitor your devices</p>

        {error && (
          <div style={styles.errorAlert}>
            <ShieldAlert size={18} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Email Address</label>
            <input
              type="email"
              className="input-field"
              placeholder="name@domain.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary" style={styles.submitBtn} disabled={loading}>
            <LogIn size={18} />
            {loading ? 'Signing in...' : 'Sign In'}
          </button>
        </form>
      </div>
    </div>
  );
}

export function Signup({ apiBase, onAuthSuccess }: AuthProps & { onToggleAuth: () => void }) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (password !== confirmPassword) {
      setError('Passwords do not match');
      return;
    }

    setLoading(true);

    try {
      const res = await fetch(`${apiBase}/api/v1/auth/register`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password }),
      });

      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'Registration failed');
      }

      onAuthSuccess(data.token, data.user);
    } catch (err: any) {
      setError(err.message || 'Server connection error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={styles.authContainer} className="animate-fade-in">
      <div style={styles.branding}>
        <div style={styles.logoCircle}>
          <Cpu size={32} color="#d946ef" />
        </div>
        <h1 style={styles.brandTitle}>Nimbus<span>IoT</span></h1>
        <p style={styles.brandSubtitle}>Create your cloud account</p>
      </div>

      <div className="glass-panel" style={styles.authCard}>
        <h2 style={styles.cardHeader}>Get Started</h2>
        <p style={styles.cardSubheader}>Create an account. First user will be Admin.</p>

        {error && (
          <div style={styles.errorAlert}>
            <ShieldAlert size={18} />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} style={styles.form}>
          <div style={styles.inputGroup}>
            <label style={styles.label}>Email Address</label>
            <input
              type="email"
              className="input-field"
              placeholder="name@domain.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="••••••••"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              required
            />
          </div>

          <div style={styles.inputGroup}>
            <label style={styles.label}>Confirm Password</label>
            <input
              type="password"
              className="input-field"
              placeholder="••••••••"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              required
            />
          </div>

          <button type="submit" className="btn btn-primary" style={styles.submitBtn} disabled={loading}>
            <UserPlus size={18} />
            {loading ? 'Creating account...' : 'Create Account'}
          </button>
        </form>
      </div>
    </div>
  );
}

const styles = {
  authContainer: {
    display: 'flex',
    flexDirection: 'column' as const,
    alignItems: 'center',
    justifyContent: 'center',
    minHeight: '100vh',
    padding: '20px',
  },
  branding: {
    textAlign: 'center' as const,
    marginBottom: '24px',
  },
  logoCircle: {
    width: '64px',
    height: '64px',
    borderRadius: '50%',
    background: 'rgba(255, 255, 255, 0.03)',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '0 auto 16px auto',
    boxShadow: '0 0 20px rgba(99, 102, 241, 0.1)',
  },
  brandTitle: {
    fontSize: '32px',
    fontWeight: 700,
    color: '#fff',
    margin: '0',
  },
  brandSubtitle: {
    fontSize: '14px',
    color: '#94a3b8',
    marginTop: '6px',
  },
  authCard: {
    width: '100%',
    maxWidth: '400px',
    padding: '32px 28px',
  },
  cardHeader: {
    fontSize: '22px',
    fontWeight: 600,
    textAlign: 'center' as const,
    color: '#fff',
  },
  cardSubheader: {
    fontSize: '13px',
    color: '#94a3b8',
    textAlign: 'center' as const,
    marginTop: '6px',
    marginBottom: '24px',
  },
  errorAlert: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    background: 'rgba(239, 68, 68, 0.1)',
    border: '1px solid rgba(239, 68, 68, 0.3)',
    color: '#fca5a5',
    padding: '12px 16px',
    borderRadius: '8px',
    fontSize: '13px',
    marginBottom: '20px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '6px',
  },
  label: {
    fontSize: '12px',
    fontWeight: 600,
    color: '#94a3b8',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  submitBtn: {
    marginTop: '10px',
    width: '100%',
  },
};
