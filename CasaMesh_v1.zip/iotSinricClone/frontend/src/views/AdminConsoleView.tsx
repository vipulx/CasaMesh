import { useState, useEffect } from 'react';
import { Users, HardDrive, Cpu, Terminal, RefreshCw, Layers } from 'lucide-react';
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface AdminStats {
  dbStats: {
    totalUsers: number;
    totalDevices: number;
    onlineDevices: number;
    offlineDevices: number;
    totalTelemetry: number;
    messagesLastDay: number;
  };
  systemStats: {
    cpuLoad: number[];
    uptime: number;
    memoryUsage: {
      total: number;
      used: number;
      free: number;
      percentage: number;
    };
    platform: string;
    arch: string;
  };
}

interface User {
  id: string;
  email: string;
  role: string;
  clientID: string;
  createdAt: string;
  deviceCount: number;
}

interface SystemLog {
  id: string;
  action: string;
  details: string;
  timestamp: string;
}

interface AdminConsoleProps {
  apiBase: string;
  token: string;
}

export default function AdminConsoleView({ apiBase, token }: AdminConsoleProps) {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [users, setUsers] = useState<User[]>([]);
  const [logs, setLogs] = useState<SystemLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [error, setError] = useState('');

  const headers = {
    'Authorization': `Bearer ${token}`,
    'Content-Type': 'application/json',
  };

  const fetchAdminData = async () => {
    setRefreshing(true);
    try {
      // 1. Fetch system stats
      const statsRes = await fetch(`${apiBase}/api/v1/admin/stats`, { headers });
      if (!statsRes.ok) throw new Error('Failed to fetch admin stats');
      const statsData = await statsRes.json();
      setStats(statsData);

      // 2. Fetch users list
      const usersRes = await fetch(`${apiBase}/api/v1/admin/users`, { headers });
      if (!usersRes.ok) throw new Error('Failed to fetch admin users');
      const usersData = await usersRes.json();
      setUsers(usersData);

      // 3. Fetch system logs
      const logsRes = await fetch(`${apiBase}/api/v1/admin/logs?limit=50`, { headers });
      if (!logsRes.ok) throw new Error('Failed to fetch system logs');
      const logsData = await logsRes.json();
      setLogs(logsData);
    } catch (err: any) {
      setError(err.message || 'Error fetching administrator console details');
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  };

  useEffect(() => {
    fetchAdminData();
    // Poll stats every 15 seconds
    const interval = setInterval(fetchAdminData, 15000);
    return () => clearInterval(interval);
  }, []);

  const formatUptime = (seconds: number) => {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    return `${d}d ${h}h ${m}m`;
  };

  // Mock message throughput data for visual dashboard display
  const chartData = [
    { name: '00:00', messages: Math.round((stats?.dbStats.messagesLastDay || 100) * 0.08) },
    { name: '04:00', messages: Math.round((stats?.dbStats.messagesLastDay || 100) * 0.12) },
    { name: '08:00', messages: Math.round((stats?.dbStats.messagesLastDay || 100) * 0.18) },
    { name: '12:00', messages: Math.round((stats?.dbStats.messagesLastDay || 100) * 0.22) },
    { name: '16:00', messages: Math.round((stats?.dbStats.messagesLastDay || 100) * 0.25) },
    { name: '20:00', messages: Math.round((stats?.dbStats.messagesLastDay || 100) * 0.15) },
  ];

  if (loading) {
    return <div style={styles.loadingCenter}>Booting Owner Administrator Console...</div>;
  }

  return (
    <div style={styles.container} className="animate-fade-in">
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>System Analytics Dashboard</h1>
          <p style={styles.subtitle}>Global metrics, host system resource monitoring, and message logging audit trace.</p>
        </div>
        <button 
          onClick={fetchAdminData} 
          className="btn btn-secondary" 
          disabled={refreshing}
          style={styles.refreshBtn}
        >
          <RefreshCw size={14} className={refreshing ? 'animate-spin' : ''} />
          {refreshing ? 'Refreshing...' : 'Refresh Stats'}
        </button>
      </div>

      {error && <div style={styles.errorAlert}>{error}</div>}

      {/* KPI Cards */}
      {stats && (
        <div style={styles.kpiGrid}>
          <div className="glass-panel" style={styles.kpiCard}>
            <Users size={24} color="#6366f1" />
            <div>
              <span style={styles.kpiLabel}>Total Registered Users</span>
              <strong style={styles.kpiVal}>{stats.dbStats.totalUsers}</strong>
            </div>
          </div>

          <div className="glass-panel" style={styles.kpiCard}>
            <HardDrive size={24} color="#d946ef" />
            <div>
              <span style={styles.kpiLabel}>Registered Devices</span>
              <strong style={styles.kpiVal}>
                {stats.dbStats.totalDevices} 
                <span style={styles.kpiSubval}> ({stats.dbStats.onlineDevices} Online)</span>
              </strong>
            </div>
          </div>

          <div className="glass-panel" style={styles.kpiCard}>
            <Layers size={24} color="#10b981" />
            <div>
              <span style={styles.kpiLabel}>Total Message Throughput</span>
              <strong style={styles.kpiVal}>{stats.dbStats.totalTelemetry}</strong>
            </div>
          </div>

          <div className="glass-panel" style={styles.kpiCard}>
            <Cpu size={24} color="#f59e0b" />
            <div>
              <span style={styles.kpiLabel}>System Uptime (OS)</span>
              <strong style={styles.kpiVal}>{formatUptime(stats.systemStats.uptime)}</strong>
            </div>
          </div>
        </div>
      )}

      {/* Secondary layout */}
      <div style={styles.mainGrid}>
        {/* Performance & Charts */}
        <div style={styles.leftCol}>
          {stats && (
            <div className="glass-panel" style={styles.statsCard}>
              <h2 style={styles.sectionTitle}>Host Resource Usage</h2>
              
              <div style={styles.resourceRow}>
                <div style={styles.resourceHeader}>
                  <span>CPU Load Average (1 / 5 / 15 min)</span>
                  <strong>{stats.systemStats.cpuLoad.map(c => c.toFixed(2)).join(' / ')}</strong>
                </div>
              </div>

              <div style={styles.resourceRow}>
                <div style={styles.resourceHeader}>
                  <span>Memory (RAM)</span>
                  <strong>{stats.systemStats.memoryUsage.used}MB / {stats.systemStats.memoryUsage.total}MB ({stats.systemStats.memoryUsage.percentage}%)</strong>
                </div>
                <div style={styles.barContainer}>
                  <div style={{
                    ...styles.barFill,
                    width: `${stats.systemStats.memoryUsage.percentage}%`,
                    background: stats.systemStats.memoryUsage.percentage > 85 ? 'var(--color-danger)' : 'var(--color-primary)'
                  }}></div>
                </div>
              </div>

              <div style={styles.sysMetaGrid}>
                <div style={styles.sysMetaItem}>
                  <span>OS Platform</span>
                  <strong>{stats.systemStats.platform} ({stats.systemStats.arch})</strong>
                </div>
                <div style={styles.sysMetaItem}>
                  <span>Messages (24h)</span>
                  <strong>{stats.dbStats.messagesLastDay} processed</strong>
                </div>
              </div>
            </div>
          )}

          {/* Telemetry charts */}
          <div className="glass-panel" style={styles.chartCard}>
            <h2 style={styles.sectionTitle}>Message Rates (last 24h)</h2>
            <div style={{ width: '100%', height: 200, marginTop: '16px' }}>
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={chartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <defs>
                    <linearGradient id="colorMsg" x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="var(--color-primary)" stopOpacity={0.4}/>
                      <stop offset="95%" stopColor="var(--color-primary)" stopOpacity={0}/>
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" />
                  <XAxis dataKey="name" stroke="var(--text-muted)" fontSize={11} />
                  <YAxis stroke="var(--text-muted)" fontSize={11} />
                  <Tooltip 
                    contentStyle={{ 
                      background: 'rgba(10, 8, 20, 0.95)', 
                      borderColor: 'rgba(255,255,255,0.1)',
                      borderRadius: '8px'
                    }}
                  />
                  <Area type="monotone" dataKey="messages" stroke="var(--color-primary)" strokeWidth={2} fillOpacity={1} fill="url(#colorMsg)" />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Users Table */}
          <div className="glass-panel" style={styles.tableCard}>
            <div style={styles.tableHeader}>
              <h2 style={styles.sectionTitle}>Registered Users</h2>
              <span style={styles.badge}>{users.length} Users</span>
            </div>
            <div style={styles.tableWrapper}>
              <table style={styles.table}>
                <thead>
                  <tr>
                    <th>Email</th>
                    <th>Role</th>
                    <th>Joined</th>
                    <th>Devices</th>
                  </tr>
                </thead>
                <tbody>
                  {users.map(u => (
                    <tr key={u.id}>
                      <td style={styles.userEmail}>{u.email}</td>
                      <td>
                        <span style={{
                          ...styles.roleBadge,
                          background: u.role === 'ADMIN' ? 'rgba(245, 158, 11, 0.15)' : 'rgba(255,255,255,0.03)',
                          color: u.role === 'ADMIN' ? 'var(--color-warning)' : 'var(--text-secondary)'
                        }}>{u.role}</span>
                      </td>
                      <td>{new Date(u.createdAt).toLocaleDateString()}</td>
                      <td style={styles.deviceCount}>{u.deviceCount}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>

        {/* System log Trace */}
        <div style={styles.rightCol}>
          <div className="glass-panel" style={styles.logCard}>
            <div style={styles.tableHeader}>
              <div style={styles.cardHeader}>
                <Terminal size={18} color="#10b981" />
                <h2 style={styles.sectionTitle}>System Log Feed</h2>
              </div>
            </div>
            <div style={styles.logsList}>
              {logs.map((log) => (
                <div key={log.id} style={styles.logRow}>
                  <div style={styles.logMeta}>
                    <span style={{
                      ...styles.logAction,
                      color: log.action.includes('ERROR') ? 'var(--color-danger)' : 'var(--color-success)'
                    }}>{log.action}</span>
                    <span style={styles.logTime}>{new Date(log.timestamp).toLocaleTimeString()}</span>
                  </div>
                  <div style={styles.logDetails}>{log.details}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '24px',
    maxWidth: '1300px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '24px',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '16px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    color: '#fff',
  },
  subtitle: {
    fontSize: '14px',
    color: '#94a3b8',
    marginTop: '4px',
  },
  refreshBtn: {
    padding: '10px 16px',
    fontSize: '13px',
  },
  errorAlert: {
    background: 'rgba(239, 68, 68, 0.1)',
    border: '1px solid rgba(239, 68, 68, 0.3)',
    color: '#fca5a5',
    padding: '12px 16px',
    borderRadius: '8px',
    fontSize: '13px',
  },
  loadingCenter: {
    textAlign: 'center' as const,
    padding: '80px 20px',
    color: '#94a3b8',
    fontSize: '16px',
  },
  kpiGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
    gap: '20px',
  },
  kpiCard: {
    padding: '20px',
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
  },
  kpiLabel: {
    display: 'block',
    fontSize: '12px',
    color: '#94a3b8',
    textTransform: 'uppercase' as const,
    fontWeight: 500,
  },
  kpiVal: {
    fontSize: '20px',
    fontWeight: 700,
    color: '#fff',
    marginTop: '2px',
    display: 'block',
  },
  kpiSubval: {
    fontSize: '13px',
    fontWeight: 400,
    color: '#94a3b8',
  },
  mainGrid: {
    display: 'grid',
    gridTemplateColumns: '3fr 2fr',
    gap: '20px',
    '@media (max-width: 900px)': {
      gridTemplateColumns: '1fr',
    },
  },
  leftCol: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '20px',
  },
  rightCol: {
    display: 'flex',
    flexDirection: 'column' as const,
  },
  statsCard: {
    padding: '24px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  sectionTitle: {
    fontSize: '16px',
    fontWeight: 600,
    color: '#fff',
  },
  resourceRow: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '8px',
  },
  resourceHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '13px',
    span: {
      color: '#94a3b8',
    },
    strong: {
      color: '#fff',
    },
  },
  barContainer: {
    height: '8px',
    background: 'rgba(255,255,255,0.05)',
    borderRadius: '4px',
    overflow: 'hidden',
  },
  barFill: {
    height: '100%',
    borderRadius: '4px',
    transition: 'width 0.5s ease',
  },
  sysMetaGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
    borderTop: '1px solid rgba(255,255,255,0.05)',
    paddingTop: '16px',
  },
  sysMetaItem: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '4px',
    fontSize: '13px',
    span: {
      color: '#64748b',
    },
    strong: {
      color: '#cbd5e1',
    },
  },
  chartCard: {
    padding: '24px',
  },
  tableCard: {
    padding: '24px',
  },
  tableHeader: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: '16px',
  },
  cardHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
  },
  badge: {
    background: 'rgba(99,102,241,0.1)',
    color: 'var(--color-primary)',
    padding: '4px 10px',
    borderRadius: '20px',
    fontSize: '12px',
    fontWeight: 600,
  },
  tableWrapper: {
    width: '100%',
    overflowX: 'auto' as const,
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse' as const,
    textAlign: 'left' as const,
    fontSize: '13px',
    th: {
      color: '#64748b',
      fontWeight: 600,
      paddingBottom: '12px',
      borderBottom: '1px solid rgba(255,255,255,0.05)',
    },
    td: {
      padding: '12px 0',
      color: '#cbd5e1',
      borderBottom: '1px solid rgba(255,255,255,0.02)',
    },
  },
  userEmail: {
    color: '#fff',
    fontWeight: 500,
  },
  roleBadge: {
    padding: '2px 8px',
    borderRadius: '4px',
    fontSize: '11px',
    fontWeight: 600,
  },
  deviceCount: {
    fontWeight: 600,
    color: '#fff',
  },
  logCard: {
    padding: '24px',
    height: '100%',
    maxHeight: '620px',
    display: 'flex',
    flexDirection: 'column' as const,
  },
  logsList: {
    overflowY: 'auto' as const,
    flex: 1,
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '12px',
    marginTop: '8px',
    paddingRight: '6px',
  },
  logRow: {
    background: 'rgba(0,0,0,0.2)',
    border: '1px solid rgba(255,255,255,0.02)',
    padding: '12px',
    borderRadius: '8px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '4px',
  },
  logMeta: {
    display: 'flex',
    justifyContent: 'space-between',
    fontSize: '11px',
  },
  logAction: {
    fontWeight: 600,
    letterSpacing: '0.02em',
  },
  logTime: {
    color: '#64748b',
  },
  logDetails: {
    fontSize: '12px',
    color: '#94a3b8',
    wordBreak: 'break-all' as const,
    fontFamily: 'monospace',
    lineHeight: '1.4',
  },
};
