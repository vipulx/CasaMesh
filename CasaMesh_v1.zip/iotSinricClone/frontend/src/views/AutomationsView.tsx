import React, { useState, useEffect } from 'react';
import { Plus, Trash2, ShieldAlert, Cpu, ToggleLeft, ToggleRight, ArrowRight } from 'lucide-react';

interface Device {
  id: string;
  name: string;
  type: string;
}

interface Rule {
  id: string;
  name: string;
  active: boolean;
  triggerDeviceId: string;
  triggerProperty: string;
  operator: string;
  triggerValue: string;
  actionDeviceId: string;
  actionProperty: string;
  actionValue: string;
}

interface AutomationsViewProps {
  apiBase: string;
  token: string;
  devices: Device[];
}

export default function AutomationsView({ apiBase, token, devices }: AutomationsViewProps) {
  const [rules, setRules] = useState<Rule[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  
  // Modal State
  const [showAddModal, setShowAddModal] = useState(false);
  const [ruleName, setRuleName] = useState('');
  const [trigDevId, setTrigDevId] = useState('');
  const [trigProp, setTrigProp] = useState('powerState');
  const [op, setOp] = useState('EQUALS');
  const [trigVal, setTrigVal] = useState('');
  const [actDevId, setActDevId] = useState('');
  const [actProp, setActProp] = useState('powerState');
  const [actVal, setActVal] = useState('');

  const headers = {
    'Content-Type': 'application/json',
    'Authorization': `Bearer ${token}`,
  };

  const fetchRules = async () => {
    try {
      const res = await fetch(`${apiBase}/api/v1/automations`, { headers });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to fetch rules');
      setRules(data);
    } catch (err: any) {
      setError(err.message || 'Error loading rules');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRules();
  }, []);

  const handleCreateRule = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!ruleName || !trigDevId || !trigProp || !op || !trigVal || !actDevId || !actProp || !actVal) {
      setError('Please fill in all rule fields');
      return;
    }

    try {
      const res = await fetch(`${apiBase}/api/v1/automations`, {
        method: 'POST',
        headers,
        body: JSON.stringify({
          name: ruleName,
          triggerDeviceId: trigDevId,
          triggerProperty: trigProp,
          operator: op,
          triggerValue: trigVal,
          actionDeviceId: actDevId,
          actionProperty: actProp,
          actionValue: actVal,
        }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create automation rule');

      setRules([...rules, data]);
      setShowAddModal(false);
      resetForm();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleToggleRule = async (id: string, currentActive: boolean) => {
    try {
      const res = await fetch(`${apiBase}/api/v1/automations/${id}`, {
        method: 'PATCH',
        headers,
        body: JSON.stringify({ active: !currentActive }),
      });

      if (!res.ok) throw new Error('Failed to update rule');
      
      setRules(rules.map(r => r.id === id ? { ...r, active: !currentActive } : r));
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleDeleteRule = async (id: string) => {
    if (!confirm('Are you sure you want to delete this automation rule?')) return;

    try {
      const res = await fetch(`${apiBase}/api/v1/automations/${id}`, {
        method: 'DELETE',
        headers,
      });

      if (!res.ok) throw new Error('Failed to delete rule');
      
      setRules(rules.filter(r => r.id !== id));
    } catch (err: any) {
      setError(err.message);
    }
  };

  const resetForm = () => {
    setRuleName('');
    setTrigDevId('');
    setTrigProp('powerState');
    setOp('EQUALS');
    setTrigVal('');
    setActDevId('');
    setActProp('powerState');
    setActVal('');
  };

  const getDeviceName = (id: string) => {
    return devices.find(d => d.id === id)?.name || 'Unknown Device';
  };

  return (
    <div style={styles.container} className="animate-fade-in">
      <div style={styles.header}>
        <div>
          <h1 style={styles.title}>Smart Automations</h1>
          <p style={styles.subtitle}>Define logic links between your devices. Turn on switches when temperature rises, or trigger cascades.</p>
        </div>
        <button className="btn btn-primary" onClick={() => setShowAddModal(true)}>
          <Plus size={18} />
          Create Rule
        </button>
      </div>

      {error && (
        <div style={styles.errorAlert}>
          <ShieldAlert size={18} />
          <span>{error}</span>
        </div>
      )}

      {loading ? (
        <div style={styles.infoCenter}>Loading automation engine state...</div>
      ) : rules.length === 0 ? (
        <div className="glass-panel" style={styles.emptyCard}>
          <Cpu size={48} color="#6366f1" style={{ marginBottom: '16px', opacity: 0.6 }} />
          <h3>No Automations Defined</h3>
          <p>Link your sensors to relays or indicators using automated trigger rules.</p>
          <button className="btn btn-secondary" style={{ marginTop: '16px' }} onClick={() => setShowAddModal(true)}>
            Add Your First Rule
          </button>
        </div>
      ) : (
        <div style={styles.rulesList}>
          {rules.map((rule) => (
            <div key={rule.id} className="glass-panel" style={{
              ...styles.ruleCard,
              borderLeft: rule.active ? '4px solid var(--color-success)' : '4px solid var(--text-muted)'
            }}>
              <div style={styles.ruleLeft}>
                <div style={styles.ruleInfo}>
                  <strong style={styles.ruleName}>{rule.name}</strong>
                  <div style={styles.ruleExpression}>
                    <span style={styles.devName}>{getDeviceName(rule.triggerDeviceId)}</span>
                    <span style={styles.token}>.{rule.triggerProperty}</span>
                    <span style={styles.operator}>{rule.operator === 'EQUALS' ? '==' : rule.operator === 'GREATER_THAN' ? '>' : '<'}</span>
                    <span style={styles.value}>"{rule.triggerValue}"</span>
                    
                    <ArrowRight size={14} color="#94a3b8" style={{ margin: '0 8px' }} />
                    
                    <span style={styles.actLabel}>Set</span>
                    <span style={styles.devName}>{getDeviceName(rule.actionDeviceId)}</span>
                    <span style={styles.token}>.{rule.actionProperty}</span>
                    <span style={styles.token}>=</span>
                    <span style={styles.value}>"{rule.actionValue}"</span>
                  </div>
                </div>
              </div>

              <div style={styles.ruleRight}>
                <button 
                  onClick={() => handleToggleRule(rule.id, rule.active)}
                  style={styles.toggleBtn}
                >
                  {rule.active ? (
                    <ToggleRight size={38} color="#10b981" />
                  ) : (
                    <ToggleLeft size={38} color="#64748b" />
                  )}
                </button>
                <button 
                  onClick={() => handleDeleteRule(rule.id)}
                  style={styles.deleteBtn}
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* CREATE RULE MODAL */}
      {showAddModal && (
        <div style={styles.modalOverlay}>
          <div className="glass-panel" style={styles.modalCard}>
            <h2 style={styles.modalTitle}>New Automation Rule</h2>
            
            <form onSubmit={handleCreateRule} style={styles.form}>
              <div style={styles.inputGroup}>
                <label style={styles.label}>Rule Name</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="e.g., Turn on AC when hot" 
                  value={ruleName}
                  onChange={(e) => setRuleName(e.target.value)}
                  required
                />
              </div>

              {/* Trigger device select */}
              <div style={styles.formRow}>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>If This Device</label>
                  <select 
                    className="input-field"
                    value={trigDevId}
                    onChange={(e) => setTrigDevId(e.target.value)}
                    required
                    style={styles.select}
                  >
                    <option value="">Select Trigger Device</option>
                    {devices.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.type})</option>
                    ))}
                  </select>
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Property Trigger</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="e.g., temperature, powerState" 
                    value={trigProp}
                    onChange={(e) => setTrigProp(e.target.value)}
                    required
                  />
                </div>
              </div>

              {/* Operator and value */}
              <div style={styles.formRow}>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>Comparison</label>
                  <select 
                    className="input-field"
                    value={op}
                    onChange={(e) => setOp(e.target.value)}
                    required
                    style={styles.select}
                  >
                    <option value="EQUALS">EQUALS (==)</option>
                    <option value="GREATER_THAN">GREATER THAN (&gt;)</option>
                    <option value="LESS_THAN">LESS THAN (&lt;)</option>
                  </select>
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Compare Value</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="e.g., 28.5 or On" 
                    value={trigVal}
                    onChange={(e) => setTrigVal(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div style={styles.divider}></div>

              {/* Action device select */}
              <div style={styles.formRow}>
                <div style={styles.inputGroup}>
                  <label style={styles.label}>Then Perform Action On</label>
                  <select 
                    className="input-field"
                    value={actDevId}
                    onChange={(e) => setActDevId(e.target.value)}
                    required
                    style={styles.select}
                  >
                    <option value="">Select Target Device</option>
                    {devices.map(d => (
                      <option key={d.id} value={d.id}>{d.name} ({d.type})</option>
                    ))}
                  </select>
                </div>

                <div style={styles.inputGroup}>
                  <label style={styles.label}>Target Property</label>
                  <input 
                    type="text" 
                    className="input-field" 
                    placeholder="e.g. powerState, brightness" 
                    value={actProp}
                    onChange={(e) => setActProp(e.target.value)}
                    required
                  />
                </div>
              </div>

              <div style={styles.inputGroup}>
                <label style={styles.label}>Action Target Value</label>
                <input 
                  type="text" 
                  className="input-field" 
                  placeholder="e.g. On or Off" 
                  value={actVal}
                  onChange={(e) => setActVal(e.target.value)}
                  required
                />
              </div>

              <div style={styles.modalButtons}>
                <button type="button" className="btn btn-secondary" onClick={() => setShowAddModal(false)}>Cancel</button>
                <button type="submit" className="btn btn-primary">Save Automation</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

const styles = {
  container: {
    padding: '24px',
    maxWidth: '1000px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '24px',
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '16px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    color: '#fff',
  },
  subtitle: {
    fontSize: '14px',
    color: '#94a3b8',
    marginTop: '4px',
  },
  errorAlert: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
    background: 'rgba(239, 68, 68, 0.1)',
    border: '1px solid rgba(239, 68, 68, 0.3)',
    color: '#fca5a5',
    padding: '12px 16px',
    borderRadius: '8px',
    fontSize: '13px',
  },
  infoCenter: {
    textAlign: 'center' as const,
    padding: '40px',
    color: '#94a3b8',
  },
  emptyCard: {
    textAlign: 'center' as const,
    padding: '48px 24px',
    h3: {
      color: '#fff',
      fontSize: '20px',
      marginBottom: '8px',
    },
    p: {
      color: '#94a3b8',
      fontSize: '14px',
      maxWidth: '400px',
      margin: '0 auto',
    },
  },
  rulesList: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  ruleCard: {
    padding: '20px 24px',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    gap: '20px',
  },
  ruleLeft: {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
  },
  ruleInfo: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '8px',
  },
  ruleName: {
    fontSize: '16px',
    color: '#fff',
    fontWeight: 600,
  },
  ruleExpression: {
    display: 'flex',
    alignItems: 'center',
    flexWrap: 'wrap' as const,
    gap: '4px',
    fontSize: '13px',
  },
  devName: {
    color: '#6366f1',
    fontWeight: 600,
    background: 'rgba(99, 102, 241, 0.08)',
    padding: '2px 6px',
    borderRadius: '4px',
  },
  token: {
    color: '#cbd5e1',
    fontWeight: 500,
  },
  operator: {
    color: '#d946ef',
    fontWeight: 700,
    padding: '0 4px',
  },
  value: {
    color: '#10b981',
    fontWeight: 600,
    background: 'rgba(16, 185, 129, 0.08)',
    padding: '2px 6px',
    borderRadius: '4px',
  },
  actLabel: {
    color: '#94a3b8',
    fontWeight: 500,
    marginRight: '4px',
  },
  ruleRight: {
    display: 'flex',
    alignItems: 'center',
    gap: '16px',
  },
  toggleBtn: {
    background: 'transparent',
    border: 'none',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
  },
  deleteBtn: {
    background: 'rgba(239, 68, 68, 0.05)',
    border: '1px solid rgba(239, 68, 68, 0.1)',
    color: '#fca5a5',
    cursor: 'pointer',
    padding: '8px',
    borderRadius: '8px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    transition: 'all 0.2s',
    '&:hover': {
      background: 'rgba(239, 68, 68, 0.2)',
      borderColor: 'rgba(239, 68, 68, 0.4)',
    },
  },
  modalOverlay: {
    position: 'fixed' as const,
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    background: 'rgba(0,0,0,0.6)',
    backdropFilter: 'blur(4px)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 100,
    padding: '20px',
  },
  modalCard: {
    width: '100%',
    maxWidth: '550px',
    padding: '30px',
    maxHeight: '90vh',
    overflowY: 'auto' as const,
  },
  modalTitle: {
    fontSize: '20px',
    fontWeight: 600,
    color: '#fff',
    marginBottom: '20px',
  },
  form: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  formRow: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '16px',
  },
  inputGroup: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '6px',
  },
  label: {
    fontSize: '11px',
    fontWeight: 600,
    color: '#94a3b8',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  select: {
    appearance: 'none' as const,
    backgroundImage: `url("data:image/svg+xml;utf8,<svg fill='white' height='24' viewBox='0 0 24 24' width='24' xmlns='http://www.w3.org/2000/svg'><path d='M7 10l5 5 5-5z'/><path d='M0 0h24v24H0z' fill='none'/></svg>")`,
    backgroundRepeat: 'no-repeat',
    backgroundPosition: 'right 12px center',
    backgroundSize: '20px',
    paddingRight: '36px',
  },
  divider: {
    height: '1px',
    background: 'rgba(255,255,255,0.06)',
    margin: '8px 0',
  },
  modalButtons: {
    display: 'flex',
    justifyContent: 'flex-end',
    gap: '12px',
    marginTop: '10px',
  },
};
