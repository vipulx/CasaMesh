import { useState } from 'react';
import { Shield, Key, Copy, Check, Radio, Layers } from 'lucide-react';

interface IntegrationsProps {
  user: {
    clientID: string;
    clientSecret: string;
  };
}

export default function IntegrationsView({ user }: IntegrationsProps) {
  const [copiedText, setCopiedText] = useState<string | null>(null);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedText(label);
    setTimeout(() => setCopiedText(null), 2000);
  };

  const domain = window.location.origin;

  const haConfig = `# Home Assistant configuration.yaml (NimbusIoT MQTT integration)
mqtt:
  switch:
    - name: "Living Room Light"
      state_topic: "device/YOUR_DEVICE_ID/updateState"
      command_topic: "device/YOUR_DEVICE_ID/command"
      value_template: "{{ value_json.properties.powerState }}"
      state_on: "On"
      state_off: "Off"
      command_on_template: '{"action":"setPowerState","value":"On"}'
      command_off_template: '{"action":"setPowerState","value":"Off"}'
      qos: 1
      retain: false
`;

  return (
    <div style={styles.container} className="animate-fade-in">
      <div style={styles.header}>
        <h1 style={styles.title}>Integrations & API Keys</h1>
        <p style={styles.subtitle}>Connect NimbusIoT with third-party home automation systems and smart assistants</p>
      </div>

      <div style={styles.cardGrid}>
        {/* API Credentials */}
        <div className="glass-panel" style={styles.card}>
          <div style={styles.cardHeader}>
            <Key size={20} color="#6366f1" />
            <h2 style={styles.cardTitle}>Nimbus Credentials</h2>
          </div>
          <p style={styles.cardDescription}>Use these client keys to link OAuth2 services or verify MQTT connections.</p>
          
          <div style={styles.credentialGroup}>
            <div style={styles.credentialRow}>
              <div style={styles.credLabel}>Client ID</div>
              <div style={styles.credValue}>
                <code>{user.clientID}</code>
                <button 
                  onClick={() => handleCopy(user.clientID, 'clientID')}
                  style={styles.copyBtn}
                >
                  {copiedText === 'clientID' ? <Check size={14} color="#10b981" /> : <Copy size={14} />}
                </button>
              </div>
            </div>

            <div style={styles.credentialRow}>
              <div style={styles.credLabel}>Client Secret</div>
              <div style={styles.credValue}>
                <code>{user.clientSecret}</code>
                <button 
                  onClick={() => handleCopy(user.clientSecret, 'clientSecret')}
                  style={styles.copyBtn}
                >
                  {copiedText === 'clientSecret' ? <Check size={14} color="#10b981" /> : <Copy size={14} />}
                </button>
              </div>
            </div>
          </div>
        </div>

        {/* Local MQTT Broker */}
        <div className="glass-panel" style={styles.card}>
          <div style={styles.cardHeader}>
            <Radio size={20} color="#10b981" />
            <h2 style={styles.cardTitle}>Local MQTT Connection</h2>
          </div>
          <p style={styles.cardDescription}>Your self-hosted instance runs a full MQTT Broker locally on port 1883.</p>
          
          <div style={styles.mqttGrid}>
            <div style={styles.mqttItem}>
              <span>Host IP</span>
              <strong>Local Server IP</strong>
            </div>
            <div style={styles.mqttItem}>
              <span>Port</span>
              <strong>1883 (TCP)</strong>
            </div>
            <div style={styles.mqttItem}>
              <span>Username</span>
              <strong>Your Client ID</strong>
            </div>
            <div style={styles.mqttItem}>
              <span>Password</span>
              <strong>Device Key</strong>
            </div>
          </div>
        </div>
      </div>

      {/* Assistant Stubs */}
      <div className="glass-panel" style={styles.bigCard}>
        <div style={styles.cardHeader}>
          <Layers size={20} color="#d946ef" />
          <h2 style={styles.cardTitle}>Alexa & Google Home Smart Integrations</h2>
        </div>
        <p style={styles.cardDescription}>
          To link your smart assistant, create a developer action/skill pointing to your public Cloudflare Tunnel URL.
        </p>

        <div style={styles.integrationsGrid}>
          <div style={styles.integrationCol}>
            <div style={styles.colHeader}>Alexa Smart Home Skill</div>
            <div style={styles.stepList}>
              <div style={styles.step}>1. Create a custom Skill in the Alexa Developer Console using the "Smart Home" model.</div>
              <div style={styles.step}>2. Enable Account Linking. Use authorization code grant:</div>
              <div style={styles.urlBlock}>
                <div>Authorization URI: <br/><code>{domain}/oauth/authorize</code></div>
                <div>Access Token URI: <br/><code>{domain}/oauth/token</code></div>
              </div>
              <div style={styles.step}>3. Set the endpoint webhook (fulfillment lambda/endpoint) to:</div>
              <div style={styles.urlBlock}>
                <code>{domain}/api/v1/smarthome/alexa</code>
              </div>
            </div>
          </div>

          <div style={styles.integrationCol}>
            <div style={styles.colHeader}>Google Home Smart Action</div>
            <div style={styles.stepList}>
              <div style={styles.step}>1. Open the Actions on Google Console and create a Smart Home Project.</div>
              <div style={styles.step}>2. Configure Account Linking under Development panel:</div>
              <div style={styles.urlBlock}>
                <div>Authorization URI: <br/><code>{domain}/oauth/authorize</code></div>
                <div>Token Exchange URI: <br/><code>{domain}/oauth/token</code></div>
              </div>
              <div style={styles.step}>3. Set the fulfillment URL under the Action settings to:</div>
              <div style={styles.urlBlock}>
                <code>{domain}/api/v1/smarthome/google</code>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Home Assistant Copy Card */}
      <div className="glass-panel" style={styles.bigCard}>
        <div style={styles.cardHeader}>
          <Shield size={20} color="#f59e0b" />
          <h2 style={styles.cardTitle}>Home Assistant Configuration</h2>
        </div>
        <p style={styles.cardDescription}>
          Connect devices directly to Home Assistant by defining YAML switches/sensors that subscribe to states.
        </p>
        <div style={styles.codeBlockWrapper}>
          <button 
            onClick={() => handleCopy(haConfig, 'haConfig')}
            style={styles.codeCopyBtn}
            className="btn btn-secondary"
          >
            {copiedText === 'haConfig' ? <Check size={14} color="#10b981" /> : <Copy size={14} />}
            {copiedText === 'haConfig' ? 'Copied YAML!' : 'Copy YAML'}
          </button>
          <pre style={styles.pre}>
            <code>{haConfig}</code>
          </pre>
        </div>
      </div>
    </div>
  );
}

const styles = {
  container: {
    padding: '24px',
    maxWidth: '1200px',
    margin: '0 auto',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '24px',
  },
  header: {
    marginBottom: '8px',
  },
  title: {
    fontSize: '28px',
    fontWeight: 700,
    color: '#fff',
  },
  subtitle: {
    fontSize: '14px',
    color: '#94a3b8',
    marginTop: '4px',
  },
  cardGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
    gap: '20px',
  },
  card: {
    padding: '24px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  bigCard: {
    padding: '24px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '16px',
  },
  cardHeader: {
    display: 'flex',
    alignItems: 'center',
    gap: '10px',
  },
  cardTitle: {
    fontSize: '18px',
    fontWeight: 600,
    color: '#fff',
  },
  cardDescription: {
    fontSize: '13px',
    color: '#94a3b8',
    lineHeight: '1.5',
  },
  credentialGroup: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '12px',
  },
  credentialRow: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '6px',
  },
  credLabel: {
    fontSize: '11px',
    fontWeight: 600,
    color: '#64748b',
    textTransform: 'uppercase' as const,
    letterSpacing: '0.05em',
  },
  credValue: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '10px 14px',
    background: 'rgba(0, 0, 0, 0.4)',
    border: '1px solid rgba(255, 255, 255, 0.05)',
    borderRadius: '8px',
    fontFamily: 'monospace',
    fontSize: '13px',
    color: '#f8fafc',
    overflowX: 'auto' as const,
    gap: '10px',
  },
  copyBtn: {
    background: 'transparent',
    border: 'none',
    color: '#94a3b8',
    cursor: 'pointer',
    padding: '4px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '4px',
    transition: 'background 0.2s',
  },
  mqttGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '12px',
    background: 'rgba(0,0,0,0.2)',
    padding: '16px',
    borderRadius: '10px',
    border: '1px solid rgba(255,255,255,0.03)',
  },
  mqttItem: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '4px',
    fontSize: '13px',
    span: {
      color: '#64748b',
      fontSize: '11px',
      textTransform: 'uppercase' as const,
    },
    strong: {
      color: '#f8fafc',
      fontWeight: 500,
    },
  },
  integrationsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(320px, 1fr))',
    gap: '20px',
    marginTop: '10px',
  },
  integrationCol: {
    background: 'rgba(255, 255, 255, 0.01)',
    border: '1px solid rgba(255, 255, 255, 0.03)',
    padding: '18px',
    borderRadius: '12px',
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '14px',
  },
  colHeader: {
    fontSize: '15px',
    fontWeight: 600,
    color: '#fff',
    borderBottom: '1px solid rgba(255,255,255,0.05)',
    paddingBottom: '8px',
  },
  stepList: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '10px',
  },
  step: {
    fontSize: '13px',
    color: '#94a3b8',
    lineHeight: '1.4',
  },
  urlBlock: {
    display: 'flex',
    flexDirection: 'column' as const,
    gap: '8px',
    background: 'rgba(0,0,0,0.3)',
    padding: '10px 14px',
    borderRadius: '8px',
    fontSize: '12px',
    color: '#cbd5e1',
    lineHeight: '1.5',
    fontFamily: 'monospace',
    wordBreak: 'break-all' as const,
  },
  codeBlockWrapper: {
    position: 'relative' as const,
  },
  codeCopyBtn: {
    position: 'absolute' as const,
    top: '12px',
    right: '12px',
    padding: '6px 12px',
    fontSize: '12px',
    display: 'flex',
    alignItems: 'center',
    gap: '6px',
    zIndex: 1,
  },
  pre: {
    background: '#040209',
    border: '1px solid rgba(255,255,255,0.04)',
    padding: '20px',
    borderRadius: '10px',
    fontSize: '13px',
    overflowX: 'auto' as const,
    color: '#cbd5e1',
    fontFamily: 'Consolas, Monaco, monospace',
    lineHeight: '1.6',
  },
};
