/*
 * NimbusIoT ESP32 Device Firmware Template
 * Redesigned for self-hosted secure WebSocket connections.
 * 
 * Dependencies:
 * - WebSockets by Markus Sattler (install via Library Manager)
 * - ArduinoJson by Benoit Blanchon (install via Library Manager)
 */

#include <WiFi.h>
#include <WebSocketsClient.h>
#include <ArduinoJson.h>

// WiFi Configuration
const char* ssid = "YOUR_WIFI_SSID";
const char* password = "YOUR_WIFI_PASSWORD";

// NimbusIoT Server Endpoint. 
// Points directly to your secure production cloud domain.
// For local testing, change values to your local server IP (e.g., 192.168.1.100, port 3001, is_secure = false).
const char* ws_host = "iot.siddhart.qzz.io"; 
const int ws_port = 443; 
const char* ws_path = "/api/v1/ws/device";
const bool is_secure = true; // Set true for wss:// (SSL)

// Device Registration Details
const char* deviceId = "YOUR_REGISTERED_DEVICE_ID";
const char* deviceKey = "YOUR_DEVICE_KEY";
const char* deviceSecret = "YOUR_DEVICE_SECRET";
const char* clientId = "YOUR_USER_CLIENT_ID";

WebSocketsClient webSocket;
unsigned long lastTelemetryTime = 0;
const int relayPin = 2; // Default onboard LED pin on most ESP32 dev boards

void webSocketEvent(WStype_t type, uint8_t * payload, size_t length) {
  switch(type) {
    case WStype_DISCONNECTED:
      Serial.println("[WS] Status: Disconnected from NimbusIoT Cloud.");
      break;
    case WStype_CONNECTED:
      Serial.println("[WS] Status: Connected and Authenticated!");
      break;
    case WStype_TEXT: {
      Serial.printf("[WS] Received raw command: %s\n", payload);
      
      StaticJsonDocument<384> doc;
      DeserializationError error = deserializeJson(doc, payload, length);
      if (error) {
        Serial.print(F("deserializeJson() failed: "));
        Serial.println(error.f_str());
        return;
      }
      
      const char* action = doc["action"];
      
      if (strcmp(action, "setPowerState") == 0) {
        const char* value = doc["value"];
        Serial.printf("[Control] Setting power state to: %s\n", value);
        
        // Control pin status
        if (strcmp(value, "On") == 0) {
          digitalWrite(relayPin, HIGH);
        } else {
          digitalWrite(relayPin, LOW);
        }
        
        // Dispatch state confirmation response back to dashboard
        StaticJsonDocument<256> confirmDoc;
        confirmDoc["action"] = "updateState";
        JsonObject props = confirmDoc.createNestedObject("properties");
        props["powerState"] = value;
        
        String response;
        serializeJson(confirmDoc, response);
        webSocket.sendTXT(response);
      }
      break;
    }
    case WStype_BIN:
      break;
    case WStype_PING:
    case WStype_PONG:
      break;
  }
}

void setup() {
  Serial.begin(115200);
  pinMode(relayPin, OUTPUT);
  digitalWrite(relayPin, LOW);
  
  // WiFi connection
  Serial.printf("Connecting to WiFi %s...", ssid);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }
  Serial.println("\nWiFi connected! IP Address: ");
  Serial.println(WiFi.localIP());

  // Setup headers for HTTP upgrade handshake authorization
  String headers = "x-client-id: " + String(clientId) + "\r\n" +
                   "x-device-id: " + String(deviceId) + "\r\n" +
                   "x-device-key: " + String(deviceKey) + "\r\n" +
                   "x-device-secret: " + String(deviceSecret);

  // Setup WS Connection
  if (is_secure) {
    webSocket.beginSSL(ws_host, ws_port, ws_path);
  } else {
    webSocket.begin(ws_host, ws_port, ws_path);
  }
  
  webSocket.setExtraHeaders(headers.c_str());
  webSocket.onEvent(webSocketEvent);
  
  // Keep-alive settings: ping every 15s, expect pong in 3s, retry 2 times before dropping
  webSocket.enableHeartbeat(15000, 3000, 2);
}

void loop() {
  webSocket.loop();
  
  // Simulate and push telemetry every 10 seconds (e.g. if SENSOR type)
  unsigned long now = millis();
  if (now - lastTelemetryTime > 10000) {
    lastTelemetryTime = now;
    
    StaticJsonDocument<256> telemetryDoc;
    telemetryDoc["action"] = "telemetry";
    JsonObject props = telemetryDoc.createNestedObject("properties");
    
    // Simulate analog readings
    props["temperature"] = 23.4 + (random(-15, 20) / 10.0);
    props["humidity"] = 48.0 + (random(-50, 50) / 10.0);
    
    String payload;
    serializeJson(telemetryDoc, payload);
    webSocket.sendTXT(payload);
    Serial.println("[WS] Telemetry simulation packet published");
  }
}
